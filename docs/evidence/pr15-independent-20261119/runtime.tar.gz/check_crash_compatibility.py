"""Real unreceipted write; candidate export must preserve legacy UNKNOWN."""
import json
import sys
from pathlib import Path
from agent.engine_v5 import EngineV5Policy
from agent.persistence import SQLiteRuntimeStore, PersistenceError, digest, dumps
from agent.registry import create_default_registry
from agent.retry import RetryPolicy
from agent.session import AgentSession, SessionBudgets
from localpilot_api.service import APIError, TaskRequest, TaskService
from tests.test_runtime_api import Backend, answer, call

phase, location = sys.argv[1:]
root = Path(location)
root.mkdir(exist_ok=True)
workspace = root / 'workspace'
workspace.mkdir(exist_ok=True)
database = root / 'runtime.sqlite3'
backend = Backend(answer(None, call('apply_patch', {'changes': [
    {'operation': 'create', 'path': 'effect.txt', 'content': 'ONCE'}]}, 'write')), answer('done'))

def factory(callback):
    return AgentSession(create_default_registry(workspace, permission_mode='full-permission'),
        backend=backend, policy='cloud-only', streaming=False, event_callback=callback,
        engine_policy=EngineV5Policy(), retry_policy=RetryPolicy(max_attempts=1),
        budgets=SessionBudgets(max_steps=12, max_tool_calls=20, max_token_units=1000000, max_output_tokens=512))

if phase == 'old-refuses':
    try:
        SQLiteRuntimeStore(database)
    except PersistenceError as error:
        assert 'Unsupported persistent runtime schema' in str(error.__cause__), str(error.__cause__)
        result = {'status': 'PASS', 'phase': phase, 'schema4_refused': True,
                  'source': str(Path(sys.modules['agent.persistence'].__file__).resolve())}
    else:
        raise AssertionError('Unmodified old runtime accepted block format')
else:
    service = TaskService({'localpilot': factory}, persistence=database)
    if phase == 'unreceipted-write':
        def fail(stage, point):
            if stage == 'before_commit' and point == 'tool_receipt':
                raise OSError('injected receipt commit failure after real write')
        service.store.fault_hook = fail
        task = service.wait(service.create_task(TaskRequest('Write effect.txt once.', idempotency_key='same-operation'))['id'])
        assert (workspace / 'effect.txt').read_text() == 'ONCE'
        assert task['recovery']['class'] == 'UNKNOWN_BLOCKED', task
        data = {'task_id': task['id'], 'mtime_ns': (workspace / 'effect.txt').stat().st_mtime_ns,
                'journal': service.store.connection.execute('SELECT * FROM journal ORDER BY revision').fetchall()}
        (root / 'original.json').write_text(json.dumps(data))
        assert service.store.connection.execute('PRAGMA user_version').fetchone()[0] == 4
        store, service.store = service.store, None
        store.close()
        service.shutdown(timeout=3)
        result = {'status': 'PASS', 'phase': phase, 'actual_write': True, 'durable_receipt': False,
                  'schema': 4, 'task_id': task['id'], 'recovery': task['recovery']}
    elif phase == 'old-unknown':
        data = json.loads((root / 'original.json').read_text())
        task = service.task_snapshot(data['task_id'])
        assert task['recovery']['class'] == 'UNKNOWN_BLOCKED', task
        try:
            service.act(task['id'], 'continue', task['required_action']['id'])
        except APIError as error:
            assert error.code == 'unknown_blocked', error.code
        else:
            raise AssertionError('Legacy resumed an unknown mutation')
        assert backend.requests == []
        assert (workspace / 'effect.txt').read_text() == 'ONCE'
        assert (workspace / 'effect.txt').stat().st_mtime_ns == data['mtime_ns']
        journal = service.store.connection.execute('SELECT * FROM journal ORDER BY revision LIMIT ?', (len(data['journal']),)).fetchall()
        assert [list(row) for row in journal] == data['journal']
        result = {'status': 'PASS', 'phase': phase, 'source': str(Path(sys.modules['agent.persistence'].__file__).resolve()),
                  'recovery': task['recovery'], 'provider_calls': 0, 'original_journal_preserved': True,
                  'effect_mtime_unchanged': True}
        service.suspend()
    else:
        raise AssertionError(phase)
(root / (phase + '.json')).write_text(json.dumps(result, indent=2))
print(json.dumps(result))
