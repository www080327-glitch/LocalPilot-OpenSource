"""Reuse the crash fixture's exact TaskService configuration for its durable intent."""
import hashlib
import sqlite3
from pathlib import Path

fixture = Path(__file__).with_name("check_crash_compatibility.py")
setup, marker, _ = fixture.read_text().partition("if phase == 'old-refuses':")
assert marker
exec(compile(setup, str(fixture), "exec"))

def journal_hashes():
    with sqlite3.connect(database.as_uri() + "?mode=ro", uri=True) as db:
        rows = db.execute("SELECT session_id,revision,point,sha256,at FROM journal ORDER BY session_id,revision").fetchall()
    return [hashlib.sha256(dumps(row).encode()).hexdigest() for row in rows]

before = journal_hashes()
if phase == "materialize":
    store = SQLiteRuntimeStore(database)
    try:
        conversion = store.materialize_legacy()
    finally:
        store.close()
    assert conversion["schema_before"] == 4 and conversion["schema_after"] == 3
    output = {"conversion": conversion}
else:
    service = TaskService({"localpilot": factory}, persistence=database)
    task_id, = service.tasks
    task = service.task_snapshot(task_id)
    assert task["recovery"]["class"] == "UNKNOWN_BLOCKED"
    try:
        service.act(task_id, "continue", task["required_action"]["id"])
    except APIError as error:
        assert error.code == "unknown_blocked"
    else:
        raise AssertionError("Unreceipted intent resumed")
    assert not backend.requests and not (workspace / "effect.txt").exists()
    service.suspend()
    output = {"recovery_class": task["recovery"]["class"], "provider_calls": len(backend.requests), "effect_exists": False}
after = journal_hashes()
assert after[:len(before)] == before
print(json.dumps({"phase":phase, "source":str(Path(sys.modules["agent.persistence"].__file__).resolve()),
                  "journal_rows_before":len(before), "journal_rows_after":len(after), **output}))
