"""Measure existing MCP startup and Schema subprocesses without changing their limits."""
import json
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import sys
import time
import unittest

TRACE = Path(__file__).with_name("startup-final-stages.jsonl")

def record(stage, **extra):
    value = {"stage": stage, "ns": time.monotonic_ns(), "pid": os.getpid(), **extra}
    with TRACE.open("a") as stream:
        stream.write(json.dumps(value) + "\n")

def trace_child(kind):
    record("interpreter_entered", kind=kind, parent_pid=os.getppid())
    if kind == "schema":
        runpy.run_path(sys.argv[2], run_name="__main__")
        record("schema_validation_finished")
        return
    from localpilot_plugins import worker
    import inspect
    source, first = inspect.getsourcelines(worker.run)
    needles = {
        "import anyio": "sdk_import_begin",
        "line = await asyncio.to_thread(sys.stdin.buffer.readline, MAX_FRAME + 1)": "config_read_begin",
        "config = json.loads(line)": "config_frame_read",
        "streams = await stack.enter_async_context(stdio_client": "stdio_enter_begin",
        "session = await stack.enter_async_context(Session": "stdio_enter_done",
        "initialized = await session.initialize()": "handshake_begin",
        "if initialized.protocolVersion != PROTOCOL_VERSION:": "handshake_done",
        'emit({"catalog": await catalog()})': "catalog_begin",
        "async def operation(request):": "catalog_frame_flushed",
    }
    lines = {}
    for index, line in enumerate(source, first):
        for prefix, label in needles.items():
            if line.strip().startswith(prefix) and label not in lines.values():
                lines[index] = label

    def local_trace(frame, event, value):
        if event == "line" and frame.f_lineno in lines:
            record(lines[frame.f_lineno])
        elif event == "exception":
            cls = value[0]
            if cls not in (StopIteration, StopAsyncIteration):
                record("worker_exception", error=cls.__name__)
        return local_trace

    def dispatch(frame, event, value):
        if frame.f_code is worker.run.__code__:
            return local_trace
        return None

    record("worker_module_imported")
    sys.settrace(dispatch)
    raise SystemExit(worker.main())

def run_probe():
    root = Path(sys.argv[1]).resolve()
    os.chdir(root)
    sys.path.insert(0, str(root))
    from localpilot_plugins.client import MCPClient, TransportFailure
    from localpilot_plugins.security import validate_input
    from tests.test_plugin_ecosystem import PluginTests

    class TracedPopen(subprocess.Popen):
        def __init__(self, args, *rest, **options):
            kind = ("sdk_worker" if args[1:3] == ["-m", "localpilot_plugins.worker"]
                    else "schema" if len(args) == 2 and str(args[1]).endswith("/schema_worker.py")
                    else None) if isinstance(args, list) else None
            if kind:
                record("popen_begin", kind=kind)
                args = [args[0], __file__, kind, *args[1:]]
            super().__init__(args, *rest, **options)
            self.trace_kind = kind
            if kind:
                record("popen_returned", kind=kind, child_pid=self.pid)

        def communicate(self, *args, **kwargs):
            try:
                result = super().communicate(*args, **kwargs)
            except Exception as exc:
                if self.trace_kind:
                    record("subprocess_error", kind=self.trace_kind, child_pid=self.pid,
                           error=type(exc).__name__, errno=getattr(exc, "errno", None))
                raise
            if self.trace_kind:
                record("subprocess_returned", kind=self.trace_kind, child_pid=self.pid, returncode=self.returncode)
            return result

    receive = MCPClient._receive
    def measured_receive(client):
        child_pid = client.process.pid
        record("parent_receive_begin", child_pid=child_pid)
        try:
            outcome = receive(client)
        except (TransportFailure, PermissionError) as error:
            record("parent_receive_error", child_pid=child_pid, error=type(error).__name__,
                   reason=getattr(error, "reason", None), errno=getattr(error, "errno", None))
            raise
        record("parent_receive_result", child_pid=child_pid, catalog="catalog" in outcome,
               failure=outcome.get("failure"))
        return outcome

    subprocess.Popen = TracedPopen
    MCPClient._receive = measured_receive
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(PluginTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    schema_ok = False
    try:
        validate_input({"text": "public"}, {"type": "object", "properties": {"text": {"type": "string"}}})
        schema_ok = True
    finally:
        record("schema_parent_result", success=schema_ok)
    with tempfile.TemporaryDirectory(prefix="lp-stdio-measure-") as cwd:
        # Worker-only observation using the same synthetic fixture. The product
        # process-tree gate already failed above and this does no Agent dispatch.
        config = PluginTests.config()
        env = {"PATH": os.defpath, "HOME": cwd, "LANG": "en_US.UTF-8",
               "PYTHONPATH": str(root), "PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1"}
        with TracedPopen([sys.executable, "-m", "localpilot_plugins.worker"],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                cwd=cwd, env=env, start_new_session=True, bufsize=0) as worker:
            start = time.monotonic_ns()
            try:
                stdout, _ = worker.communicate((json.dumps(config) + "\n").encode(), timeout=config["timeout"] + 1)
            except subprocess.TimeoutExpired:
                worker.kill()
                worker.communicate()
                raise
            frame = json.loads(stdout.splitlines()[0])
            record("standalone_worker_result", elapsed_ns=time.monotonic_ns() - start,
                   child_pid=worker.pid, returncode=worker.returncode, catalog="catalog" in frame,
                   failure=frame.get("failure"))
    return not result.wasSuccessful()

if __name__ == "__main__":
    if sys.argv[1] in {"sdk_worker", "schema"}:
        trace_child(sys.argv[1])
    else:
        raise SystemExit(run_probe())
