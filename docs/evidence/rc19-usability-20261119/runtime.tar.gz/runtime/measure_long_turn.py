"""One real scripted task, real file reads and SQLite writes; no model provider."""
import json
import time
from pathlib import Path
from agent.engine_v5 import EngineV5Policy
from agent.registry import create_default_registry
from agent.retry import RetryPolicy
from agent.session import AgentSession, SessionBudgets
from localpilot_api.service import TaskService, TaskRequest
from tests.test_runtime_api import Backend, answer, call

root = Path(__file__).parent / 'long-turn-case-r2'
root.mkdir(exist_ok=True)
workspace = root / 'workspace'
workspace.mkdir(exist_ok=True)
total = 96
for index in range(total):
    (workspace / f'fact-{index}.txt').write_text(f'UNIQUE SOURCE {index}\n' + 'retained original text ' * 200)
backend = Backend(*(answer(None, call('read_file', {'path': f'fact-{index}.txt'}, f'read-{index}'))
                    for index in range(total)), answer('Inspected all generated inputs.'))

def factory(callback):
    return AgentSession(create_default_registry(workspace, permission_mode='full-permission'),
        backend=backend, policy='cloud-only', event_callback=callback, streaming=False,
        engine_policy=EngineV5Policy(max_completion_repairs=0), retry_policy=RetryPolicy(max_attempts=1),
        budgets=SessionBudgets(max_steps=110, max_tool_calls=110, max_token_units=256000000, max_output_tokens=512))

service = TaskService({'localpilot': factory}, persistence=root / 'runtime.sqlite3')
checkpoint = service._checkpoint
samples = []

def measured(session_id, point, **kwargs):
    start = time.perf_counter()
    checkpoint(session_id, point, **kwargs)
    elapsed = time.perf_counter() - start
    runtime = service.sessions[session_id].runtime
    count = len(runtime.tool_history)
    if count in {0, 1, 8, 16, 32, 64, 96}:
        row = service.store.connection.execute('SELECT length(CAST(payload AS BLOB)) FROM checkpoints WHERE session_id=?', (session_id,)).fetchone()
        samples.append({'receipts': count, 'point': point, 'seconds': elapsed,
                        'checkpoint_bytes': row[0], 'canonical_messages': len(runtime.messages),
                        'model_window_messages': len(runtime._request_history.messages)})

service._checkpoint = measured
started = time.perf_counter()
task = service.wait(service.create_task(TaskRequest('Inspect the generated facts and report completion.', timeout_seconds=180))['id'])
summary = {'status': task['status'], 'elapsed_seconds': time.perf_counter() - started,
           'tool_count': len(task['tools']), 'provider': 'scripted-only', 'samples': samples,
           'raw_error': task.get('error'), 'result': task.get('result', {}).get('text')}
service.suspend()
(root / 'measurements.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps(summary, ensure_ascii=False))
