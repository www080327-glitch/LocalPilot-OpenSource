import importlib.metadata
import json
from pathlib import Path
import sys
import time
import unittest

harness = Path(__file__).resolve().parent
runtime = Path(sys.prefix).resolve()
sys.path.insert(0, str(harness))
names = ['tests.test_history_recall', 'test_task_store', 'test_pet_history']
start = time.monotonic()
suite = unittest.defaultTestLoader.loadTestsFromNames(names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
prefixes = ('agent', 'companion', 'computer', 'localpilot_api', 'localpilot_service', 'localpilot_suite', 'localpilot_channels')
locations = {}
for name, module in sorted(sys.modules.items()):
    if name.split('.')[0] not in prefixes or not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    assert path.is_relative_to(runtime), (name, str(path), str(runtime))
    locations[name] = str(path.relative_to(runtime))
report = {'scope': 'Real package runtime imports only, copied test harness; no system package installation claim', 'source_commit': '02838a5db0b342647fc0f7904738bee87f167cf0', 'python': sys.version, 'isolated': bool(sys.flags.isolated), 'runtime': str(runtime), 'names': names, 'run': result.testsRun, 'passed': result.testsRun - len(result.errors) - len(result.failures) - len(result.skipped), 'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped), 'seconds': time.monotonic()-start, 'module_locations': locations}
(harness.parent/'PACKAGED_RUNTIME_TESTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key != 'module_locations'},indent=2))
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)
