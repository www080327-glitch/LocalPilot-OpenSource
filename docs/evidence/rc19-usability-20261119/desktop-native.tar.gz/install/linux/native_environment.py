"""Reproduce the existing Linux packaging flow against downloaded reviewed dependencies."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUST = Path('/workspace/scratch/c0f3ec78c621/validation/context-20261117/toolchain/rustup/toolchains/1.100.0-x86_64-unknown-linux-gnu/bin')


def environment():
    sysroot = ROOT / 'sysroot'
    env = dict(os.environ)
    for key in ('PYTHONPATH', 'PYTHONHOME'):
        env.pop(key, None)
    env.update(
        PATH=os.pathsep.join([str(ROOT/'node-v22.23.4-linux-x64/bin'), str(RUST), str(sysroot/'usr/bin'), env['PATH']]),
        CARGO_HOME=str(ROOT/'cargo'),
        CARGO_NET_OFFLINE='true',
        CARGO_BUILD_JOBS='1',
        CARGO_TARGET_DIR=str(ROOT/'target'),
        PKG_CONFIG_SYSROOT_DIR=str(sysroot),
        PKG_CONFIG_LIBDIR=os.pathsep.join(str(sysroot/path) for path in ('usr/lib/x86_64-linux-gnu/pkgconfig', 'usr/share/pkgconfig', 'usr/lib/pkgconfig')),
        LIBRARY_PATH=str(sysroot/'usr/lib/x86_64-linux-gnu'),
        LD_LIBRARY_PATH=str(sysroot/'usr/lib/x86_64-linux-gnu'),
        RUSTFLAGS='-C link-arg=-Wl,-rpath-link,'+str(sysroot/'usr/lib/x86_64-linux-gnu'),
        LP_GUI_USE_INSTALLED_DEPS='1',
        LP_GUI_TEST_CONFIG='src-tauri/tauri.test.conf.json',
        PYTHONDONTWRITEBYTECODE='1',
    )
    return env
