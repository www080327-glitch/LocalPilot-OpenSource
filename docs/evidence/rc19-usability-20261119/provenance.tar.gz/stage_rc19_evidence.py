#!/usr/bin/env python3
"""Snapshot this turn's text evidence without copying environments or artwork."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile


DIRECT_GROUPS = {
    "runtime": ["runtime"],
    "desktop-ui": ["ui"],
    "desktop-native": ["install", "install/linux"],
    "reviews": ["pet"],
}
EXPLICIT_GROUPS = {
    "provenance": [
        "PUBLIC_SOURCE_MAP.json",
        "source-publication.json",
        "source-publication-final.json",
        "stage_rc19_evidence.py",
    ],
    "runtime": [
        "runtime/check_rollback.py",
        "runtime/measure_long_turn.py",
        "runtime/rollback-case/candidate-create.json",
        "runtime/rollback-case/rc18-write.json",
        "runtime/rollback-case/candidate-reopen.json",
        "runtime/rollback-case/tasks.json",
        "runtime/long-turn-case-r2/measurements.json",
    ],
    "desktop-ui": [
        "ui/baseline-page/browser-tests.json",
        "ui/installed-browser/browser-tests.json",
    ],
    "desktop-native": [
        "install/linux/offline-release/offline-check.json",
        "install/linux/native_environment.py",
        "install/linux/installed-harness/run_installed.py",
    ],
}
SUMMARY_COPIES = {
    "PUBLIC_SOURCE_MAP.json": "PUBLIC_SOURCE_MAP.json",
    "ui/RESULTS.json": "UI_RESULTS.json",
    "pet/RESULTS.json": "PET_RESULTS.json",
    "pet/novice-review.json": "NOVICE_FLOW_REVIEW.json",
    "pet/runtime-final-delta-review.json": "RUNTIME_REVIEW.json",
    "runtime/RESULTS.json": "RUNTIME_RESULTS.json",
    "install/RESULTS.json": "INSTALL_RESULTS.json",
    "install/INSTALL_FINAL_RESULTS.json": "NATIVE_PACKAGE_RESULTS.json",
    "install/linux/NATIVE_GUI_LAUNCH.json": "NATIVE_GUI_RESULTS.json",
    "install/linux/RESULTS.json": "NATIVE_RESULTS.json",
}
EXCLUSIONS = [
    "All subdirectories except explicitly selected nested JSON receipts",
    "Repository clones and source snapshots (their JSON source manifests are included)",
    "Virtual environments, node_modules, Cargo, sysroots, downloaded packages and models",
    "Runtime SQLite databases, journals, lock files and generated bulk fixtures",
    "Personal artwork, artwork source archives, artwork manifests and private downloads",
    "Built apps, executables, wheels, DEBs, screenshots and other binary files",
    "Library upload helpers, build helpers and all unlisted Python scripts",
]
SECRET_PATTERNS = {
    "provider_key": r"\b(?:sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[A-Z0-9]{16})\b",
    "private_key": r"-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----",
    "credential_assignment": r"(?i)(?:authorization\s*[:=]\s*[\"']?bearer\s+|api[_-]?key\s*[:=]\s*[\"']?)([A-Za-z0-9_.-]{16,})",
    "url_credentials": r"://[^/\s:@]+:[^/\s@]+@",
    "signed_query": r"(?i)[?&](?:sig|X-Amz-Signature|access_token)=([^&\s\"'<>]+)",
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True, help="New snapshot directory; never overwritten")
    parser.add_argument("--phase", choices=["draft", "final"], default="draft")
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    groups, payloads = read_selection(root, output)
    credential_scan = scan_credentials(payloads)
    output.mkdir(parents=True)

    archives = []
    for group, names in sorted(groups.items()):
        path = output / f"{group}.tar.gz"
        write_archive(path, names, payloads)
        archives.append({
            "path": path.name,
            "bytes": path.stat().st_size,
            "sha256": digest(path.read_bytes()),
            "member_count": len(names),
            "members": [{"path": name, "bytes": len(payloads[name]), "sha256": digest(payloads[name])} for name in names],
        })

    standalone = []
    for source, name in SUMMARY_COPIES.items():
        if source in payloads:
            (output / name).write_bytes(payloads[source])
            standalone.append({"path": name, "source": source})

    summaries = {
        "LOG_SUMMARY.json": summarize_logs(payloads),
        "REVIEW_INDEX.json": review_index(payloads),
        "SANITIZATION.json": credential_scan,
    }
    for name, value in summaries.items():
        (output / name).write_bytes(json_bytes(value))
        standalone.append({"path": name, "generated": True})
    (output / "EVIDENCE_README.md").write_text(readme(args.phase), encoding="utf-8")
    standalone.append({"path": "EVIDENCE_README.md", "generated": True})
    for item in standalone:
        data = (output / item["path"]).read_bytes()
        item.update(bytes=len(data), sha256=digest(data))

    manifest = {
        "format": "localpilot-rc19-public-evidence-v1",
        "phase": args.phase,
        "source_map": json.loads(payloads["PUBLIC_SOURCE_MAP.json"]),
        "raw_member_count": len(payloads),
        "raw_member_bytes": sum(map(len, payloads.values())),
        "archive_count": len(archives),
        "archive_bytes": sum(item["bytes"] for item in archives),
        "selection": {"direct_text_directories": DIRECT_GROUPS, "direct_extensions": [".json", ".log", ".txt"], "explicit_files": EXPLICIT_GROUPS, "excluded": EXCLUSIONS},
        "transformations": [],
        "archives": archives,
        "standalone": standalone,
    }
    (output / "EVIDENCE_MANIFEST.json").write_bytes(json_bytes(manifest))
    checksummed = sorted(p for p in output.iterdir() if p.is_file())
    (output / "SHA256SUMS").write_text("".join(f"{digest(p.read_bytes())}  {p.name}\n" for p in checksummed), encoding="utf-8")
    print(json.dumps({"output": str(output), "phase": args.phase, "raw_members": len(payloads), "archives": len(archives), "archive_bytes": manifest["archive_bytes"], "credential_candidates": credential_scan["candidate_count"]}))


def read_selection(root: Path, output: Path) -> tuple[dict[str, list[str]], dict[str, bytes]]:
    if output.exists():
        raise SystemExit(f"Snapshot directory already exists: {output}")
    groups = {name: set(paths) for name, paths in EXPLICIT_GROUPS.items()}
    for group, directories in DIRECT_GROUPS.items():
        for directory in directories:
            groups.setdefault(group, set()).update(
                path.relative_to(root).as_posix()
                for path in (root / directory).iterdir()
                if path.is_file() and not path.is_symlink() and path.suffix in {".log", ".json", ".txt"}
            )
    payloads = {}
    for name in sorted({name for paths in groups.values() for name in paths}):
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise SystemExit(f"Selected evidence must be a regular file: {name}")
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        if (before.st_mtime_ns, before.st_size) != (after.st_mtime_ns, after.st_size):
            raise SystemExit(f"Evidence changed during snapshot; rerun after producer finishes: {name}")
        data.decode("utf-8")
        if b"\x00" in data:
            raise SystemExit(f"Binary content in selected text file: {name}")
        payloads[name] = data
    return {group: sorted(names) for group, names in groups.items()}, payloads


def scan_credentials(payloads: dict[str, bytes]) -> dict:
    candidates = []
    for name, data in payloads.items():
        text = data.decode("utf-8")
        for kind, pattern in SECRET_PATTERNS.items():
            for match in re.finditer(pattern, text):
                candidates.append({"path": name, "pattern": kind, "line": text.count("\n", 0, match.start()) + 1})
    if candidates:
        raise SystemExit("Inspect credential candidates before publication; no automatic redaction: " + json.dumps(candidates))
    return {
        "files_scanned": len(payloads),
        "patterns": list(SECRET_PATTERNS),
        "candidate_count": 0,
        "automatic_redaction": False,
        "transformations": [],
        "limitations": "Pattern screening plus explicit file selection; not a claim that arbitrary sensitive text can be detected automatically.",
    }


def write_archive(path: Path, names: list[str], payloads: dict[str, bytes]) -> None:
    with path.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, filename="", mode="wb", mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name in names:
                    data = payloads[name]
                    member = tarfile.TarInfo(name)
                    member.size = len(data)
                    member.mode = 0o644
                    member.mtime = 0
                    archive.addfile(member, io.BytesIO(data))


def summarize_logs(payloads: dict[str, bytes]) -> dict:
    records = []
    ansi = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
    for name, data in sorted(payloads.items()):
        if not name.endswith(".log"):
            continue
        text = ansi.sub("", data.decode("utf-8"))
        summaries = []
        for match in re.finditer(r"(?m)^Ran (\d+) tests? in ([\d.]+)s\s*\n\s*\n(OK|FAILED)(?: \(([^\n]+)\))?", text):
            counts = {key: int(value) for key, value in re.findall(r"(\w+)=(\d+)", match.group(4) or "")}
            ran = int(match.group(1))
            skipped = counts.get("skipped", 0)
            failures = counts.get("failures", 0)
            errors = counts.get("errors", 0)
            summaries.append({"framework": "unittest", "ran": ran, "skipped": skipped, "failures": failures, "errors": errors, "passed": ran - skipped - failures - errors, "result": match.group(3), "seconds": float(match.group(2)), "footer": match.group(0)})
        for match in re.finditer(r"(?m)^\s*Tests\s+(\d+) passed(?:[^\n]*)$", text):
            summaries.append({"framework": "vitest", "passed": int(match.group(1)), "footer": match.group(0).strip()})
        for match in re.finditer(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([\d.]+)s", text):
            summaries.append({"framework": "rust", "result": match.group(1), "passed": int(match.group(2)), "failed": int(match.group(3)), "ignored": int(match.group(4)), "footer": match.group(0)})
        node = {key: int(value) for key, value in re.findall(r"(?m)^(?:ℹ|#) (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$", text)}
        if node:
            summaries.append({"framework": "node", **node})
        records.append({"path": name, "bytes": len(data), "sha256": digest(data), "footers": summaries, "classification": "REPORTED_FOOTER" if summaries else "EMPTY_LOG" if not data else "NO_PARSED_TEST_FOOTER"})
    browsers = []
    for name, data in sorted(payloads.items()):
        if name.endswith("/browser-tests.json"):
            value = json.loads(data)
            browsers.append({"path": name, "stats": value.get("stats"), "top_level_errors": value.get("errors", []), "note": "Framework counts include browser-launch failures; consult UI_RESULTS.json for actual page assertions."})
    return {
        "scope": "Mechanical extraction of actual log footers; runs are not merged or added into a coverage total.",
        "limits": "No test footer or an empty typecheck log is not classified as PASS. A completed footer does not identify the source snapshot; use the source receipts. Original failures remain included.",
        "logs": records,
        "browser_reports": browsers,
    }


def review_index(payloads: dict[str, bytes]) -> dict:
    reviews = []
    for name, data in sorted(payloads.items()):
        if not name.endswith(".json") or "review" not in name.lower():
            continue
        value = json.loads(data)
        reviews.append({"path": name, "sha256": digest(data), **{key: value[key] for key in ("scope", "method", "status", "final_status", "findings") if key in value}})
    return {"scope": "Index of independent source/requirements reviews; these do not replace native or browser execution.", "reviews": reviews}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def readme(phase: str) -> str:
    return f"""# RC19 public evidence snapshot

Snapshot phase: **{phase.upper()}**. This archive is evidence, not a release-readiness assertion.

`EVIDENCE_MANIFEST.json` enumerates every raw member and archive with byte count and SHA256. `SHA256SUMS` covers every delivered file except itself. Original text bytes are preserved; `SANITIZATION.json` records screening and any transformations. No transformation was applied in this snapshot.

The five deterministic gzip archives group provenance, runtime, desktop UI, native/install and independent reviews. Archive member names are relative to the validation directory. `PUBLIC_SOURCE_MAP.json` identifies the tested local commits and matching public source trees. Earlier failures and results for older source snapshots remain present and must not be described as final-source passes.

`LOG_SUMMARY.json` extracts recorded test footers without summing different runs. `UI_RESULTS.json` distinguishes unit tests/build/collection/typecheck from blocked page execution. `NATIVE_PACKAGE_RESULTS.json` records package tests; `NATIVE_GUI_RESULTS.json` separately records the actual window launch. A log with no parsed footer, including a successful but empty typecheck log, needs its producer's result receipt. Browser launch failure does not count as a page assertion. Source review does not establish physical animation, dragging, device acceptance or novice usability.

The staging program is in `provenance.tar.gz` as `stage_rc19_evidence.py`. Given the original validation directory, rerun `python stage_rc19_evidence.py --root <validation-directory> --output <new-snapshot-directory> --phase {phase}`. It deliberately refuses to overwrite a snapshot. Use `sha256sum --check SHA256SUMS` in this directory before extracting.

Excluded: source clone contents; environments and toolchains; runtime databases and generated bulk fixtures; downloaded packages/models; built binaries; personal artwork and its metadata; unlisted helper scripts. Root-owned RESULTS, requirements and Work handoff documents are maintained separately.
"""


if __name__ == "__main__":
    main()
