from pathlib import Path
import argparse
import contextlib
import hashlib
import json
import platform
import subprocess
import sys
import time
import unittest

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--suite', choices=('core', 'companion', 'suite'), required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = args.source.resolve(strict=True)
out = args.output.resolve()
out.mkdir(parents=True, mode=0o700, exist_ok=False)
sys.path.insert(0, str(root))

def inventory():
    paths = set()
    for folder in ('agent', 'computer', 'localpilot_api', 'localpilot_service', 'localpilot_plugins',
                   'companion', 'channels', 'suite', 'tests', 'scripts'):
        for path in (root / folder).rglob('*'):
            if path.is_file() and path.suffix in ('.py', '.swift') and '__pycache__' not in path.parts:
                paths.add(path)
    for name in ('pyproject.toml', 'companion/pyproject.toml', 'suite/pyproject.toml',
                 'channels/pyproject.toml', 'MODULE_RELEASE.json', 'companion/MODULE_RELEASE.json',
                 'suite/MODULE_RELEASE.json'):
        paths.add(root / name)
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(paths)}

class EvidenceResult(unittest.TextTestResult):
    def __init__(self, *arguments, **options):
        super().__init__(*arguments, **options)
        self.records = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.records.append({'id': test.id(), 'status': 'PASS'})

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self.records.append({'id': test.id(), 'status': 'SKIP', 'reason': reason})

    def addFailure(self, test, error):
        super().addFailure(test, error)
        self.records.append({'id': test.id(), 'status': 'FAIL', 'detail': self._exc_info_to_string(error, test)})

    def addError(self, test, error):
        super().addError(test, error)
        self.records.append({'id': test.id(), 'status': 'ERROR', 'detail': self._exc_info_to_string(error, test)})

    def addExpectedFailure(self, test, error):
        super().addExpectedFailure(test, error)
        self.records.append({'id': test.id(), 'status': 'EXPECTED_FAILURE'})

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test)
        self.records.append({'id': test.id(), 'status': 'UNEXPECTED_SUCCESS'})

    def addSubTest(self, test, subtest, error):
        super().addSubTest(test, subtest, error)
        if error is not None:
            self.records.append({'id': subtest.id(), 'status': 'SUBTEST_FAILURE',
                                 'detail': self._exc_info_to_string(error, test)})

before = inventory()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
start = time.monotonic()
with (out / 'unittest.log').open('x') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
    if args.suite == 'suite':
        suite = unittest.defaultTestLoader.discover(str(root / 'suite/tests'))
    else:
        suite = unittest.defaultTestLoader.discover(str(root / ('tests' if args.suite == 'core' else 'companion/tests')),
                                                   top_level_dir=str(root))
    result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=EvidenceResult).run(suite)
elapsed = time.monotonic() - start
after = inventory()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
(out / 'tests.json').write_text(json.dumps(result.records, ensure_ascii=False, indent=2) + '\n')
passed_count = sum(row['status'] == 'PASS' for row in result.records)
report = {'suite': args.suite, 'git_head': head, 'git_status_before': status, 'python': platform.python_version(),
          'python_executable': sys.executable, 'tests_run': result.testsRun, 'passed': passed_count,
          'skipped': len(result.skipped), 'failures': len(result.failures), 'errors': len(result.errors),
          'expected_failures': len(result.expectedFailures), 'unexpected_successes': len(result.unexpectedSuccesses),
          'elapsed_seconds': elapsed, 'source_files': len(before), 'source_unchanged': before == after,
          'was_successful': result.wasSuccessful(), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
report['status'] = 'PASS_WITH_SKIPS' if result.wasSuccessful() and before == after and result.skipped else (
    'PASS' if result.wasSuccessful() and before == after else 'FAIL')
(out / 'run.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False), flush=True)
raise SystemExit(0 if report['status'].startswith('PASS') else 1)
