from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path('/workspace/scratch/c0f3ec78c621/LocalPilot-dispatch-20261117')
desktop = root / 'desktop'
run = Path('/workspace/scratch/c0f3ec78c621/validation/dispatch-20261117/scheduling') / sys.argv[1]
run.mkdir(exist_ok=False)
paths = [p for folder in ['src', 'tests'] for p in (desktop / folder).rglob('*') if p.is_file()]
paths += [p for p in desktop.iterdir() if p.is_file() and p.suffix in {'.json', '.ts'}]

def snapshot():
    return {str(p.relative_to(root)): {'bytes': p.stat().st_size,
                                      'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(set(paths))}

before = snapshot()
(run / 'SOURCE_BEFORE.json').write_text(json.dumps(before, indent=2) + '\n')
env = dict(os.environ, LP_UI_EVIDENCE_DIR=str(run / 'ui'))
browser = Path('/usr/bin/chromium')
if browser.is_file():
    env['LP_UI_CHROMIUM_EXECUTABLE'] = str(browser)
commands = {
    'unit': ['npm', 'test'],
    'build': ['npm', 'run', 'build'],
    'ui': ['npm', 'run', 'test:ui', '--', 'tests/ui/model-configuration.spec.ts',
           '--output', str(run / 'ui' / 'test-results')],
}
results = {}
for name, argv in commands.items():
    start = time.monotonic()
    with (run / (name + '.log')).open('wb') as stream:
        try:
            process = subprocess.run(argv, cwd=desktop, env=env, stdout=stream,
                                     stderr=subprocess.STDOUT, timeout=180)
            exit_code = process.returncode
        except subprocess.TimeoutExpired:
            exit_code = 'TIMEOUT'
    log = (run / (name + '.log')).read_text()
    result = {'argv': argv, 'exit_code': exit_code,
              'duration_seconds': time.monotonic() - start}
    if name == 'ui':
        result['chromium_executable'] = env.get('LP_UI_CHROMIUM_EXECUTABLE')
        result['status'] = ('PASS' if exit_code == 0 else 'BLOCKED'
                            if 'socket() failed: Operation not permitted' in log
                            else 'FAIL')
    else:
        result['status'] = 'PASS' if exit_code == 0 else 'FAIL'
    results[name] = result
    print(json.dumps({name: result}), flush=True)
    print('\n'.join(log.splitlines()[-15:]), flush=True)
after = snapshot()
(run / 'SOURCE_AFTER.json').write_text(json.dumps(after, indent=2) + '\n')
result = {'commands': results, 'files': len(before), 'source_unchanged': before == after,
          'source_changes': [p for p in before if before[p] != after.get(p)],
          'head_at_end': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
          'external_model_requests': 0, 'ui_backend': 'scripted bridge fixture, not native E2E'}
(run / 'RESULTS.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'commands'}), flush=True)
