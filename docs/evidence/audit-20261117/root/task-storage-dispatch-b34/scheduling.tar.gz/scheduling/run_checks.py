from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path('/workspace/scratch/c0f3ec78c621/LocalPilot-dispatch-20261117')
evidence = Path('/workspace/scratch/c0f3ec78c621/validation/dispatch-20261117/scheduling')
run = evidence / sys.argv[1]
run.mkdir(exist_ok=False)
paths = [p for folder in ['agent', 'localpilot_api', 'localpilot_service', 'suite/localpilot_suite']
         for p in (root / folder).rglob('*.py') if '__pycache__' not in p.parts]
paths += [root / p for p in ['tests/test_worker_role_routes.py', 'tests/test_cloud_local_partners.py',
                            'tests/test_local_http_backend.py', 'suite/tests/test_model_configuration.py']]
def snapshot():
    return {str(p.relative_to(root)): {'bytes': p.stat().st_size,
                                      'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(set(paths))}
before = snapshot()
(run / 'SOURCE_BEFORE.json').write_text(json.dumps(before, indent=2) + '\n')
env = dict(os.environ, PYTHONPATH=str(root / 'suite') + os.pathsep + str(root))
commands = {
    'core': [str(root / '.venv/bin/python'), '-m', 'unittest', 'tests.test_worker_role_routes',
             'tests.test_cloud_local_partners', '-v'],
    'suite': [str(root / '.venv/bin/python'), '-m', 'unittest', 'discover', '-s', 'suite/tests',
              '-p', 'test_model_configuration.py', '-v'],
}
results = {}
for name, argv in commands.items():
    start = time.monotonic()
    with (run / (name + '.log')).open('wb') as stream:
        process = subprocess.run(argv, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    log = (run / (name + '.log')).read_text()
    matches = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', log, re.MULTILINE)
    results[name] = {'argv': argv, 'exit_code': process.returncode,
                     'duration_seconds': time.monotonic() - start,
                     'unittest_summary': matches[-1] if matches else None}
    print(json.dumps({name: results[name]}), flush=True)
after = snapshot()
(run / 'SOURCE_AFTER.json').write_text(json.dumps(after, indent=2) + '\n')
result = {'status': 'PASS' if all(v['exit_code'] == 0 for v in results.values()) else 'FAIL',
          'commands': results, 'files': len(before), 'source_unchanged': before == after,
          'source_changes': [p for p in before if before[p] != after.get(p)],
          'head_at_end': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
          'external_model_requests': 0, 'provider_kind': 'scripted loopback HTTP, not a model'}
(run / 'RESULTS.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'commands'}), flush=True)
