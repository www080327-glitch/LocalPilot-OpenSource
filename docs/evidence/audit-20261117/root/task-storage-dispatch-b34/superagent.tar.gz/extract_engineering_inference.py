"""Export model/effort events from one stopped run without copying its database."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_directory', type=Path)
    args = parser.parse_args()
    run = args.run_directory.resolve()
    report = json.loads((run / 'RESULTS.json').read_text())
    task = json.loads((run / 'engineering-task.json').read_text())
    if report['owned_core_stopped'] is not True:
        raise ValueError('The owned Core must be stopped before immutable checkpoint inspection')
    database = run / 'core-private/data/runtime.sqlite3'
    before = hashlib.sha256(database.read_bytes()).hexdigest()
    connection = sqlite3.connect(database.as_uri() + '?mode=ro&immutable=1', uri=True)
    try:
        raw, checksum = connection.execute(
            'SELECT payload,sha256 FROM checkpoints WHERE session_id=?', (task['session_id'],)).fetchone()
    finally:
        connection.close()
    if hashlib.sha256(raw.encode()).hexdigest() != checksum:
        raise ValueError('Checkpoint payload checksum mismatch')
    runtime = json.loads(raw)['runtime']
    workers = {}
    for name, node in [('parent', runtime), *runtime['children'].items()]:
        events = [{'sequence': event['sequence'], 'timestamp': event['timestamp'],
                   'turn_id': event['turn_id'], **{key: event['data'][key]
                    for key in ('model', 'thinking', 'phase', 'role', 'primary')}}
                  for event in node['events'] if event['type'] == 'ModelRequestStarted']
        workers[name] = {'model_request_events': len(events),
            'models': sorted({event['model'] for event in events}),
            'thinking_efforts': sorted({event['thinking'] for event in events}), 'events': events}
    events = [event for worker in workers.values() for event in worker['events']]
    audit = {
        'version': 1, 'source_kind': 'Host ModelRequestStarted events in final durable checkpoint',
        'source_database_sha256': before, 'source_checkpoint_payload_sha256': checksum,
        'source_repository_commit': report['source']['git_head'],
        'source_query': 'SELECT payload,sha256 FROM checkpoints WHERE session_id=?',
        'database_read_only': True, 'database_exported': False,
        'model_request_events': len(events), 'expected_model': report['model'],
        'expected_thinking': report['reasoning'],
        'every_request_matches': all(event['model'] == report['model']
                                    and event['thinking'] == report['reasoning'] for event in events),
        'provider_reported_models': sorted({call['reported_model'] for call in task['result']['model_calls']}),
        'provider_model_calls': len(task['result']['model_calls']),
        'event_count_matches_calls': len(events) == len(task['result']['model_calls']),
        'workers': workers,
        'scope': 'These are actual host request events and provider-reported response models; reasoning effort is recorded by the host, not independently echoed by provider usage.',
    }
    if hashlib.sha256(database.read_bytes()).hexdigest() != before:
        raise RuntimeError('Database changed during inspection; no audit written')
    (run / 'INFERENCE_AUDIT.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: audit[key] for key in ('model_request_events', 'every_request_matches',
          'provider_reported_models', 'event_count_matches_calls', 'database_read_only', 'database_exported')}))


if __name__ == '__main__':
    main()
