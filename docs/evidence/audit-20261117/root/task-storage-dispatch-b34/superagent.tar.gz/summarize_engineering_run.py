"""Derive a bounded engineering summary without running models or acceptance.

Run with the completed qualification directory. Only POSTRUN_SUMMARY.json is
written; provider receipts and qualification verdicts remain authoritative.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path


RAW_INPUTS = (
    'RESULTS.json', 'engineering-task.json', 'RUN_EXECUTION.json',
    'external-unittest.json', 'external-cli.json', 'PROTOCOL.json',
    'resolved-inference.json',
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_directory', type=Path)
    args = parser.parse_args()
    directory = args.run_directory.resolve()
    originals = {name: (directory / name).read_bytes() for name in RAW_INPUTS}
    documents = {name: json.loads(data) for name, data in originals.items()}
    summary = summarize(documents)
    summary['provenance'] = {
        'processor': Path(__file__).name,
        'processor_sha256': digest(Path(__file__).read_bytes()),
        'raw_inputs_sha256': {name: digest(data) for name, data in originals.items()},
        'errors_extracted_from': 'engineering-task.json.tools[*].payload.error',
        'no_model_or_acceptance_execution': True,
    }
    if any((directory / name).read_bytes() != original for name, original in originals.items()):
        raise RuntimeError('Raw evidence changed during postprocessing; no summary written')
    destination = directory / 'POSTRUN_SUMMARY.json'
    destination.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({
        'output': str(destination), 'qualification_status': summary['status'],
        'product_task_outcome': summary['result_fields']['task_outcome'],
        'model_calls': summary['model_calls'], 'tool_receipts': summary['tool_receipts'],
        'failed_tool_receipt_count': summary['failed_tool_receipt_count'],
        'raw_inputs_unchanged': True, 'consistency': summary['consistency_checks'],
    }, ensure_ascii=False))


def digest(value):
    return hashlib.sha256(value).hexdigest()


def summarize(documents):
    report = documents['RESULTS.json']
    task = documents['engineering-task.json']
    execution = documents['RUN_EXECUTION.json']
    unit = documents['external-unittest.json']
    cli = documents['external-cli.json']
    result = task['result']
    orchestration = report['orchestration']
    calls, receipts = result['model_calls'], task['tools']
    checks = {child['id']: child for child in orchestration['children']}
    counts = Counter(row.get('worker_id') or 'parent' for row in receipts)
    children = [child_summary(child, checks[child['id']], counts[child['id']])
                for child in task['subagents']]
    failures = [failed_receipt(row, index) for index, row in enumerate(receipts)
                if row['status'] == 'failed']
    usage = {name: reported_total(calls, key) for name, key in (
        ('input_tokens', 'input_tokens'), ('output_tokens', 'output_tokens'),
        ('cached_input_tokens', 'prompt_cache_hit_tokens'),
        ('uncached_input_tokens', 'prompt_cache_miss_tokens'))}
    pair_overlaps = []
    for left, right in combinations(children, 2):
        a, b = left['lifecycle_interval'], right['lifecycle_interval']
        pair_overlaps.append({'children': [left['id'], right['id']],
            'seconds': max(0, min(a[1], b[1]) - max(a[0], b[0])) if a and b else None})
    completion = result['completion']
    return {
        'summary_version': 2,
        'model': report['model'], 'reasoning': report['reasoning'],
        'kind': report['kind'], 'scope': report['scope'],
        'status': report['engineering_status'],
        'status_source': 'RESULTS.json.engineering_status (external qualification verdict)',
        **{key: report[key] for key in ('protocol_status', 'orchestration_status', 'semantic_status')},
        'source_git_head': report['source']['git_head'],
        'source_manifest_sha256': report['source']['manifest_sha256'],
        'runner_sha256': report['source']['runner_sha256'],
        'configured_inference': documents['resolved-inference.json'],
        'model_run_seconds': report['model_run_seconds'],
        'outer_seconds': execution['elapsed_seconds'],
        'model_calls': len(calls),
        'model_call_scope': orchestration['model_call_scope'],
        'parent_model_calls': len(calls) - sum(child['model_calls'] for child in children),
        'model_attempts': result['runtime_metrics']['model_attempts'],
        'failed_model_attempts': result['runtime_metrics']['failed_attempts'],
        'incomplete_model_calls': [{'aggregate_index': index, **call} for index, call in enumerate(calls)
                                   if call['finish_reason'] not in ('stop', 'tool_calls')],
        'tool_receipts': len(receipts), 'receipt_counts_by_worker': dict(counts),
        'tool_proposals': result['total_tool_calls'],
        'unreceipted_tool_proposals': result['total_tool_calls'] - len(receipts),
        'receipt_counts_by_status': dict(Counter(row['status'] for row in receipts)),
        'failed_tool_receipt_count': len(failures), 'failed_tool_receipts': failures,
        **usage,
        'usage_scope': 'Provider-reported usage summed over aggregate model calls once; child calls are already included. Not a billing statement.',
        'usage_reporting_counts': {key: sum(type(call.get(key)) is int for call in calls)
            for key in ('input_tokens', 'output_tokens', 'prompt_cache_hit_tokens', 'prompt_cache_miss_tokens')},
        'aggregate_model_latency_seconds': result['model_latency_seconds'],
        'latency_scope': 'Sum over parent and child inference calls; concurrent intervals mean this is not wall-clock duration.',
        'async_lifecycle_overlap_seconds': orchestration['async_lifecycle_overlap_seconds'],
        'overlap_scope': orchestration['overlap_scope'],
        'child_pair_overlaps': pair_overlaps,
        'children': children,
        'parent_successful_shells': orchestration['parent_successful_shells'],
        'external_checks': {
            'unit': {key: unit[key] for key in ('tests_run', 'returncode', 'passed')},
            'cli_cases': {name: {key: case[key] for key in ('returncode', 'passed')}
                          for name, case in cli.items()},
            'cli_case_count': len(cli), 'cli_passed_count': sum(case['passed'] for case in cli.values()),
            'acceptance_passed': report['acceptance']['passed'],
            'parent_cli_artifact_matches': report['acceptance']['parent_cli_artifact_matches'],
            'original_acceptance_unchanged': report['original_acceptance_unchanged'],
        },
        'owned_core_stopped': report['owned_core_stopped'],
        'source_unchanged': report['source_unchanged'],
        'result_fields': {key: result[key] for key in (
            'status', 'runtime_status', 'deliverable_status', 'verification_status',
            'engineering_status', 'task_outcome', 'task_succeeded', 'verification')},
        'product_completion': {key: completion[key] for key in
            ('execution', 'delivery', 'attempts', 'receipt_count', 'obligations')},
        'verification_boundary': 'External synthetic engineering acceptance is separate from the product result. This summary preserves product verification/outcome fields and never upgrades not_run/unverified to verified.',
        'consistency_checks': {
            'aggregate_call_records_match': calls == orchestration['aggregate_model_calls'],
            'receipt_count_matches_product': len(receipts) == completion['receipt_count'],
            'tool_proposals_cover_receipts': result['total_tool_calls'] >= len(receipts),
            'child_projection_counts_match': all(child['receipt_count'] == child['parent_projected_receipt_count'] for child in children),
            'unit_count_matches_qualification': unit['tests_run'] == report['acceptance']['unit_test_count'],
            'cli_outcomes_match_qualification': {name: case['passed'] for name, case in cli.items()} == report['acceptance']['cli_cases'],
            'source_execution_fingerprints_match': execution['source_sha256_before'] == execution['source_sha256_after'],
            'source_qualification_fingerprints_match': report['source'] == report['source_after'],
        },
    }


def reported_total(calls, key):
    values = [call.get(key) for call in calls]
    return sum(values) if all(type(value) is int for value in values) else None


def failed_receipt(row, index):
    error = row['payload'].get('error', {})
    result = row['payload'].get('result', {})
    return {
        'receipt_index': index, 'receipt_id': row['receipt_id'], 'call_id': row['id'],
        'name': row['name'], 'worker_id': row.get('worker_id'), 'status': row['status'],
        'error_type': error.get('type'), 'error_message': error.get('message'),
        **({'error_fields': error['fields']} if 'fields' in error else {}),
        **{'result_' + key: result[key] for key in ('status', 'reason', 'exit_code') if key in result},
        **{key: result[key] for key in ('stage', 'action_sent', 'action_may_have_applied') if key in result},
        'side_effect_completed': row['side_effect_completed'],
    }


def child_summary(child, checks, projected_count):
    starts = [event['at'] for event in child['timeline'] if event['event'] == 'start']
    finishes = [event['at'] for event in child['timeline'] if event['event'] == 'completed']
    return {
        **{key: child[key] for key in ('id', 'status', 'async', 'collected',
            'configured_model', 'backend_id', 'tier', 'read_only', 'model_calls')},
        'receipt_count': len(child['receipts']), 'parent_projected_receipt_count': projected_count,
        'timeline': child['timeline'],
        'lifecycle_interval': [min(starts), max(finishes)] if starts and finishes else None,
        **{key: checks[key] for key in ('single_assigned_module', 'changed_paths',
            'test_class', 'tests_ran', 'completed', 'successful_shells')},
    }


if __name__ == '__main__':
    main()
