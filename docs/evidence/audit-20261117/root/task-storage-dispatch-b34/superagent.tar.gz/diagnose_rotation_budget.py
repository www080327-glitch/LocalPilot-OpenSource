"""Instrument the real rotation fixture without editing checked-out code."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--without-work-contract', action='store_true')
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(args.source))
    from agent import context_v5
    from agent.context_budget import context_tokens
    from tests.test_hybrid_history_rotation import HybridHistoryRotationTests

    watched = ['agent/context_v5.py', 'tests/test_hybrid_history_rotation.py']
    before = {name: hashlib.sha256((args.source / name).read_bytes()).hexdigest() for name in watched}
    observations = []
    original_transfer = context_v5.transfer
    original_host_state = context_v5.host_state
    if args.without_work_contract:
        def remove_contract(*positional, **keywords):
            state = original_host_state(*positional, **keywords)
            state.pop('work_contract', None)
            return state
        context_v5.host_state = remove_contract

    def observe(messages, tools, window, output_reserve, **kwargs):
        row = {'window': window, 'output_and_margin_reserve': output_reserve,
               'input_budget': window - output_reserve, 'source_message_count': len(messages),
               'has_work_contract': 'work_contract' in kwargs['working_state']}
        try:
            view, compacted = original_transfer(messages, tools, window, output_reserve, **kwargs)
        except Exception as error:
            row.update(error_type=type(error).__name__, error_message=str(error))
            observations.append(row)
            raise
        count = context_tokens(view, tools, tokenizer=kwargs.get('tokenizer'))
        row.update(admitted_input_tokens=count, compacted=compacted,
            original_input_tokens=compacted['original_estimated_units'] if compacted else count,
            admitted_message_count=len(view),
            exact_original_question_retained=any(m.content == 'Keep this exact original question.' for m in view))
        observations.append(row)
        return view, compacted

    context_v5.transfer = observe
    case = HybridHistoryRotationTests('test_zero_dispatch_turn_keeps_attempt_identity_after_rotation_commit_and_restart')
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.TestSuite([case]))
    after = {name: hashlib.sha256((args.source / name).read_bytes()).hexdigest() for name in watched}
    report = {'source': str(args.source), 'in_memory_counterfactual_removes_work_contract': args.without_work_contract,
              'test_passed': result.wasSuccessful(), 'source_unchanged': before == after,
              'source_sha256': before, 'transfer_observations': observations}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    args.output.with_suffix('.log').write_text(log.getvalue())
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
