import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import unittest

source = Path('/workspace/scratch/c0f3ec78c621/LocalPilot-dispatch-20261117')
out = Path('/workspace/scratch/c0f3ec78c621/validation/dispatch-20261117/superagent/targeted-r2')
out.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(source))
modules = ['tests.test_worker_role_runtime', 'tests.test_worker_role_responses',
           'tests.test_engineering_qualification', 'tests.test_worker_tiering',
           'tests.test_engine_v5', 'tests.test_hybrid_runtime', 'tests.test_v5_hybrid',
           'tests.test_context_v5', 'tests.test_async_runtime',
           'tests.test_adaptive_routing', 'tests.test_worker_role_routes']

def fingerprints():
    paths = sorted([*source.glob('agent/**/*.py'), *source.glob('localpilot_api/**/*.py'),
                    *source.glob('localpilot_service/**/*.py'),
                    source / 'scripts/qualify_openai_engineering.py',
                    *[source / (module.replace('.', '/') + '.py') for module in modules]])
    return {str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}

before = fingerprints()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
started = time.monotonic()
suite = unittest.TestLoader().loadTestsFromNames(modules)
with (out / 'unittest.log').open('w') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
after = fingerprints()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
report = {'command': [sys.executable, '-m', 'unittest', *modules, '-v'],
          'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip(),
          'source_unchanged': before == after, 'source_files': len(before),
          'tests': result.testsRun, 'passed': result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped),
          'failures': [{'test': str(test), 'traceback': trace} for test, trace in result.failures],
          'errors': [{'test': str(test), 'traceback': trace} for test, trace in result.errors],
          'skips': [{'test': str(test), 'reason': reason} for test, reason in result.skipped],
          'seconds': time.monotonic() - started,
          'status': 'PASS' if result.wasSuccessful() and before == after else 'FAIL'}
(out / 'RESULTS.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
sys.exit(0 if report['status'] == 'PASS' else 1)
