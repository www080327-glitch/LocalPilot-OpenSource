import argparse
import hashlib
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--phase', choices=['write', 'restore'], required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.source))

from agent.engine_v5 import EngineV5Policy
from agent.hybrid import CloudEgressPolicy, HybridPolicy
from agent.registry import create_default_registry
from agent.retry import RetryPolicy
from agent.session import AgentSession, SessionBudgets
from localpilot_api.service import TaskService, TaskRequest
from tests.test_runtime_api import Backend, answer, call

args.output.mkdir(parents=True, exist_ok=True)
work = args.output / 'workspace'
work.mkdir(exist_ok=True)
(work / 'fact.txt').write_text('VERSION-CONTINUITY-7319')
backend = Backend(*( [answer(None, call('read_file', {'path': 'fact.txt'}, 'first-read')),
                     answer('BASELINE-READ-7319')] if args.phase == 'write' else [answer('CANDIDATE-SECOND')] ))

def factory(callback):
    return AgentSession(create_default_registry(work, permission_mode='full-permission'),
        cloud_backend=backend, policy='cloud-only', streaming=False,
        engine_policy=EngineV5Policy(), retry_policy=RetryPolicy(max_attempts=1),
        hybrid_policy=HybridPolicy(CloudEgressPolicy('CLOUD_ALLOWED', ('fact.txt',))),
        hybrid_backends={'selected': backend}, hybrid_primary='selected', event_callback=callback,
        budgets=SessionBudgets(max_steps=12, max_tool_calls=12, max_token_units=4000000))

service = TaskService({'localpilot': factory}, persistence=args.output / 'runtime.sqlite3')
request = TaskRequest('Read fact.txt.', idempotency_key='original-once')
if args.phase == 'write':
    task = service.wait(service.create_task(request)['id'])
    assert task['status'] == 'completed', task.get('error')
    expected = {'id': task['id'], 'session_id': task['session_id'], 'result': task['result'], 'tools': task['tools']}
    (args.output / 'expected.json').write_text(json.dumps(expected, indent=2) + '\n')
    original_system = service.sessions[task['session_id']].runtime.messages[0].content
    (args.output / 'original-system.txt').write_text(original_system)
    result = {'phase': 'write', 'status': 'PASS', 'model_requests': len(backend.requests),
              'original_system_sha256': hashlib.sha256(original_system.encode()).hexdigest()}
    service.suspend()
else:
    expected = json.loads((args.output / 'expected.json').read_text())
    old = service.task_snapshot(expected['id'])
    assert old['result'] == expected['result'] and old['tools'] == expected['tools']
    assert service.create_task(request)['id'] == expected['id']
    assert len(backend.requests) == 0
    second = service.wait(service.create_task(TaskRequest('Continue in this same session.',
        session_id=expected['session_id'], idempotency_key='second-once'))['id'])
    assert second['status'] == 'completed', second.get('error')
    assert second['result']['text'] == 'CANDIDATE-SECOND'
    current = service.sessions[expected['session_id']].runtime
    assert current.messages[0].content == (args.output / 'original-system.txt').read_text()
    assert len(backend.requests) == 1
    result = {'phase': 'restore', 'status': 'PASS', 'old_result_and_receipts_exact': True,
              'old_idempotency_replayed': False, 'system_text_exact': True,
              'same_session_continued': True, 'model_requests_for_new_turn_only': 1,
              'worker_roles': current.worker_roles}
    service.shutdown()
(args.output / (args.phase + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
