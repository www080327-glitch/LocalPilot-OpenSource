"""Command-line interface for the CSV event-log summarizer."""

import argparse
import json
import sys

from .aggregate import summarize
from .parser import parse_records


class _ArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise ValueError(message)


def main(argv=None):
    parser = _ArgumentParser(description="Summarize a UTF-8 CSV event log.")
    parser.add_argument("input", metavar="INPUT", help="CSV input file")
    parser.add_argument("--output", metavar="PATH", help="write JSON to this file")
    try:
        args = parser.parse_args(argv)
        # Preserve CSV newlines, including those inside quoted fields.
        with open(args.input, encoding="utf-8", newline="") as source:
            records = parse_records(source.read())
        text = json.dumps(summarize(records), ensure_ascii=False) + "\n"
        # Do not open/truncate the destination until input validation succeeds.
        if args.output is not None:
            with open(args.output, "w", encoding="utf-8", newline="\n") as output:
                output.write(text)
        else:
            sys.stdout.write(text)
            sys.stdout.flush()
    except (OSError, UnicodeError, ValueError) as exc:
        message = " ".join(str(exc).splitlines())
        print(f"error: {message}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
