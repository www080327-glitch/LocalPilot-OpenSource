from collections.abc import Sequence
from datetime import timezone
from decimal import Decimal, MAX_EMAX, MIN_EMIN, localcontext

from .parser import Record


def summarize(records: Sequence[Record]) -> dict:
    """Summarize parsed records without changing their values or ordering."""
    if not records:
        return {"record_count": 0, "groups": []}

    # Parsed values have at most two decimal places. Reserve enough precision
    # for the largest value in hundredths plus every possible carry from adding
    # all records, rather than relying on Decimal's default 28-digit context.
    precision = max(max(record.value.adjusted() + 3, 2) for record in records)
    precision += len(str(len(records))) + 1
    groups = {}
    with localcontext() as context:
        context.prec = precision
        context.Emax = MAX_EMAX
        context.Emin = MIN_EMIN
        for record in records:
            timestamp = record.timestamp.astimezone(timezone.utc)
            if record.category not in groups:
                groups[record.category] = {
                    "category": record.category,
                    "count": 0,
                    "total": Decimal(0),
                    "first": timestamp,
                    "last": timestamp,
                }
            group = groups[record.category]
            group["count"] += 1
            group["total"] += record.value
            group["first"] = min(group["first"], timestamp)
            group["last"] = max(group["last"], timestamp)

        result = []
        for category in sorted(groups):
            group = groups[category]
            total = group["total"]
            group["total"] = format(total, ".2f") if total else "0.00"
            for field in ("first", "last"):
                group[field] = group[field].isoformat(timespec="seconds").replace("+00:00", "Z")
            result.append(group)

    return {"record_count": len(records), "groups": result}
