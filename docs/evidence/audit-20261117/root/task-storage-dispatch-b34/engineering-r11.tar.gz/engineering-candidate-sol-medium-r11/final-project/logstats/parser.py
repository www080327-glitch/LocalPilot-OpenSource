import csv
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from io import StringIO


@dataclass(frozen=True)
class Record:
    timestamp: datetime
    category: str
    value: Decimal


_TIMESTAMP = re.compile(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}"
    r"(?:Z|[+-](?:[01][0-9]|2[0-3]):[0-5][0-9])"
)
_VALUE = re.compile(r"[+-]?[0-9]+(?:\.[0-9]{1,2})?")


def _check_quotes(raw: str) -> None:
    """Reject quotes in unquoted fields, which csv.reader otherwise accepts."""
    quoted = False
    field_start = True
    index = 0
    while index < len(raw):
        char = raw[index]
        if quoted:
            if char == '"':
                if index + 1 < len(raw) and raw[index + 1] == '"':
                    index += 1
                else:
                    quoted = False
        elif char == ',':
            field_start = True
        elif char == '"':
            if not field_start:
                raise ValueError("quote inside an unquoted field")
            quoted = True
            field_start = False
        elif char not in '\r\n':
            field_start = False
        index += 1


def parse_records(text: str) -> list[Record]:
    """Parse CSV events, reporting the physical end line of each bad record."""
    stream = StringIO(text, newline="")
    reader = csv.reader(stream, strict=True)
    records = []
    have_header = False

    while True:
        start = stream.tell()
        try:
            fields = next(reader)
        except StopIteration:
            break
        except csv.Error as exc:
            raise ValueError(f"row {max(1, reader.line_num)}: {exc}") from exc

        raw = text[start:stream.tell()]
        # Only truly blank physical lines are ignorable, not CSV empty fields
        # such as ',,' or a quoted empty string.
        if not raw.strip():
            continue
        line = reader.line_num
        try:
            _check_quotes(raw)
            fields = [field.strip() for field in fields]
            if not have_header:
                if fields != ["timestamp", "category", "value"]:
                    raise ValueError("expected header timestamp,category,value")
                have_header = True
                continue
            if len(fields) != 3:
                raise ValueError("expected exactly three fields")
            timestamp_text, category, value_text = fields
            if not _TIMESTAMP.fullmatch(timestamp_text):
                raise ValueError("invalid timestamp; expected seconds and timezone")
            try:
                timestamp = datetime.fromisoformat(
                    timestamp_text.replace("Z", "+00:00")
                ).astimezone(timezone.utc)
            except (ValueError, OverflowError) as exc:
                raise ValueError("invalid calendar timestamp or UTC range") from exc
            if not category:
                raise ValueError("category must not be empty")
            if not _VALUE.fullmatch(value_text):
                raise ValueError("invalid decimal value")
            records.append(Record(timestamp, category, Decimal(value_text)))
        except ValueError as exc:
            raise ValueError(f"row {line}: {exc}") from exc

    if not have_header:
        raise ValueError("row 1: missing header timestamp,category,value")
    return records
