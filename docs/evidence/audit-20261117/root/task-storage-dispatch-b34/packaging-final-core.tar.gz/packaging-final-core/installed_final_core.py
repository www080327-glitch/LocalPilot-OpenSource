import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
import tomllib
import tarfile
import zipfile


ROOT = Path('/workspace/scratch/c0f3ec78c621/LocalPilot-dispatch-20261117')
OUT = Path('/workspace/scratch/c0f3ec78c621/validation/dispatch-20261117/packaging-final-core/r1')
OUT.mkdir(parents=True, exist_ok=False)
shutil.copyfile(__file__, OUT / 'runner.py')
WHEELS = OUT / 'wheels'
WHEELS.mkdir()
STAGE = OUT / 'source'
STAGE.mkdir()
(OUT / 'tmp').mkdir()
ENV = {k: v for k, v in os.environ.items() if k not in {'PYTHONPATH', 'PYTHONHOME', 'LOCALPILOT_SOURCE', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'DEEPSEEK_API_KEY'}}
ENV.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(OUT / 'tmp'))
EXPECTED = {'localpilot-agent-service': '5.0.0b34', 'localpilot-suite': '0.2.0b34',
            'localpilot-companion': '0.5.7b11', 'localpilot-channels': '0.1.0a4'}
DEPENDENCIES = ['psutil==7.2.2', 'pypdf==6.21.4', 'Pillow==12.3.0', 'defusedxml==0.7.1', 'watchdog==6.0.0']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes():
    candidates = set(subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT).decode().split('\0'))
    roots = {'agent', 'computer', 'localpilot_api', 'localpilot_service', 'localpilot_plugins',
             'localpilot_channels', 'companion', 'suite', 'channels', 'integrations', 'tests', 'scripts'}
    selected = {name for name in candidates if name and
                (Path(name).parts[0] in roots or name in {'catalog.py', 'recommender.py', 'hardware.py', 'selector_mlp.py', 'pyproject.toml'})
                and Path(name).suffix in {'.py', '.swift', '.mjs', '.json', '.toml'}
                and not set(Path(name).parts) & {'build', 'dist', 'node_modules', '__pycache__', 'evidence'}}
    for project in ('', 'companion', 'suite', 'channels'):
        path = ROOT / project / 'pyproject.toml'
        config = tomllib.loads(path.read_text())
        selected.add(str(path.relative_to(ROOT)))
        for files in config['tool']['setuptools'].get('data-files', {}).values():
            for name in files:
                selected.add(str((ROOT / ('' if project == 'channels' else project) / name).relative_to(ROOT)))
        for name in config['project'].get('license-files', []):
            selected.add(str((ROOT / ('' if project == 'channels' else project) / name).relative_to(ROOT)))
        for package, patterns in config['tool']['setuptools'].get('package-data', {}).items():
            package_path = ROOT / project / ('' if project == 'companion' and package == 'companion' else package.replace('.', '/'))
            for pattern in patterns:
                selected.update(str(file.relative_to(ROOT)) for file in package_path.glob(pattern) if file.is_file())
    return {name: sha(ROOT / name) for name in sorted(selected)}


record = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'source_dirty': bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()),
          'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'python': sys.version,
          'platform': platform.platform(), 'os_release': Path('/etc/os-release').read_text(),
          'build_tools': {name: importlib.metadata.version(name) for name in ('build', 'setuptools', 'wheel')},
          'expected_versions': EXPECTED, 'dependency_pins': DEPENDENCIES, 'commands': [],
          'real_model_calls': False, 'system_install': False, 'real_platform_accounts': False}
record['source_tree'] = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
assert record['source_commit'] == '3764fc054899d9fb3d13c545667e4ff0fc64d044'
assert record['source_tree'] == '6923f502896ebc565be54532e49107fd1bbd21d9'
assert not record['source_dirty']
before = source_hashes()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')


def run(command, log, cwd=ROOT, env=ENV):
    step = {'argv': list(map(str, command)), 'cwd': str(cwd), 'log': log,
            'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    record['commands'].append(step)
    started = time.monotonic()
    with (OUT / log).open('a') as output:
        output.write(json.dumps(list(map(str, command))) + '\n')
        output.flush()
        process = subprocess.run(list(map(str, command)), cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    step.update(exit_code=process.returncode, elapsed_seconds=time.monotonic() - started,
                end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT / 'PROGRESS.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'log':log,'exit_code':process.returncode,'seconds':step['elapsed_seconds']}), flush=True)
    process.check_returncode()


try:
    archive = OUT / 'source.tar'
    run(['git', 'archive', '--format=tar', '--output', archive, record['source_commit'], *before], 'stage.log')
    with tarfile.open(archive) as source:
        source.extractall(STAGE, filter='data')
    assert all(sha(STAGE / name) == value for name, value in before.items())
    record['stage'] = {'kind':'git archive of frozen source files and declared package data',
                       'files':len(before), 'archive_sha256':sha(archive), 'source_sha256_match':True}
    for project in ('.',):
        run([sys.executable, '-m', 'build', '--wheel', '--no-isolation', '--outdir', WHEELS, project], 'build.log', cwd=STAGE)
    wheels = sorted(WHEELS.glob('*.whl'))
    assert len(wheels) == 1
    original = ROOT.parent / 'validation/dispatch-20261117/packaging/r1'
    previous = json.loads((original / 'run.json').read_text())
    reused = [original / 'wheels' / row['file'] for row in previous['wheels'] if not row['file'].startswith('localpilot_agent_service-')]
    assert len(reused) == 3
    assert all(sha(path) == next(row['sha256'] for row in previous['wheels'] if row['file'] == path.name) for path in reused)
    wheels = sorted([*wheels, *reused])
    record['composition'] = {'built_core_commit':record['source_commit'], 'reused_other_components_commit':previous['source_commit'], 'reused_wheels_sha256_verified':True, 'original_evidence':'packaging/r1/run.json'}
    record['wheels'] = [{'file': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path), 'path':str(path), 'source_commit':record['source_commit'] if path.parent == WHEELS else previous['source_commit']} for path in wheels]
    runtime = OUT / 'runtime'
    run([sys.executable, '-m', 'venv', runtime], 'venv.log')
    python = runtime / 'bin/python'
    run([python, '-m', 'pip', '--disable-pip-version-check', 'install', '--no-input', *DEPENDENCIES], 'dependencies.log')
    run([python, '-m', 'pip', '--disable-pip-version-check', 'install', '--no-index', '--no-deps', *wheels], 'install.log')
    run([python, '-I', '-m', 'pip', 'check'], 'pip-check.log', cwd=OUT)
    probe = '''import importlib,importlib.metadata,inspect,json,pathlib,sys,sysconfig
modules={name:importlib.import_module(name).__file__ for name in ('agent','localpilot_service','localpilot_suite','localpilot_channels','companion','companion.memory.task_store')}
assert all(pathlib.Path(path).resolve().is_relative_to(sys.prefix) for path in modules.values())
names=('localpilot-agent-service','localpilot-suite','localpilot-companion','localpilot-channels','watchdog','psutil','pypdf','Pillow','defusedxml')
origins={name:json.loads(importlib.metadata.distribution(name).read_text('direct_url.json')) for name in names[:4]}
capabilities=importlib.import_module('localpilot_service.protocol').manifest()['capabilities']
assert 'worker_roles_v1' in capabilities
assert 'worker_roles' in inspect.signature(importlib.import_module('agent.session').AgentSession).parameters
print(json.dumps({'imports':modules,'versions':{name:importlib.metadata.version(name) for name in names},'wheel_origins':origins,'capabilities':capabilities,'service_version':importlib.import_module('localpilot_service').VERSION,'sqlite_schema':importlib.import_module('agent.persistence').SQLiteRuntimeStore.VERSION,'prefix':sys.prefix,'site':sysconfig.get_path('purelib'),'sys_path':sys.path},indent=2))
'''
    proof = json.loads(subprocess.check_output([python, '-I', '-c', probe], cwd=OUT, env=ENV, text=True))
    assert {name: proof['versions'][name] for name in EXPECTED} == EXPECTED
    assert proof['service_version'] == EXPECTED['localpilot-agent-service']
    assert proof['sqlite_schema'] == 3
    wheel_hashes = {path.name:sha(path) for path in wheels}
    from urllib.parse import unquote, urlsplit
    for origin in proof['wheel_origins'].values():
        installed_from = Path(unquote(urlsplit(origin['url']).path))
        assert installed_from in wheels
        assert origin['archive_info']['hashes']['sha256'] == wheel_hashes[installed_from.name]
        assert not origin.get('dir_info', {}).get('editable')
    (OUT / 'import-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
    run([python, '-I', '-m', 'localpilot_suite.cli', '--version'], 'cli-version.log', cwd=OUT)
    verified = {}
    verified_names = set()
    credential_file = Path('/workspace/scratch/c0f3ec78c621/private/openai-api-key')
    credential = credential_file.read_bytes().strip() if credential_file.is_file() else None
    for wheel in wheels:
        count = 0
        with zipfile.ZipFile(wheel) as archive:
            for name in archive.namelist():
                assert not name.endswith(('.sqlite3', '.sqlite', '.db', '.key')) and Path(name).name not in {'.env', 'credentials.json'}, ('private artifact path', wheel.name, name)
                if credential:
                    assert credential not in archive.read(name), ('known credential present', wheel.name, name)
                if name.endswith(('.py', '.swift')) and '.dist-info/' not in name and '.data/' not in name:
                    source = ROOT / ('suite' if name.startswith('localpilot_suite/') else '') / name
                    payload = archive.read(name)
                    assert source.read_bytes() == payload, ('source mismatch', name)
                    assert (Path(proof['site']) / name).read_bytes() == payload, ('installed mismatch', name)
                    count += 1
                    verified_names.add(name)
        verified[wheel.name] = count
    record['verified_installed_source_files_by_wheel'] = verified
    required_sources = {'agent/session.py', 'agent/runtime_tools.py', 'agent/session_history.py', 'agent/context_v5.py',
                        'localpilot_service/route_backends.py', 'localpilot_service/deployment.py',
                        'localpilot_service/protocol.py', 'localpilot_suite/model_configuration.py',
                        'companion/memory/task_store.py', 'companion/memory/store.py',
                        'companion/runtime/tasks.py', 'companion/runtime/service.py',
                        'companion/runtime/model_collaboration.py'}
    assert required_sources <= verified_names
    record['required_changed_sources_verified'] = sorted(required_sources)
    record['wheel_private_artifact_scan'] = {'known_credential_checked': bool(credential), 'matches': 0, 'forbidden_paths': 0}
    credential = None
    harness = OUT / 'harness'
    harness.mkdir()
    shutil.copytree(ROOT / 'tests', harness / 'tests', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    record['harness_kind'] = 'Existing Core tests copied without product Python packages; product imports verified under isolated runtime prefix'
    test_env = ENV
    command = [python, '-B', '-m', 'unittest', 'tests.test_worker_role_routes',
               'tests.test_hybrid_history_rotation', 'tests.test_context_v5',
               'tests.test_engine_v5', 'tests.test_worker_role_runtime', '-v']
    record['test_start_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    started = time.monotonic()
    run(command, 'tests.log', cwd=harness, env=test_env)
    record['test_elapsed_seconds'] = time.monotonic() - started
    record['test_end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process_probe = '''import json,os,psutil,sys
prefix=sys.prefix
owned=[]
for proc in psutil.process_iter(['pid','cmdline']):
    if proc.pid != os.getpid() and any(prefix in arg for arg in proc.info['cmdline'] or []):
        owned.append(proc.info['pid'])
print(json.dumps(owned))
'''
    owned = json.loads(subprocess.check_output([python, '-I', '-c', process_probe], cwd=OUT, env=ENV, text=True))
    record['remaining_owned_processes'] = owned
    assert not owned
    record['status'] = 'PASS'
except Exception as error:
    record.update(status='FAILED', failure=type(error).__name__, failure_message=str(error))
    raise
finally:
    after = source_hashes()
    (OUT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    record['source_commit_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    record['source_tree_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
    record['source_revision_unchanged'] = record['source_commit_after'] == record['source_commit'] and record['source_tree_after'] == record['source_tree']
    if record.get('status') == 'PASS' and (before != after or not record['source_revision_unchanged']):
        record['status'] = 'FAILED_SOURCE_CHANGED'
    record['source_files_verified'] = len(before)
    record['source_unchanged'] = before == after
    record['source_changes'] = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
    record['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record.get(key) for key in ('status', 'wheels', 'source_files_verified', 'source_unchanged', 'source_changes', 'test_elapsed_seconds', 'remaining_owned_processes')}))

if record['status'] != 'PASS':
    raise SystemExit(1)
