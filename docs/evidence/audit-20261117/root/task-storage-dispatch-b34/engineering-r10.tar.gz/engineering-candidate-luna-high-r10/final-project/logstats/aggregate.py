from collections.abc import Sequence
from datetime import timezone

from .parser import Record


def _cents(value) -> int:
    """Return a parsed two-decimal-place value as an exact integer of cents."""
    parts = value.as_tuple()
    coefficient = int("".join(str(digit) for digit in parts.digits) or "0")
    if parts.sign:
        coefficient = -coefficient
    # parse_records only creates values with at most two fractional digits.
    return coefficient * (10 ** (parts.exponent + 2))


def _format_cents(cents: int) -> str:
    sign = "-" if cents < 0 else ""
    whole, fraction = divmod(abs(cents), 100)
    return f"{sign}{whole}.{fraction:02d}"


def _utc_string(timestamp) -> str:
    timestamp = timestamp.astimezone(timezone.utc)
    return (
        f"{timestamp.year:04d}-{timestamp.month:02d}-{timestamp.day:02d}T"
        f"{timestamp.hour:02d}:{timestamp.minute:02d}:{timestamp.second:02d}Z"
    )


def summarize(records: Sequence[Record]) -> dict:
    """Summarize records by category without changing the input sequence."""
    groups = {}
    record_count = 0

    for record in records:
        record_count += 1
        group = groups.get(record.category)
        if group is None:
            groups[record.category] = {
                "count": 1,
                "cents": _cents(record.value),
                "first": record.timestamp,
                "last": record.timestamp,
            }
        else:
            group["count"] += 1
            group["cents"] += _cents(record.value)
            if record.timestamp < group["first"]:
                group["first"] = record.timestamp
            if record.timestamp > group["last"]:
                group["last"] = record.timestamp

    result_groups = []
    for category in sorted(groups):
        group = groups[category]
        result_groups.append({
            "category": category,
            "count": group["count"],
            "total": _format_cents(group["cents"]),
            "first": _utc_string(group["first"]),
            "last": _utc_string(group["last"]),
        })

    return {"record_count": record_count, "groups": result_groups}
