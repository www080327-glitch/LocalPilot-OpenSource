"""Repeat only the existing installed lifecycle checks blocked by fixture TMPDIR."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time


root = Path('/workspace/scratch/c0f3ec78c621/LocalPilot-dispatch-20261117')
base = root.parent / 'validation/dispatch-20261117/packaging'
first = base / 'r1'
out = base / 'verification-r2'
out.mkdir(exist_ok=False)
prior = json.loads((first / 'run.json').read_text())
source_names = json.loads((first / 'source-after.json').read_text())
runtime = first / 'runtime'
python = runtime / 'bin/python'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sources():
    return {name:sha(root / name) for name in source_names}

before = sources()
assert before == source_names
wheels = {row['file']:row['sha256'] for row in prior['wheels']}
assert all(sha(first / 'wheels' / name) == digest for name, digest in wheels.items())
env = {key:value for key,value in os.environ.items() if key not in
       {'PYTHONPATH', 'PYTHONHOME', 'LOCALPILOT_SOURCE', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'DEEPSEEK_API_KEY'}}
env.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1', TMPDIR='/tmp',
           LP_TEST_CHANNEL_WHEEL=str(first / 'wheels' / next(name for name in wheels if name.startswith('localpilot_channels-'))))
command = [str(python), '-B', '-m', 'unittest', 'tests.test_channel_suite_integration', '-v']
record = {'argv':command, 'cwd':str(first / 'harness'), 'start_utc':datetime.now(timezone.utc).isoformat(),
          'reason':'Five lifecycle tests failed before startup because the custom fixture TMPDIR inherited the /workspace 0777 ancestor. Reuse the existing system temporary-directory workflow without changing policy or source.',
          'fixture_tmpdir':'/tmp', 'source_commit':prior['source_commit'], 'wheels':wheels,
          'source_sha256_before':before, 'prior_failed_run':'r1/run.json'}
started = time.monotonic()
with (out / 'tests.log').open('w') as log:
    process = subprocess.run(command, cwd=first / 'harness', env=env, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_code=process.returncode, elapsed_seconds=time.monotonic() - started,
              end_utc=datetime.now(timezone.utc).isoformat())
log = (out / 'tests.log').read_text()
record['unittest_summary'] = re.findall(r'^Ran (\d+) tests in ([\d.]+)s$', log, re.MULTILINE)
after = sources()
record.update(source_sha256_after=after, source_unchanged=before==after,
              source_revision_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==prior['source_commit'],
              source_worktree_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip(),
              wheel_hashes_unchanged=all(sha(first / 'wheels' / name)==digest for name,digest in wheels.items()))
probe = '''import json,os,psutil,sys
owned=[]
for proc in psutil.process_iter(['pid','cmdline']):
    if proc.pid!=os.getpid() and any(sys.prefix in item for item in proc.info['cmdline'] or []):
        owned.append(proc.info['pid'])
print(json.dumps(owned))
'''
record['remaining_owned_processes'] = json.loads(subprocess.check_output([python,'-I','-c',probe],cwd=out,env=env,text=True))
record['status'] = 'PASS' if (process.returncode==0 and record['source_unchanged'] and record['source_revision_unchanged'] and record['wheel_hashes_unchanged'] and not record['remaining_owned_processes']) else 'FAIL'
(out / 'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:record[key] for key in ('status','exit_code','unittest_summary','elapsed_seconds','end_utc','source_unchanged','source_worktree_clean','remaining_owned_processes')}),flush=True)
print('\n'.join(log.splitlines()[-10:]),flush=True)
if record['status']!='PASS':
    raise SystemExit(1)
