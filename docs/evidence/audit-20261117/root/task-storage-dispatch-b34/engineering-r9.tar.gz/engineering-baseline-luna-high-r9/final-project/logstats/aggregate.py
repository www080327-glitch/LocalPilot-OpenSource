from collections.abc import Sequence
from datetime import timezone
from .parser import Record


def _utc_string(timestamp) -> str:
    """Format a UTC timestamp with a portable, four-digit year."""
    timestamp = timestamp.astimezone(timezone.utc)
    return (
        f"{timestamp.year:04d}-{timestamp.month:02d}-{timestamp.day:02d}T"
        f"{timestamp.hour:02d}:{timestamp.minute:02d}:{timestamp.second:02d}Z"
    )


def _total_string(coefficient: int, exponent: int) -> str:
    """Format an exact Decimal coefficient/exponent pair as cents."""
    # Parser-produced values have at most two fractional digits. If a caller
    # supplies finer precision directly, round the exact group total to cents
    # using Decimal's usual half-even rule, without context-limited arithmetic.
    cents_exponent = exponent + 2
    if cents_exponent >= 0:
        cents = coefficient * (10 ** cents_exponent)
    else:
        divisor = 10 ** (-cents_exponent)
        sign = -1 if coefficient < 0 else 1
        quotient, remainder = divmod(abs(coefficient), divisor)
        if 2 * remainder > divisor or (2 * remainder == divisor and quotient % 2):
            quotient += 1
        cents = sign * quotient

    sign = "-" if cents < 0 else ""
    whole, fractional = divmod(abs(cents), 100)
    return f"{sign}{whole}.{fractional:02d}"


def summarize(records: Sequence[Record]) -> dict:
    groups = {}
    record_count = 0

    for record in records:
        record_count += 1
        value = record.value
        value_tuple = value.as_tuple()
        value_coefficient = int("".join(map(str, value_tuple.digits)) or "0")
        if value_tuple.sign:
            value_coefficient = -value_coefficient
        value_exponent = value_tuple.exponent

        group = groups.get(record.category)
        if group is None:
            group = {
                "count": 0,
                "coefficient": 0,
                "exponent": value_exponent,
                "first": record.timestamp,
                "last": record.timestamp,
            }
            groups[record.category] = group

        # Keep the sum as an integer coefficient at the smallest exponent seen
        # so far. This avoids Decimal context rounding for arbitrarily large
        # aggregate totals.
        if value_exponent < group["exponent"]:
            group["coefficient"] *= 10 ** (group["exponent"] - value_exponent)
            group["exponent"] = value_exponent
        group["coefficient"] += value_coefficient * 10 ** (value_exponent - group["exponent"])
        group["count"] += 1
        if record.timestamp < group["first"]:
            group["first"] = record.timestamp
        if record.timestamp > group["last"]:
            group["last"] = record.timestamp

    result_groups = []
    for category in sorted(groups):
        group = groups[category]
        result_groups.append({
            "category": category,
            "count": group["count"],
            "total": _total_string(group["coefficient"], group["exponent"]),
            "first": _utc_string(group["first"]),
            "last": _utc_string(group["last"]),
        })

    return {"record_count": record_count, "groups": result_groups}
