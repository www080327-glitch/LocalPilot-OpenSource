import csv
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
import io
import re


@dataclass(frozen=True)
class Record:
    timestamp: datetime
    category: str
    value: Decimal


_HEADER = ("timestamp", "category", "value")
_TIMESTAMP_RE = re.compile(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:Z|[+-][0-9]{2}:[0-9]{2})"
)
_VALUE_RE = re.compile(r"[+-]?[0-9]+(?:\.[0-9]{1,2})?")


def _row_error(line: int, message: str) -> ValueError:
    return ValueError(f"row {max(line, 1)}: {message}")


def parse_records(text: str) -> list[Record]:
    # Keep the original physical lines available so blank whitespace-only lines can
    # be ignored without dropping line breaks inside quoted CSV fields.
    lines = list(io.StringIO(text, newline=""))
    reader = csv.reader(iter(lines), strict=True)
    previous_end = 0
    header_seen = False
    records: list[Record] = []

    while True:
        try:
            row = next(reader)
        except StopIteration:
            break
        except csv.Error as exc:
            raise _row_error(reader.line_num, f"invalid CSV: {exc}") from None

        line = reader.line_num
        physical_record = lines[previous_end:line]
        previous_end = line

        # csv.reader returns [] for an empty line, but not for a whitespace-only
        # one. Only ignore the latter when the source line itself contains no CSV
        # syntax (so a quoted whitespace field remains an invalid record/header).
        if not row or all(not source_line.strip() for source_line in physical_record):
            continue

        fields = [field.strip() for field in row]
        if not header_seen:
            if tuple(fields) != _HEADER:
                raise _row_error(line, "expected header timestamp,category,value")
            header_seen = True
            continue

        if len(fields) != 3:
            raise _row_error(line, "record must contain exactly three fields")

        timestamp_text, category, value_text = fields
        if not _TIMESTAMP_RE.fullmatch(timestamp_text):
            raise _row_error(line, "invalid timestamp")
        try:
            parsed_timestamp = datetime.fromisoformat(
                timestamp_text[:-1] + "+00:00" if timestamp_text.endswith("Z") else timestamp_text
            ).astimezone(timezone.utc)
        except (ValueError, OverflowError):
            raise _row_error(line, "invalid timestamp") from None

        if not category:
            raise _row_error(line, "category must not be empty")
        if not _VALUE_RE.fullmatch(value_text):
            raise _row_error(line, "invalid decimal value")
        try:
            value = Decimal(value_text)
        except Exception:
            raise _row_error(line, "invalid decimal value") from None

        records.append(Record(parsed_timestamp, category, value))

    if not header_seen:
        raise _row_error(1, "missing header")
    return records
