"""Compare real Companion HTTP/SQLite paths in separate source processes.

Run the same script and interpreter against RC16 and the candidate sequentially.
Seeding and the first open/migration are separate from the steady-state samples.
Each size has one actual scripted task; the additional history is synthetic.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time
import tracemalloc


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sources(root):
    return {str(path.relative_to(root)):digest(path.read_bytes())
            for folder in ('companion', 'agent', 'computer', 'localpilot_api', 'localpilot_service', 'tests')
            for path in sorted((root / folder).rglob('*.py')) if '__pycache__' not in path.parts}


def measure(app, action):
    action()
    times = []
    for _ in range(5):
        start = time.perf_counter()
        action()
        times.append((time.perf_counter() - start) * 1000)
    calls = {'full_task_map_selects':0, 'full_task_map_writes':0,
             'task_row_selects':0, 'task_row_writes':0}
    def trace(statement):
        if statement == "SELECT value FROM state WHERE key='localpilot_tasks'":
            calls['full_task_map_selects'] += 1
        if statement.startswith("INSERT OR REPLACE INTO state VALUES('localpilot_tasks',"):
            calls['full_task_map_writes'] += 1
        if statement.startswith('SELECT') and 'FROM localpilot_tasks' in statement:
            calls['task_row_selects'] += 1
        if statement.startswith('INSERT INTO localpilot_tasks'):
            calls['task_row_writes'] += 1
    app.store.db.set_trace_callback(trace)
    try:
        action()
    finally:
        app.store.db.set_trace_callback(None)
    tracemalloc.start()
    try:
        action()
        _, peak = tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()
    return {'elapsed_ms':times, 'median_ms':statistics.median(times),
            'peak_python_allocation_bytes_separate_sample':peak, **calls}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-storage', choices=('rows', 'json'), required=True)
    parser.add_argument('--counts', nargs='+', type=int, default=[1, 100, 1000, 10000])
    args = parser.parse_args()
    root, out = args.source_root.resolve(), args.output.resolve()
    out.mkdir(mode=0o700, parents=True, exist_ok=False)
    sys.path.insert(0, str(root))
    from companion.tests.test_v044_service import ServiceContractTests, request
    before = sources(root)
    report = {'source_root':str(root), 'git_head':subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
              'git_status_before':subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True),
              'source_sha256_before':before, 'python':platform.python_version(), 'python_executable':sys.executable,
              'platform':platform.platform(), 'storage':args.expected_storage, 'samples':[], 'external_model_calls':0,
              'scope':'One actual scripted task per history size through authenticated HTTP/SQLite; other tasks are synthetic copies. Five steady-state timing samples, SQL tracing and tracemalloc run separately. No model capability or universal latency claim.'}
    for count in args.counts:
        case = ServiceContractTests('test_native_submit_result_not_claimed_verified')
        case.setUp()
        try:
            app = case.host()
            row_storage = hasattr(app.store, 'tasks')
            assert row_storage == (args.expected_storage == 'rows')
            prepared = app.prepare_escalation(request('Synthetic public task for stored-history growth measurement'), mode='execution')
            first = app.command({'command':'submit_escalation', 'approved':True,
                'expected_digest':prepared['review_digest'], 'defer_monitor':True})
            task_id = first['task_id']
            case.service.wait(task_id)
            view = app.command({'command':'task_status', 'task_id':task_id})
            assert view['status'] == 'completed' and view['quiescent']
            seed = app.store.tasks.get(task_id) if row_storage else app.store.get('localpilot_tasks')[task_id]
            rows = {task_id:deepcopy(seed)}
            for index in range(1, count):
                item = deepcopy(seed)
                synthetic_id = f'synthetic-task-{index:08}'
                item['submission_id'] = f'synthetic-submission-{index:08}'
                item['timestamp'] = seed['timestamp'] - index
                for key in ('result', 'last_status', 'feedback'):
                    item[key]['task_id'] = synthetic_id
                for key in ('result', 'last_status'):
                    item[key]['session_id'] = f'synthetic-session-{index:08}'
                rows[synthetic_id] = item
            rows[task_id]['timestamp'] = seed['timestamp'] - count
            seed = rows[task_id]
            # Recreate the old on-disk representation in this disposable fixture.
            if row_storage:
                with app.store.db:
                    app.store.db.execute('DROP TABLE localpilot_tasks')
            app.store.set('localpilot_tasks', rows)
            legacy_bytes = len(app.store.db.execute("SELECT value FROM state WHERE key='localpilot_tasks'").fetchone()[0].encode())
            del rows
            app.channel.stop()
            app.store.close()
            app.lock.close()
            del case._cleanups[-3:]
            start = time.perf_counter()
            app = case.host()
            opened_ms = (time.perf_counter() - start) * 1000
            sample = {'stored_tasks':count, 'legacy_json_bytes':legacy_bytes,
                      'first_host_open_ms_including_migration':opened_ms}
            if row_storage:
                assert app.store.tasks.count() == count
                assert app.store.get('localpilot_tasks') is None
                assert app.store.tasks.get(task_id) == seed
                sample['migration_backup_bytes'] = app.store.tasks.backup_path.stat().st_size
                sample['migration_backup_sha256'] = digest(app.store.tasks.backup_path.read_bytes())
                sample['stored_payload_bytes'] = app.store.db.execute('SELECT sum(length(CAST(payload AS BLOB))) FROM localpilot_tasks').fetchone()[0]
            else:
                assert len(app.store.get('localpilot_tasks')) == count
                sample['stored_payload_bytes'] = legacy_bytes
            actions = {
                'provider_exact_lookup':lambda:app.provider_for_task(task_id),
                'receive_terminal_update':lambda:app.receive_task_update(task_id, deepcopy(view)),
                'task_status_real_http':lambda:app.command({'command':'task_status', 'task_id':task_id}),
                'escalation_status':lambda:app.command({'command':'escalation_status'}),
                'result_context_current':lambda:app.agent_tasks.result_context_current(task_id),
            }
            for label, action in actions.items():
                sample[label] = measure(app, action)
            assert app.agent_tasks.result_context_current(task_id)
            status = app.command({'command':'escalation_status'})
            assert status['total'] == count and len(status['tasks']) == min(count, 30)
            assert count <= 30 or task_id not in status['tasks']
            sample['escalation_status_json_bytes'] = len(json.dumps(status, ensure_ascii=False).encode())
            if status['next_before']:
                cursor = status['next_before']
                sample['escalation_older_page'] = measure(app, lambda:app.command({'command':'escalation_status', 'before':cursor}))
                next_page = app.command({'command':'escalation_status', 'before':cursor})
                assert not set(status['tasks']) & set(next_page['tasks'])
                sample['second_page_has_no_duplicate_ids'] = True
            current = app.command({'command':'task_status', 'task_id':task_id})
            assert current['task_id'] == task_id and current['session_id'] == first['session_id']
            assert len(case.backend.requests) == 1
            sample['scripted_backend_requests'] = 1
            sample['exact_old_task_identity_preserved'] = True
            report['samples'].append(sample)
            (out / 'PROGRESS.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
            print(json.dumps({'storage':args.expected_storage, 'stored_tasks':count,
                'status_ms':sample['task_status_real_http']['median_ms'],
                'status_peak_bytes':sample['task_status_real_http']['peak_python_allocation_bytes_separate_sample'],
                'whole_map_reads':sample['task_status_real_http']['full_task_map_selects'],
                'whole_map_writes':sample['task_status_real_http']['full_task_map_writes']}, ensure_ascii=False), flush=True)
        finally:
            case.doCleanups()
            case.tearDown()
    report['source_sha256_after'] = sources(root)
    report['source_unchanged'] = before == report['source_sha256_after']
    report['probe_sha256'] = digest(Path(__file__).read_bytes())
    report['passed'] = report['source_unchanged']
    (out / 'RESULTS.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    if not report['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
