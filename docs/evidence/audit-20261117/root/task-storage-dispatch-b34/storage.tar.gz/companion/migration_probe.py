"""Exercise actual RC16 reader, row migration, rollback backup and explicit clear."""
import argparse
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import types


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.source_root.resolve()
    out = args.output.resolve()
    out.mkdir(mode=0o700, parents=True, exist_ok=False)
    sys.path.insert(0, str(root))
    from companion.memory.store import MemoryStore
    from companion.memory.task_store import TaskStore
    baseline = 'c411dd1f92ad09e3b6e095acc96bc65c12107d5e'
    original = subprocess.check_output(['git', 'show', baseline + ':companion/memory/store.py'], cwd=root)
    reliability = subprocess.check_output(['git', 'show', baseline + ':companion/memory/reliability.py'], cwd=root)
    assert reliability == (root / 'companion/memory/reliability.py').read_bytes()
    module = types.ModuleType('companion.memory.rc16_store')
    module.__package__ = 'companion.memory'
    exec(compile(original, '<exact RC16 MemoryStore>', 'exec'), module.__dict__)
    db_path = out / 'private-memory.sqlite3'
    old = module.MemoryStore(db_path)
    records = {'old-task':{'timestamp':1, 'endpoint':'http://synthetic',
        'submission_id':'stable-original-key', 'last_event_cursor':23,
        'transport':{'provider_kind':'cloud', 'subject':'original-owner', 'scope':'consent'},
        'request':{'user_request':'原始未完成任务 🌱', 'relevant_memories':[]},
        'result':{'session_id':'original-session'}, 'last_status':{'status':'completed'}}}
    old.set('localpilot_tasks', records)
    memory_id = old.add('preference', 'Original synthetic preference', 'user')
    old.close()
    current = MemoryStore(db_path)
    backup = current.tasks.backup_path
    backup_sha = sha(backup.read_bytes())
    migrated = current.tasks.get('old-task')
    assert migrated == records['old-task']
    assert current.get('localpilot_tasks') is None
    assert current.db.execute('SELECT summary FROM memories WHERE id=?', (memory_id,)).fetchone()[0] == 'Original synthetic preference'
    current.tasks.put('new-task', {'timestamp':2, 'endpoint':'http://synthetic', 'submission_id':'new-key'})
    current.close()
    actual_old_reader = module.MemoryStore(db_path)
    direct_downgrade_result = actual_old_reader.get('localpilot_tasks')
    assert direct_downgrade_result is None
    actual_old_reader.close()
    restored_path = out / 'private-restored.sqlite3'
    with closing(sqlite3.connect(backup)) as source, closing(sqlite3.connect(restored_path)) as destination:
        source.backup(destination)
    restored = module.MemoryStore(restored_path)
    assert restored.get('localpilot_tasks') == records
    assert restored.db.execute('SELECT summary FROM memories WHERE id=?', (memory_id,)).fetchone()[0] == 'Original synthetic preference'
    restored.close()
    assert sha(backup.read_bytes()) == backup_sha
    current = MemoryStore(db_path)
    assert current.tasks.get('old-task') == records['old-task']
    assert current.tasks.get('new-task')['submission_id'] == 'new-key'
    assert current.tasks.backup_path is None
    current.clear(state={'observation_paused':True})
    assert current.tasks.count() == 0 and not backup.exists()
    current.close()
    current = MemoryStore(db_path)
    assert current.tasks.count() == 0
    current.close()
    report = {
        'status':'PASS_WITH_EXPLICIT_DOWNGRADE_LIMIT',
        'baseline_commit':baseline, 'baseline_store_sha256':sha(original),
        'current_store_sha256':sha((root / 'companion/memory/store.py').read_bytes()),
        'task_store_sha256':sha((root / 'companion/memory/task_store.py').read_bytes()),
        'original_record_and_other_memory_preserved':True,
        'legacy_map_removed_after_migration':True,
        'new_row_survives_reopen':True,
        'backup_sha256':backup_sha,
        'actual_old_reader_direct_new_database_result':direct_downgrade_result,
        'old_reader_rejects_new_schema':False,
        'actual_old_reader_after_backup_restore_exact_original_tasks':True,
        'actual_old_reader_after_backup_restore_other_memory_preserved':True,
        'backup_unchanged_by_restore':True,
        'explicit_clear_removes_rows_and_automatic_migration_backup':True,
        'clear_does_not_resurrect_tasks_on_reopen':True,
        'downgrade_policy':'Stop the service and restore the pre-migration SQLite backup. The old reader does not know the row table and cannot be used directly against an upgraded database. Restoring a backup excludes work created after that backup.',
        'scope':'Synthetic private databases only; actual RC16 source reader plus current MemoryStore implementation. No model calls or user data.',
    }
    (out / 'RESULTS.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
