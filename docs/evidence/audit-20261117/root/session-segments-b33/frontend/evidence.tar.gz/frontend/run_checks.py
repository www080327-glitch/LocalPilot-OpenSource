"""Run existing frontend/format/version gates without editing tracked sources."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path('<SOURCE_ROOT>')
OUT = Path(__file__).parent
RUST = Path('<PREVIOUS_VALIDATION_ROOT>/toolchain')
VERSION_INPUTS = [
    'scripts/check-candidate-versions.py', 'pyproject.toml', 'localpilot_service/__init__.py',
    'suite/pyproject.toml', 'suite/localpilot_suite/__init__.py',
    'companion/pyproject.toml', 'companion/__init__.py', 'desktop/package.json',
    'desktop/package-lock.json', 'desktop/src-tauri/tauri.conf.json', 'desktop/src-tauri/Cargo.toml',
    'MODULE_RELEASE.json', 'suite/MODULE_RELEASE.json', 'companion/MODULE_RELEASE.json',
    'README.md', 'desktop/README.md', 'suite/README.md', 'companion/README.md',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True).strip()


def inputs():
    paths = set(VERSION_INPUTS)
    for path in git('ls-files','desktop').splitlines():
        if not path.startswith('desktop/docs/'):
            paths.add(path)
    return {path:{'bytes':(ROOT/path).stat().st_size, 'sha256':sha((ROOT/path).read_bytes())}
            for path in sorted(paths)}


def run(name, args, cwd=ROOT, env=None):
    start = time.perf_counter()
    result = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = OUT/(name+'.log')
    log.write_bytes(result.stdout)
    record = {'name':name, 'argv':[str(arg) for arg in args], 'cwd':str(cwd), 'exit_code':result.returncode,
              'elapsed_seconds':time.perf_counter()-start, 'log':log.name, 'log_sha256':sha(result.stdout)}
    print(json.dumps({key:record[key] for key in ('name','exit_code','elapsed_seconds')}),flush=True)
    return record, result.stdout.decode(errors='replace')


def differences(before, after, path=''):
    if isinstance(before,dict) and isinstance(after,dict):
        result=[]
        for key in sorted(set(before)|set(after)):
            child=f'{path}/{key}'
            if key not in before or key not in after:
                result.append({'path':child,'before':before.get(key),'after':after.get(key)})
            else:
                result.extend(differences(before[key],after[key],child))
        return result
    return [] if before == after else [{'path':path,'before':before,'after':after}]


def main():
    original = inputs()
    report={'commit':git('rev-parse','HEAD'), 'tree':git('rev-parse','HEAD^{tree}'),
            'git_status_before':git('status','--short'), 'source_inputs_before':original,
            'checks':[], 'negative_controls':[],
            'scope':'Frontend unit tests, TypeScript/Vite build, Rust format only, version consistency including negative controls; no native compilation, Swift execution, browser page assertion or external model call.'}
    previous=json.loads(git('show','b9615c72db68bcf0ee065c884882b26d2cf0a581:desktop/package-lock.json'))
    current=json.loads((ROOT/'desktop/package-lock.json').read_text())
    delta=differences(previous,current)
    assert {item['path'] for item in delta} == {'/version','/packages//version'}
    assert all(item['before']=='5.0.1-rc.15' and item['after']=='5.0.1-rc.16' for item in delta)
    report['dependencies']={'node_modules_path':str((ROOT/'desktop/node_modules').resolve()),
        'installation':'Existing npm ci installation reused; no dependency install or source lockfile modification.',
        'lockfile_changes_from_rc15':delta,'dependency_graph_unchanged':True}
    rust_env=os.environ.copy()
    rust_env['CARGO_HOME']=str(RUST/'cargo')
    rust_env['RUSTUP_HOME']=str(RUST/'rustup')
    rust_env['PATH']=str(RUST/'cargo/bin')+os.pathsep+rust_env.get('PATH','')
    for name,args,cwd,env in (
        ('npm-test',['npm','test'],ROOT/'desktop',None),
        ('npm-build',['npm','run','build'],ROOT/'desktop',None),
        ('rustfmt-version',[str(RUST/'cargo/bin/rustfmt'),'--version'],ROOT,rust_env),
        ('cargo-fmt-check',[str(RUST/'cargo/bin/cargo'),'fmt','--manifest-path','src-tauri/Cargo.toml','--check'],ROOT/'desktop',rust_env),
        ('candidate-versions',[sys.executable,'scripts/check-candidate-versions.py'],ROOT,None),
    ):
        record,_=run(name,args,cwd,env)
        report['checks'].append(record)
    for label,path,constant,message in (
        ('companion-runtime-mismatch','companion/__init__.py','__version__','companion.__version__ differs from companion/pyproject.toml'),
        ('suite-runtime-mismatch','suite/localpilot_suite/__init__.py','VERSION','localpilot_suite.VERSION differs from suite/pyproject.toml'),
    ):
        with tempfile.TemporaryDirectory(prefix=label+'-',dir=OUT) as directory:
            case=Path(directory)
            for relative in VERSION_INPUTS:
                target=case/relative
                target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/relative,target)
            baseline,_=run(label+'-copy-baseline',[sys.executable,'scripts/check-candidate-versions.py'],case)
            assert baseline['exit_code']==0
            target=case/path
            old=target.read_text()
            changed,count=re.subn(r'^'+re.escape(constant)+r'\s*=.*$',constant+' = "0.0.0"',old,flags=re.MULTILINE)
            assert count==1 and changed!=old
            target.write_text(changed)
            changed_paths=[relative for relative in VERSION_INPUTS if (case/relative).read_bytes()!=(ROOT/relative).read_bytes()]
            assert changed_paths==[path]
            result,text=run(label,[sys.executable,'scripts/check-candidate-versions.py'],case)
            assert result['exit_code']!=0 and message in text
            report['negative_controls'].append({'name':label,'copied_positive_baseline':baseline,
                'negative_result':result,'only_changed_input':path,'original_sha256':sha(old.encode()),
                'altered_sha256':sha(changed.encode()),'expected_diagnostic':message,
                'checker_sha256':sha((case/'scripts/check-candidate-versions.py').read_bytes()),
                'temporary_copy_removed_on_exit':True})
    report['source_inputs_after']=inputs()
    report['source_unchanged']=original==report['source_inputs_after']
    report['git_status_after']=git('status','--short')
    report['helper_sha256']=sha(Path(__file__).read_bytes())
    report['status']='PASS' if report['source_unchanged'] and all(check['exit_code']==0 for check in report['checks']) else 'FAIL'
    (OUT/'RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (OUT/'MANIFEST.json').write_text(json.dumps({'files':{path.name:{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
        for path in sorted(OUT.iterdir()) if path.is_file() and path.name not in ('MANIFEST.json','run.log')}},indent=2)+'\n')
    print(json.dumps({'status':report['status'],'source_unchanged':report['source_unchanged'],
                      'source_inputs':len(original),'negative_controls':len(report['negative_controls'])}),flush=True)
    return 0 if report['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
