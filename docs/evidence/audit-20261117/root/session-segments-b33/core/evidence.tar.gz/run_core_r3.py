import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import time

root = Path('<FINAL_REGRESSION_SOURCE_ROOT>')
out = Path('<VALIDATION_ROOT>/core-full-r3')
out.mkdir(exist_ok=False)
python = '<PINNED_TEST_ENVIRONMENT>/.venv/bin/python'

def sources():
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for directory in ('agent', 'localpilot_api', 'localpilot_service', 'tests', 'computer')
            for path in sorted((root / directory).rglob('*.py'))}

before = sources()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
command = [python, '-B', 'scripts/aic_test.py', '--output', str(out / 'tests.json')]
record = {'command': command, 'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
          'source_dirty': bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()),
          'platform': platform.platform(), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'live_model_calls': False}
start = time.monotonic()
with (out / 'unittest.log').open('w') as log:
    result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
after = sources()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
record.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start,
              source_unchanged=before == after, source_files=len(before),
              source_changes=[name for name in before.keys() | after.keys() if before.get(name) != after.get(name)])
if (out / 'tests.json').exists():
    data = json.loads((out / 'tests.json').read_text())
    record.update({name: data[name] for name in ('tests_run', 'failures', 'errors', 'skips', 'successful')})
    record['passes'] = sum(item['status'] == 'PASS' for item in data['records'])
record['status'] = 'PASS_WITH_DECLARED_SKIPS' if result.returncode == 0 and before == after else 'FAIL'
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode or int(before != after))
