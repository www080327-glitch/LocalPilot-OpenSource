import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import time

root = Path('<SOURCE_ROOT>')
validation = Path('<VALIDATION_ROOT>')
out = validation / 'suite-r1'
out.mkdir(exist_ok=False)
shutil.copyfile(__file__, out / 'runner.py')
python = validation / 'installed-r1/runtime/bin/python'
selected = json.loads((validation / 'installed-r1/source-before.json').read_text())
def sources():
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in selected}
before = sources()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
env = {key:value for key,value in os.environ.items() if key not in {
    'PYTHONPATH', 'PYTHONHOME', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'DEEPSEEK_API_KEY'}}
env.update(PYTHONPATH=str(root / 'suite'), PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
command = [str(python), '-B', '-m', 'unittest', 'discover', '-s', 'suite/tests', '-v']
proof_code = '''import agent,companion,localpilot_suite,localpilot_service,platform,sys,json
from agent.persistence import SQLiteRuntimeStore
print(json.dumps({'python':sys.version,'platform':platform.platform(),'sqlite_schema':SQLiteRuntimeStore.VERSION,'service_version':localpilot_service.VERSION,'imports':{m.__name__:m.__file__ for m in (agent,companion,localpilot_suite,localpilot_service)}}))
'''
proof = json.loads(subprocess.check_output([python, '-B', '-c', proof_code], cwd=root, env=env, text=True))
assert proof['service_version'] == '5.0.0b33' and proof['sqlite_schema'] == 3
assert all(Path(path).is_relative_to(root) for path in proof['imports'].values())
record = {'command':command,'cwd':str(root),'test_pythonpath':env['PYTHONPATH'], 'environment':proof,
          'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
          'source_dirty':bool(subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()),
          'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'real_model_calls':False,'system_install':False,'native_macos_acceptance':False}
record['source_tree'] = subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
assert record['source_commit'] == 'b6f95da47f706581a780d6874382be53d99b33c4'
assert record['source_tree'] == '36d464811bbfd9538274d88bd2c13fbcf80374be'
assert not record['source_dirty']
started = time.monotonic()
with (out / 'suite-full.log').open('w') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode, elapsed_seconds=time.monotonic()-started,
              end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
text = (out / 'suite-full.log').read_text()
summary = re.search(r'Ran (\d+) tests in ([\d.]+)s',text)
record['tests_run'] = int(summary[1]) if summary else None
record['unittest_seconds'] = float(summary[2]) if summary else None
record['warnings'] = [line for line in text.splitlines() if 'Warning:' in line or 'ResourceWarning' in line]
record['skipped'] = [line for line in text.splitlines() if ' ... skipped ' in line]
record['passed'] = sum(line.rstrip().endswith(' ... ok') for line in text.splitlines())
after = sources()
(out / 'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
record['source_commit_after'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
record['source_tree_after'] = subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
record['source_revision_unchanged'] = record['source_commit_after'] == record['source_commit'] and record['source_tree_after'] == record['source_tree']
record['source_files_verified'] = len(before)
record['source_unchanged'] = before == after
record['source_changes'] = [name for name in before if before[name] != after[name]]
record['status'] = 'PASS_WITH_DECLARED_SKIP' if result.returncode == 0 and before == after and record['source_revision_unchanged'] else 'FAILED'
(out / 'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
raise SystemExit(result.returncode or (1 if before != after or not record['source_revision_unchanged'] else 0))
