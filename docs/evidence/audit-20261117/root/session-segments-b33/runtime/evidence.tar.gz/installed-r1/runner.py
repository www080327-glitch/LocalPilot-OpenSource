import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
import tomllib
import zipfile


ROOT = Path('<SOURCE_ROOT>')
OUT = Path('<VALIDATION_ROOT>/installed-r1')
OUT.mkdir(parents=True, exist_ok=False)
shutil.copyfile(__file__, OUT / 'runner.py')
WHEELS = OUT / 'wheels'
WHEELS.mkdir()
ENV = {k: v for k, v in os.environ.items() if k not in {'PYTHONPATH', 'PYTHONHOME', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'DEEPSEEK_API_KEY'}}
ENV.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
EXPECTED = {'localpilot-agent-service': '5.0.0b33', 'localpilot-suite': '0.2.0b33',
            'localpilot-companion': '0.5.7b10', 'localpilot-channels': '0.1.0a4'}
DEPENDENCIES = ['psutil==7.2.2', 'pypdf==6.21.4', 'Pillow==12.3.0', 'defusedxml==0.7.1', 'watchdog==6.0.0']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes():
    candidates = set(subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT).decode().split('\0'))
    roots = {'agent', 'computer', 'localpilot_api', 'localpilot_service', 'localpilot_plugins',
             'localpilot_channels', 'companion', 'suite', 'channels', 'integrations', 'tests', 'scripts'}
    selected = {name for name in candidates if name and
                (Path(name).parts[0] in roots or name in {'catalog.py', 'recommender.py', 'hardware.py', 'selector_mlp.py', 'pyproject.toml'})
                and Path(name).suffix in {'.py', '.swift', '.mjs', '.json', '.toml'}
                and not set(Path(name).parts) & {'build', 'dist', 'node_modules', '__pycache__', 'evidence'}}
    for project in ('', 'companion', 'suite', 'channels'):
        path = ROOT / project / 'pyproject.toml'
        config = tomllib.loads(path.read_text())
        selected.add(str(path.relative_to(ROOT)))
        for files in config['tool']['setuptools'].get('data-files', {}).values():
            for name in files:
                selected.add(str((ROOT / ('' if project == 'channels' else project) / name).relative_to(ROOT)))
        for name in config['project'].get('license-files', []):
            selected.add(str((ROOT / ('' if project == 'channels' else project) / name).relative_to(ROOT)))
    return {name: sha(ROOT / name) for name in sorted(selected)}


record = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'source_dirty': bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()),
          'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'python': sys.version,
          'platform': platform.platform(), 'os_release': Path('/etc/os-release').read_text(),
          'build_tools': {name: importlib.metadata.version(name) for name in ('build', 'setuptools', 'wheel')},
          'expected_versions': EXPECTED, 'dependency_pins': DEPENDENCIES, 'commands': [],
          'real_model_calls': False, 'system_install': False, 'real_platform_accounts': False}
record['source_tree'] = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
assert record['source_commit'] == 'b6f95da47f706581a780d6874382be53d99b33c4'
assert record['source_tree'] == '36d464811bbfd9538274d88bd2c13fbcf80374be'
assert not record['source_dirty']
before = source_hashes()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')


def run(command, log, cwd=ROOT, env=ENV):
    record['commands'].append({'argv': list(map(str, command)), 'cwd': str(cwd), 'log': log})
    with (OUT / log).open('a') as output:
        output.write(json.dumps(list(map(str, command))) + '\n')
        output.flush()
        subprocess.run(list(map(str, command)), cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, check=True)


try:
    for project in ('.', 'companion', 'suite'):
        run([sys.executable, '-m', 'build', '--wheel', '--no-isolation', '--outdir', WHEELS, project], 'build.log')
    run([sys.executable, 'scripts/build_channels_wheel.py', '--no-isolation', '--out', WHEELS], 'build.log')
    wheels = sorted(WHEELS.glob('*.whl'))
    assert len(wheels) == 4
    record['wheels'] = [{'file': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path)} for path in wheels]
    runtime = OUT / 'runtime'
    run([sys.executable, '-m', 'venv', runtime], 'venv.log')
    python = runtime / 'bin/python'
    run([python, '-m', 'pip', '--disable-pip-version-check', 'install', '--no-input', *DEPENDENCIES], 'dependencies.log')
    run([python, '-m', 'pip', '--disable-pip-version-check', 'install', '--no-index', '--no-deps', *wheels], 'install.log')
    run([python, '-I', '-m', 'pip', 'check'], 'pip-check.log', cwd=OUT)
    probe = '''import importlib,importlib.metadata,json,pathlib,sys,sysconfig
modules={name:importlib.import_module(name).__file__ for name in ('agent','localpilot_service','localpilot_suite','localpilot_channels','companion')}
assert all(pathlib.Path(path).resolve().is_relative_to(sys.prefix) for path in modules.values())
names=('localpilot-agent-service','localpilot-suite','localpilot-companion','localpilot-channels','watchdog','psutil','pypdf','Pillow','defusedxml')
print(json.dumps({'imports':modules,'versions':{name:importlib.metadata.version(name) for name in names},'service_version':importlib.import_module('localpilot_service').VERSION,'sqlite_schema':importlib.import_module('agent.persistence').SQLiteRuntimeStore.VERSION,'prefix':sys.prefix,'site':sysconfig.get_path('purelib'),'sys_path':sys.path},indent=2))
'''
    proof = json.loads(subprocess.check_output([python, '-I', '-c', probe], cwd=OUT, env=ENV, text=True))
    assert {name: proof['versions'][name] for name in EXPECTED} == EXPECTED
    assert proof['service_version'] == EXPECTED['localpilot-agent-service']
    assert proof['sqlite_schema'] == 3
    (OUT / 'import-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
    run([python, '-I', '-m', 'localpilot_suite.cli', '--version'], 'cli-version.log', cwd=OUT)
    verified = {}
    verified_names = set()
    credential_file = Path('<PRIVATE_KEY_FILE>')
    credential = credential_file.read_bytes().strip() if credential_file.is_file() else None
    for wheel in wheels:
        count = 0
        with zipfile.ZipFile(wheel) as archive:
            for name in archive.namelist():
                assert not name.endswith(('.sqlite3', '.sqlite', '.db', '.key')) and Path(name).name not in {'.env', 'credentials.json'}, ('private artifact path', wheel.name, name)
                if credential:
                    assert credential not in archive.read(name), ('known credential present', wheel.name, name)
                if name.endswith(('.py', '.swift')) and '.dist-info/' not in name and '.data/' not in name:
                    source = ROOT / ('suite' if name.startswith('localpilot_suite/') else '') / name
                    payload = archive.read(name)
                    assert source.read_bytes() == payload, ('source mismatch', name)
                    assert (Path(proof['site']) / name).read_bytes() == payload, ('installed mismatch', name)
                    count += 1
                    verified_names.add(name)
        verified[wheel.name] = count
    record['verified_installed_source_files_by_wheel'] = verified
    required_sources = {'agent/session_history.py', 'agent/persistence.py', 'agent/hybrid.py', 'localpilot_api/service.py', 'companion/runtime/tasks.py'}
    assert required_sources <= verified_names
    record['required_changed_sources_verified'] = sorted(required_sources)
    record['wheel_private_artifact_scan'] = {'known_credential_checked': bool(credential), 'matches': 0, 'forbidden_paths': 0}
    credential = None
    harness = OUT / 'harness'
    harness.mkdir()
    shutil.copytree(ROOT / 'tests', harness / 'tests', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    shutil.copytree(runtime / 'share/localpilot/channels', harness / 'integrations')
    record['harness_kind'] = 'Existing tests copied without product Python packages; channel assets from installed wheel; imports verified under isolated runtime prefix'
    test_env = {**ENV, 'LP_TEST_CHANNEL_WHEEL': str(next(path for path in wheels if path.name.startswith('localpilot_channels-')))}
    command = [python, '-B', '-m', 'unittest', 'tests.test_channel_suite_diagnostics', 'tests.test_channel_suite_integration', '-v']
    record['test_start_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    started = time.monotonic()
    run(command, 'tests.log', cwd=harness, env=test_env)
    record['test_elapsed_seconds'] = time.monotonic() - started
    record['test_end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    import psutil
    owned = []
    for proc in psutil.process_iter(['pid', 'cmdline']):
        args = proc.info['cmdline'] or []
        if any(str(runtime) in item for item in args):
            owned.append(proc.info['pid'])
    record['remaining_owned_processes'] = owned
    assert not owned
    record['status'] = 'PASS'
except Exception as error:
    record.update(status='FAILED', failure=type(error).__name__, failure_message=str(error))
    raise
finally:
    after = source_hashes()
    (OUT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    record['source_commit_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    record['source_tree_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
    record['source_revision_unchanged'] = record['source_commit_after'] == record['source_commit'] and record['source_tree_after'] == record['source_tree']
    if record.get('status') == 'PASS' and (before != after or not record['source_revision_unchanged']):
        record['status'] = 'FAILED_SOURCE_CHANGED'
    record['source_files_verified'] = len(before)
    record['source_unchanged'] = before == after
    record['source_changes'] = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
    record['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record.get(key) for key in ('status', 'wheels', 'source_files_verified', 'source_unchanged', 'source_changes', 'test_elapsed_seconds', 'remaining_owned_processes')}))

if record['status'] != 'PASS':
    raise SystemExit(1)
