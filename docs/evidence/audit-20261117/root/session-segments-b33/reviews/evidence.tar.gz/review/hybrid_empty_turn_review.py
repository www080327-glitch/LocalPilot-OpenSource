"""Actual pre-dispatch context failure followed by a rotated Hybrid turn."""
from pathlib import Path
import hashlib
import json
import sys
import tempfile

ROOT = Path('<SOURCE_ROOT>')
OUTPUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from agent.backends import ModelInfo
from agent.engine_v5 import EngineV5Policy
from agent.hybrid import HybridPolicy, CloudEgressPolicy
from agent.registry import ToolRegistry
from agent.session import AgentSession, SessionBudgets
from localpilot_api.service import TaskService, TaskRequest
from tests.test_runtime_api import Backend, answer


def main():
    report = {
        'source_hashes': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in (
            'agent/hybrid.py', 'agent/session_history.py', 'localpilot_api/service.py')},
        'external_model_calls': 0,
        'turns': [],
    }
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        workspace = root / 'workspace'
        workspace.mkdir()
        backend = Backend(answer('first'), answer('third'))
        backend.model_info = ModelInfo('small-model', 'scripted', 3000)
        backend.service_cache_stable_prefix = True
        def factory(callback):
            return AgentSession(ToolRegistry(workspace), backend=backend, policy='cloud-only',
                streaming=False, event_callback=callback, system_prompt='Complete the request.',
                runtime_tools=False, engine_policy=EngineV5Policy(max_completion_repairs=0),
                hybrid_policy=HybridPolicy(CloudEgressPolicy('CLOUD_ALLOWED')),
                hybrid_backends={'selected': backend}, hybrid_primary='selected',
                budgets=SessionBudgets(max_steps=12, max_token_units=1000000, max_output_tokens=256))
        service = TaskService({'localpilot': factory}, persistence=root / 'runtime.sqlite3',
                              history_rotation_bytes=1)
        sid = None
        for text in ('first question', 'Z' * 4000, 'third question'):
            task = service.wait(service.create_task(TaskRequest(text, session_id=sid))['id'])
            sid = task['session_id']
            session = service.sessions[sid]
            runtime = session.runtime
            report['turns'].append({
                'status': task['status'], 'result_text': (task['result'] or {}).get('text'),
                'history_generation': session.history_generation, 'turn': runtime.turn_id,
                'attempts': [(attempt['id'], attempt['turn_id']) for attempt in runtime.hybrid.state['attempts']],
                'provider_requests': len(backend.requests),
                'runtime_message_count': len(runtime.messages),
                'request_history_source_count': runtime._request_history.source_count,
                'context_start': session.context_start,
            })
        service.shutdown()
    report['source_unchanged'] = all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == checksum
                                     for name, checksum in report['source_hashes'].items())
    report['last_attempt_id_strictly_increased'] = report['turns'][2]['attempts'][-1][0] > report['turns'][0]['attempts'][-1][0]
    path = OUTPUT / sys.argv[1]
    with path.open('x') as output:
        json.dump(report, output, indent=2)
        output.write('\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
