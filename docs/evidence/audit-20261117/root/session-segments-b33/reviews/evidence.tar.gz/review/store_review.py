"""Independent SQLite probes for the runtime segmentation store change."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sqlite3
import subprocess
import sys
import tempfile

ROOT = Path('<SOURCE_ROOT>')
OUTPUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from agent.persistence import SQLiteRuntimeStore, PersistenceError


def old_store():
    source = subprocess.check_output(
        ['git', 'show', 'b9615c72db68bcf0ee065c884882b26d2cf0a581:agent/persistence.py'],
        cwd=ROOT,
    )
    path = OUTPUT / 'schema2-persistence-original.py'
    path.write_bytes(source)
    spec = importlib.util.spec_from_file_location('agent._schema2_review', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.SQLiteRuntimeStore, module.PersistenceError


def payload(text):
    return {'session': {'id': 'session', 'owner_subject': 'owner'}, 'runtime': {'text': text}}


def db_state(path):
    with sqlite3.connect(path) as db:
        return {
            'version': db.execute('PRAGMA user_version').fetchone()[0],
            'checkpoints': db.execute('SELECT * FROM checkpoints').fetchall(),
            'journal': db.execute('SELECT * FROM journal').fetchall(),
            'segments': db.execute('SELECT * FROM runtime_segments').fetchall(),
        }


def main():
    old, old_error = old_store()
    result = {'source_sha256': hashlib.sha256((ROOT / 'agent/persistence.py').read_bytes()).hexdigest()}
    with tempfile.TemporaryDirectory() as directory:
        directory = Path(directory)
        # Exercise an actual schema-2 writer, not a hand-written migration mock.
        path = directory / 'migration.sqlite3'
        store = old(path)
        store.save('session', payload('before'), 'initial')
        prior = store.load()
        store.close()
        store = SQLiteRuntimeStore(path)
        backup = store.migration_backup
        with sqlite3.connect(backup) as db:
            backup_version = db.execute('PRAGMA user_version').fetchone()[0]
            backup_integrity = db.execute('PRAGMA integrity_check').fetchone()[0]
        result['schema2_migration'] = {
            'before': 2, 'after': store.connection.execute('PRAGMA user_version').fetchone()[0],
            'backup_version': backup_version, 'backup_integrity': backup_integrity,
            'backup_mode': oct(backup.stat().st_mode & 0o777), 'payload_unchanged': store.load() == prior,
        }
        store.close()
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        try:
            old(path)
            result['old_reader_rejection'] = False
        except old_error:
            result['old_reader_rejection'] = True
        result['old_reader_database_unchanged'] = before == hashlib.sha256(path.read_bytes()).hexdigest()

        for stage in ('before_commit', 'after_commit'):
            path = directory / (stage + '.sqlite3')
            store = SQLiteRuntimeStore(path)
            store.save('session', payload('old'), 'initial')
            def fail(current, point):
                if current == stage:
                    raise OSError('injected storage failure')
            store.fault_hook = fail
            try:
                store.save('session', payload('new'), 'rotation',
                           archived_runtime={'generation': 0, 'snapshot': {'text': 'old'}})
                raised = False
            except PersistenceError:
                raised = True
            fenced = store.failed
            store.close()
            state = db_state(path)
            store = SQLiteRuntimeStore(path)
            loaded = store.load()
            segment = store.runtime_segment('session', 0)
            store.close()
            result[stage] = {
                'raised': raised, 'fenced': fenced,
                'checkpoint_text': loaded[0]['runtime']['text'],
                'journal_rows': len(state['journal']),
                'segment_rows': len(state['segments']), 'segment': segment,
            }

        path = directory / 'revision.sqlite3'
        store = SQLiteRuntimeStore(path)
        for number in (1, 2, 3):
            store.save('session', payload(str(number)), 'revision')
        store.connection.execute('UPDATE journal SET revision = 1.5 WHERE revision = 2')
        rows = store.connection.execute('SELECT revision FROM journal ORDER BY revision').fetchall()
        old_predicate = [row[0] for row in rows] == list(range(1, 4))
        try:
            store.load()
            new_accepts = True
        except PersistenceError:
            new_accepts = False
        store.close()
        result['fractional_revision_integrity'] = {
            'rows': rows, 'old_contiguous_predicate_accepts': old_predicate,
            'new_load_accepts': new_accepts,
        }
    result['source_unchanged'] = result['source_sha256'] == hashlib.sha256((ROOT / 'agent/persistence.py').read_bytes()).hexdigest()
    (OUTPUT / 'store-review-results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
