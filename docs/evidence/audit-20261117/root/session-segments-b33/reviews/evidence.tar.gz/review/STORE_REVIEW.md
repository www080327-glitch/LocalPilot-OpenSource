# Independent review: schema-3 runtime segments

This is a review of the new `SQLiteRuntimeStore` diff, not a release acceptance certificate. The probe invokes the current real store and the actual schema-2 implementation retrieved from commit `b9615c72db68bcf0ee065c884882b26d2cf0a581`; SQLite is not mocked. The probe source stayed unchanged during the recorded run.

## Verified behavior

- Schema-2 database creation uses the actual old writer. Opening it with schema 3 creates a readable, integrity-checked backup whose `user_version` remains 2 and permissions remain 0600. Checkpoint payloads survive unchanged.
- The actual old reader refuses the schema-3 database. Hashing the database before and after the rejected open found no content mutation. The probe does not start any model or tool execution.
- A `before_commit` injected failure leaves the previous checkpoint and journal, with no segment. An `after_commit` injected failure leaves the new checkpoint, the added journal entry, and the segment together. Both failures fence the live store. Reopening reads the matching durable state.
- The revised aggregate journal check rejects non-integral revision numbers, preserving the old contiguous-integer-sequence semantics under SQLite's non-STRICT INTEGER affinity. The initial count/min/max-only expression was not equivalent for rows 1, 1.5, 3; the root author added the integer-type aggregate before this recorded probe ran.

## Code review assessment

The schema migration backs up versions 1 and 2 before the DDL transaction. The new runtime-segment insert shares the existing transaction with checkpoint replacement, journal append, archived tasks and optional closed-session archival. Existing serialization/hash checks and failure fencing apply to the new segment reader. No second Runtime or replay mechanism is introduced by the Store change.

The indexed aggregate query avoids allocating all journal rows in Python but still scans the session's lifetime journal in SQLite. It is a memory-allocation improvement, not proof of constant-time startup or bounded database size. Archived payload corruption remains detected lazily when read, matching the preceding archive design; startup does not validate every archived payload.

Service rotation and task-index compatibility are a separate review once that diff is complete. No conclusion on those not-yet-reviewed changes is implied here.

## Evidence

`store_review.py` is the independent reproduction. `store-review-results.json` includes the reviewed source SHA-256 and all observed values. `schema2-persistence-original.py` is an unmodified retrieval of the prior implementation for the probe, not a new source edit.
