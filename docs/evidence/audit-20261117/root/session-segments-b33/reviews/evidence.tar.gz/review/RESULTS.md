# Independent persistence and Hybrid rotation review

## Final assessment

**PASS WITH SCOPE LIMITS for the reviewed Store and completed-task rotation paths.** Two concrete regressions found during this review cycle were fixed and are covered by a real service regression test. The tested files and exact commands are recorded in `hybrid-review-r2/RESULTS.json`; source hashes did not change during the final targeted run or isolated negative controls.

The only repository edit made by this reviewer is `tests/test_hybrid_history_rotation.py`, explicitly delegated by the root author. Production fixes were made by their assigned owners. No external model calls were made during this review.

## Findings and fixes

1. A completed turn which failed before its first model dispatch had no current-turn Hybrid attempt. Retaining only current-turn attempts therefore erased the last attempt identity and made the following request reuse ID 0. The minimal fix retains the last old attempt as an identity anchor when the current turn has no attempts. Existing metrics and cloud quotas remain scoped by task identity and turn.
2. The same zero-dispatch case exposed a canonical-tail issue: `context_start` could lie after `request_history.source_count`, so cutting at the latest task start could remove the preceding final assistant response before it had entered the model's admitted window. The helper now cuts no later than the admitted cursor and rebases both cursor and latest-task start. The regression verifies the response after a real committed rotation, restart, and the next provider request.

The regression uses one fixed 4,000-token model-window fixture throughout. The 4,000-character second input is valid at the task-input boundary but causes a real protected-context failure before model dispatch. The subsequent short question fits without a legitimate compaction that would mask the tail assertion. No host configuration changes are used to make the check pass.

## Final verification

The 7-case targeted run passed in **1.027 seconds** (1.332 seconds outer elapsed time):

- Real default deployment factory with its local HTTP model adapter, Hybrid defaults, SQLite rotation and restart.
- Cloud Hybrid rotation preserving the last admitted request prefix, current-turn usage and durable state.
- Exact egress grants left unchanged, including the deliberate skip of rotation for such sessions.
- Cloud request quota shared with children.
- Per-request cloud egress authorization remaining separate from later requests.
- Configuration drift and missing Hybrid state rejected on restore.
- Zero-dispatch failure followed by an `after_commit` rotation interruption, restart, original archived runtime equality, full input text preservation, frozen old task snapshots, zero-call idempotent retrieval, attempt ID continuity, exact request-prefix continuity and a second restart.

Two negative controls ran the same new test against isolated copies of the actual implementation. Removing only the attempt anchor caused the expected `0 != 1` failure. Restoring the older tail-cut boundary caused the resumed cursor to point at the wrong message. Both controls exited 1 at the intended assertions. They did not modify the shared checkout.

## Store verification

`STORE_REVIEW.md`, `store_review.py` and `store-review-results.json` cover the actual schema-2 writer migrating to schema 3, verified 0600 backups, rejection by the actual old reader without database mutation, and before/after-commit atomicity of checkpoint, journal and segment state.

A single 20,000-revision journal comparison retained the exact checkpoint payload and measured Python allocation peaks of **4,990,492 bytes** for the old schema-2 loader and **2,856 bytes** for the current aggregate loader. The observed times were 0.0942 and 0.00305 seconds. This is a small diagnostic sample, not a throughput guarantee, whole-process RSS measurement, or constant-time-startup proof; SQLite still scans the journal.

## Evidence chronology and limits

`service-review-results.json` records the earlier three plain-V5 restart/rotation probes. `hybrid-empty-turn-attempt-fix-only.json` records the intermediate state after the attempt-identity fix but before the canonical-tail fix; its source hashes identify that stage. Neither is relabeled as the final Hybrid review. The final seven-case run and both negative controls are under `hybrid-review-r2/`.

The implementation rotates only at eligible completed-task boundaries. This review does not certify a hard size limit during one continuously running task, native GUI behavior, actual model quality, all future schema migrations, or unbounded disk retention. Computer Use and Adaptive paths remain outside automatic rotation; sessions with existing exact egress grants retain their prior behavior. No balances, credentials, real user files or user services were accessed by these probes.
