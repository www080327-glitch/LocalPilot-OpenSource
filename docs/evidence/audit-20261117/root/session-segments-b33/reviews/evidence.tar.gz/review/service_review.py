"""Independent real AgentSession / Registry / SQLite rotation probes."""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import sys
import tempfile

ROOT = Path('<SOURCE_ROOT>')
OUTPUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from agent.engine_v5 import EngineV5Policy
from agent.persistence import PersistenceError
from agent.registry import create_default_registry
from agent.session import AgentSession, SessionBudgets
from localpilot_api.service import TaskRequest, TaskService
from tests.test_runtime_api import Backend, answer, call


def source_hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in (
        'agent/persistence.py', 'agent/session_history.py', 'localpilot_api/service.py')}


def main():
    report = {'source_hashes': source_hashes(), 'external_model_calls': 0, 'cases': {}}
    for failure_stage in (None, 'before_commit', 'after_commit'):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            workspace = directory / 'workspace'
            workspace.mkdir()
            (workspace / 'note.txt').write_text('exact original note')
            steps = []
            for index in range(6):
                steps.extend([answer(None, call('read_file', {'path': 'note.txt'}, 'read-' + str(index))),
                              answer('answer-' + str(index))])
            backend = Backend(*steps)
            def factory(callback):
                return AgentSession(create_default_registry(workspace, permission_mode='full-permission'),
                    backend=backend, policy='cloud-only', streaming=False, event_callback=callback,
                    engine_policy=EngineV5Policy(max_completion_repairs=0),
                    budgets=SessionBudgets(max_steps=12, max_token_units=1000000, max_output_tokens=512))
            def service():
                return TaskService({'localpilot': factory}, persistence=directory / 'runtime.sqlite3',
                                   history_rotation_bytes=1)
            current = service()
            frozen = []
            requests = []
            sid = None
            for index in range(2):
                request = TaskRequest('question-' + str(index), session_id=sid,
                                      instructions='GUIDANCE-' + str(index), idempotency_key='key-' + str(index))
                task = current.wait(current.create_task(request)['id'])
                assert task['status'] == 'completed', task['status']
                sid = task['session_id']
                requests.append(request)
                frozen.append(deepcopy(task))
            last_request = deepcopy(backend.requests[-1]['messages'])
            if failure_stage:
                def fail(stage, point):
                    if stage == failure_stage and point == 'history_rotated':
                        raise OSError('injected rotation boundary interruption')
                current.store.fault_hook = fail
                try:
                    current.create_task(TaskRequest('not-dispatched', session_id=sid, idempotency_key='never-created'))
                    raise AssertionError('rotation fault did not stop task creation')
                except PersistenceError:
                    pass
                assert len(backend.requests) == 4
                assert current.store.failed
                current.store.close()
                current = service()
            else:
                current.suspend()
                current = service()
            snapshots_stable = all(current.task_snapshot(task['id']) == task for task in frozen)
            before_retry = len(backend.requests)
            retries_stable = all(current.create_task(request) == task for request, task in zip(requests, frozen))
            retry_calls = len(backend.requests) - before_retry
            task = current.wait(current.create_task(TaskRequest('question-2', session_id=sid,
                instructions='GUIDANCE-2', idempotency_key='key-2'))['id'])
            assert task['status'] == 'completed', task['status']
            actual_request = backend.requests[4]['messages']
            prefix_preserved = actual_request[:len(last_request)] == last_request
            session = current.sessions[sid]
            retained_users = [message.content for message in session.runtime.messages if message.role == 'user']
            case = {
                'task_status': task['status'],
                'old_task_snapshots_exact': snapshots_stable,
                'old_idempotency_retries_exact': retries_stable,
                'additional_provider_requests_on_retry': retry_calls,
                'previous_admitted_request_is_exact_prefix': prefix_preserved,
                'history_generation': session.history_generation,
                'segment_count': len(current.store.runtime_segments(sid)),
                'retained_user_messages': retained_users,
                'latest_tool_receipt_count': len(task['tools']),
                'latest_assistant_texts': [item['content'] for item in task['output'] if item['role'] == 'assistant'],
            }
            assert snapshots_stable and retries_stable and retry_calls == 0
            assert prefix_preserved
            assert 'question-1' in retained_users and 'question-2' in retained_users
            assert any('GUIDANCE-1' in text for text in retained_users)
            assert 'question-0' not in retained_users
            assert len(task['tools']) == 1
            current.suspend()
            current = service()
            case['latest_snapshot_after_second_restart_exact'] = current.task_snapshot(task['id']) == task
            assert case['latest_snapshot_after_second_restart_exact']
            current.shutdown()
            report['cases'][failure_stage or 'normal_restart'] = case
    report['source_unchanged'] = source_hashes() == report['source_hashes']
    (OUTPUT / 'service-review-results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
