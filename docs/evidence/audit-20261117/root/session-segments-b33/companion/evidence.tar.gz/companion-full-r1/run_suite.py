import hashlib, json, os, platform, re, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path

root = Path('<SOURCE_ROOT>')
output = Path(__file__).resolve().parent
python = '<PINNED_TEST_ENVIRONMENT>/.venv/bin/python'
command = [python, '-B', '-m', 'unittest', 'discover', '-s', 'companion/tests', '-t', '.', '-v']
prefixes = ('agent/', 'localpilot_api/', 'localpilot_service/', 'companion/', 'suite/', 'channels/', 'tests/')

def sources():
    paths = sorted(set(subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard'], cwd=root, text=True).splitlines()))
    records = {}
    for name in paths:
        path = root/name
        if (name.startswith(prefixes) or name in {'pyproject.toml','MODULE_RELEASE_MATRIX.json'}) and path.is_file():
            data = path.read_bytes()
            records[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return records

before = sources()
(output/'source-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2)+'\n')
started = datetime.now(timezone.utc).isoformat()
start = time.monotonic()
with (output/'unittest.log').open('w') as log:
    result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
elapsed = time.monotonic()-start
finished = datetime.now(timezone.utc).isoformat()
after = sources()
(output/'source-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2)+'\n')
changed = [name for name in sorted(set(before)|set(after)) if before.get(name)!=after.get(name)]
log = (output/'unittest.log').read_text()
match = re.search(r'Ran (\d+) tests in ([0-9.]+)s',log)
status = re.search(r'^(OK|FAILED)(?: \((.*?)\))?$',log,re.M)
counts = dict(re.findall(r'(failures|errors|skipped)=(\d+)',status.group(2) or '')) if status else {}
run = int(match.group(1)) if match else None
failed = int(counts.get('failures',0))
errors = int(counts.get('errors',0))
skipped = int(counts.get('skipped',0))
summary = {'command':command,'cwd':str(root),'python':subprocess.check_output([python,'--version'],text=True).strip(),
    'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'started_at_utc':started,'finished_at_utc':finished,'wrapper_seconds':elapsed,
    'unittest_seconds':float(match.group(2)) if match else None,'exit_code':result.returncode,
    'tests':run,'passed':run-failed-errors-skipped if run is not None else None,'failed':failed,'errors':errors,'skipped':skipped,
    'source_files':len(before),'source_unchanged':not changed,'source_changes':changed,
    'source_before_sha256':hashlib.sha256((output/'source-before.json').read_bytes()).hexdigest(),
    'source_after_sha256':hashlib.sha256((output/'source-after.json').read_bytes()).hexdigest(),
    'source_selection':'Git tracked and untracked nonignored files under agent, localpilot_api, localpilot_service, companion, suite, channels, tests plus root pyproject.toml and MODULE_RELEASE_MATRIX.json',
    'log_sha256':hashlib.sha256((output/'unittest.log').read_bytes()).hexdigest()}
(output/'run.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
raise SystemExit(result.returncode or bool(changed))
