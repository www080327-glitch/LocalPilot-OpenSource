"""Measure real Companion persistence paths using one real task plus synthetic history.

No model/network provider outside the in-process HTTP fixture is used. Timing
samples exclude SQL tracing and tracemalloc; both are measured separately.
"""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import platform
import statistics
import subprocess
import sys
import time
import tracemalloc

ROOT = Path('<SOURCE_ROOT>')
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from companion.tests.test_v044_service import ServiceContractTests, request


def digest(data):
    return hashlib.sha256(data).hexdigest()


def files():
    paths = [
        'companion/runtime/tasks.py', 'companion/runtime/service.py',
        'companion/runtime/model_collaboration.py', 'companion/runtime/commands.py',
        'companion/memory/store.py', 'companion/memory/retention.py',
        'companion/tests/test_v044_service.py',
    ]
    return {name: digest((ROOT / name).read_bytes()) for name in paths}


def measure(app, action):
    times = []
    for _ in range(5):
        start = time.perf_counter()
        action()
        times.append((time.perf_counter() - start) * 1000)
    calls = {'full_task_map_selects': 0, 'full_task_map_writes': 0}
    def sql(statement):
        if statement == "SELECT value FROM state WHERE key='localpilot_tasks'":
            calls['full_task_map_selects'] += 1
        if statement.startswith("INSERT OR REPLACE INTO state VALUES('localpilot_tasks',"):
            calls['full_task_map_writes'] += 1
    app.store.db.set_trace_callback(sql)
    action()
    app.store.db.set_trace_callback(None)
    tracemalloc.start()
    action()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return {'elapsed_ms': times, 'median_ms': statistics.median(times),
            'peak_python_allocation_bytes_separate_sample': peak, **calls}


def main():
    before = files()
    case = ServiceContractTests('test_native_submit_result_not_claimed_verified')
    case.setUp()
    report = {'base_commit': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(),
              'source_sha256_before': before, 'python': platform.python_version(),
              'platform': platform.platform(),
              'scope': 'One accepted task through real HTTP/SQLite; additional stored history rows are synthetic copies, not actually executed tasks.',
              'external_model_calls': 0, 'samples': []}
    try:
        app = case.host()
        prepared = app.prepare_escalation(request('Synthetic public task for stored-history growth measurement'), mode='execution')
        first = app.command({'command':'submit_escalation','approved':True,
                             'expected_digest':prepared['review_digest'],'defer_monitor':True})
        task_id = first['task_id']
        case.service.wait(task_id)
        view = app.command({'command':'task_status','task_id':task_id})
        assert view['status'] == 'completed' and view['quiescent']
        seed = app.store.get('localpilot_tasks')[task_id]
        report['seed_record_json_bytes'] = len(json.dumps(seed, ensure_ascii=False).encode())
        for count in (1, 100, 1000, 10000):
            rows = {task_id: deepcopy(seed)}
            for index in range(1, count):
                item = deepcopy(seed)
                synthetic_id = f'synthetic-task-{index:08}'
                item['submission_id'] = f'synthetic-submission-{index:08}'
                item['timestamp'] = seed['timestamp'] - index
                for key in ('result', 'last_status', 'feedback'):
                    item[key]['task_id'] = synthetic_id
                for key in ('result', 'last_status'):
                    item[key]['session_id'] = f'synthetic-session-{index:08}'
                rows[synthetic_id] = item
            app.store.set('localpilot_tasks', rows)
            del rows
            sample = {'stored_tasks': count}
            raw = app.store.db.execute("SELECT value FROM state WHERE key='localpilot_tasks'").fetchone()[0]
            sample['stored_json_bytes'] = len(raw.encode())
            sample['provider_exact_lookup'] = measure(app, lambda: app.provider_for_task(task_id))
            sample['receive_terminal_update'] = measure(app, lambda: app.receive_task_update(task_id, deepcopy(view)))
            sample['task_status_real_http'] = measure(app, lambda: app.command({'command':'task_status','task_id':task_id}))
            sample['escalation_status'] = measure(app, lambda: app.command({'command':'escalation_status'}))
            status = app.command({'command':'escalation_status'})
            sample['escalation_status_json_bytes'] = len(json.dumps(status, ensure_ascii=False).encode())
            start = time.perf_counter()
            app.retention()
            sample['retention_ms'] = (time.perf_counter() - start) * 1000
            after_retention = app.store.db.execute("SELECT value FROM state WHERE key='localpilot_tasks'").fetchone()[0]
            # Updates intentionally change last_checked_at, so compare retention with
            # its own immediate before/after hashes, separately below.
            sample['stored_tasks_after_retention'] = len(json.loads(after_retention))
            previous = digest(after_retention.encode())
            app.retention()
            after_again = app.store.db.execute("SELECT value FROM state WHERE key='localpilot_tasks'").fetchone()[0]
            sample['retention_does_not_change_task_map'] = previous == digest(after_again.encode())
            report['samples'].append(sample)
            print(json.dumps({'stored_tasks': count,'bytes':sample['stored_json_bytes'],
                              'status_ms':sample['task_status_real_http']['median_ms'],
                              'status_reads':sample['task_status_real_http']['full_task_map_selects'],
                              'status_writes':sample['task_status_real_http']['full_task_map_writes']}), flush=True)
        before_clear = len(app.store.get('localpilot_tasks'))
        cleared = app.command({'command':'clear','confirmation':'DELETE_COMPANION_MEMORY'})
        try:
            app.command({'command':'task_status','task_id':task_id})
        except ValueError as exc:
            missing_record_error = str(exc)
        else:
            raise AssertionError('A cleared task unexpectedly retained Companion ownership')
        report['clear_probe'] = {'disposable_fixture_only':True, 'tasks_before':before_clear,
            'clear_status':cleared['status'], 'tasks_after':len(app.store.get('localpilot_tasks',{})),
            'core_task_still_present':task_id in case.service.tasks, 'companion_lookup_error':missing_record_error}
        report['scripted_backend_requests'] = len(case.backend.requests)
    finally:
        case.doCleanups()
        case.tearDown()
    report['source_sha256_after'] = files()
    report['source_unchanged'] = report['source_sha256_before'] == report['source_sha256_after']
    report['probe_sha256'] = digest(Path(__file__).read_bytes())
    (OUT/'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')


if __name__ == '__main__':
    main()
