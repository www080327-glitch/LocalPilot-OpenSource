"""Post-fix measurement; preserves the original growth probe and its output."""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import statistics
import sys
import time

from probe import ROOT, files
sys.path.insert(0, str(ROOT))
from companion.tests import test_v044_service as contract

OUT = Path(__file__).parent


def main():
    fixture = contract.ServiceContractTests('test_native_submit_result_not_claimed_verified')
    fixture.setUp()
    before = files()
    report = {'source_sha256_before':before, 'scope':'One real HTTP task and synthetic stored-history copies',
              'external_model_calls':0, 'samples':[]}
    try:
        app = fixture.host()
        prepared = app.prepare_escalation(contract.request('Synthetic public task for stored-history growth measurement'), mode='execution')
        first = app.command({'command':'submit_escalation', 'approved':True,
            'expected_digest':prepared['review_digest'], 'defer_monitor':True})
        fixture.service.wait(first['task_id'])
        view = app.command({'command':'task_status', 'task_id':first['task_id']})
        seed = app.store.get('localpilot_tasks')[first['task_id']]
        for count in (1000, 10000):
            rows = {first['task_id']:deepcopy(seed)}
            for index in range(1, count):
                item = deepcopy(seed)
                task_id = f'synthetic-task-{index:08}'
                item['submission_id'] = f'synthetic-submission-{index:08}'
                item['timestamp'] = seed['timestamp'] - index
                for key in ('result','last_status','feedback'):
                    item[key]['task_id'] = task_id
                for key in ('result','last_status'):
                    item[key]['session_id'] = f'synthetic-session-{index:08}'
                rows[task_id] = item
            app.store.set('localpilot_tasks', rows)
            del rows
            sample = {'stored_tasks':count}
            durations = []
            for _ in range(5):
                begin = time.perf_counter()
                app.command({'command':'task_status','task_id':first['task_id']})
                durations.append((time.perf_counter()-begin)*1000)
            counts = {'full_task_map_selects':0,'full_task_map_writes':0}
            def trace(sql):
                if sql == "SELECT value FROM state WHERE key='localpilot_tasks'":
                    counts['full_task_map_selects'] += 1
                if sql.startswith("INSERT OR REPLACE INTO state VALUES('localpilot_tasks',"):
                    counts['full_task_map_writes'] += 1
            app.store.db.set_trace_callback(trace)
            app.command({'command':'task_status','task_id':first['task_id']})
            app.store.db.set_trace_callback(None)
            sample['task_status_real_http'] = {'elapsed_ms':durations,'median_ms':statistics.median(durations),**counts}
            raw = app.store.db.execute("SELECT value FROM state WHERE key='localpilot_tasks'").fetchone()[0]
            sample['stored_json_bytes'] = len(raw.encode())
            snapshot = app.command({'command':'ui_snapshot'})
            sample['ui_snapshot_bytes'] = len(json.dumps(snapshot,ensure_ascii=False).encode())
            sample['ui_client_response_limit_bytes'] = 2_097_152
            sample['ui_page_count'] = len(snapshot['escalation']['tasks'])
            sample['ui_total'] = snapshot['escalation']['total']
            sample['both_ui_task_projections_match'] = snapshot['runtime']['escalation_tasks'] == snapshot['escalation']['tasks']
            sample['history_read_preserved_original_json'] = raw == app.store.db.execute("SELECT value FROM state WHERE key='localpilot_tasks'").fetchone()[0]
            sample['oldest_task_still_recorded'] = f'synthetic-task-{count-1:08}' in app.store.get('localpilot_tasks')
            assert sample['ui_snapshot_bytes'] < sample['ui_client_response_limit_bytes']
            assert sample['ui_page_count'] == 30 and sample['ui_total'] == count
            assert sample['history_read_preserved_original_json'] and sample['both_ui_task_projections_match']
            report['samples'].append(sample)
            print(json.dumps(sample),flush=True)
        report['scripted_backend_requests'] = len(fixture.backend.requests)
        assert report['scripted_backend_requests'] == 1
    finally:
        fixture.doCleanups()
        fixture.tearDown()
    report['source_sha256_after'] = files()
    report['source_unchanged'] = before == report['source_sha256_after']
    report['probe_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (OUT/'after-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')


if __name__ == '__main__':
    main()
