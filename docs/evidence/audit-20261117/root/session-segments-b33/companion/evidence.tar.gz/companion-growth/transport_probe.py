"""Exercise Companion's authenticated HTTP serializer with a large saved history.

The real queue is serviced on the SQLite-owning thread; startup observers and
native widgets are not launched. No external model service is contacted.
"""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import sys
from urllib.request import ProxyHandler, Request, build_opener

from probe import ROOT, files
sys.path.insert(0, str(ROOT))
from companion.tests import test_v044_service as contract

OUT = Path(__file__).parent


def main():
    fixture = contract.ServiceContractTests('test_native_submit_result_not_claimed_verified')
    fixture.setUp()
    before = files()
    report = {'source_sha256_before':before, 'external_model_calls':0,
              'scope':'Real authenticated Companion HTTP channel, command queue, dispatcher and SQLite; native Swift UI is not executed',
              'requests':[]}
    try:
        app = fixture.host()
        prepared = app.prepare_escalation(contract.request('Synthetic retained task'), mode='execution')
        first = app.command({'command':'submit_escalation', 'approved':True,
            'expected_digest':prepared['review_digest'], 'defer_monitor':True})
        fixture.service.wait(first['task_id'])
        app.command({'command':'task_status','task_id':first['task_id']})
        seed = app.store.get('localpilot_tasks')[first['task_id']]
        seed['timestamp'] = 1
        records = {first['task_id']:seed}
        for index in range(1000):
            item = deepcopy(seed)
            item['timestamp'] = index + 2
            item['request']['user_request'] = '历史问题详细背景。' * 350
            records[f'historical-{index:05}'] = item
        app.store.set('localpilot_tasks', records)
        raw = app.store.db.execute("SELECT value FROM state WHERE key='localpilot_tasks'").fetchone()[0]
        report['stored_json_bytes'] = len(raw.encode())
        assert report['stored_json_bytes'] > 2_097_152
        app.channel.start()
        def fetch(body):
            request = Request(f'http://127.0.0.1:{app.channel.port}/command', data=json.dumps(body).encode(),
                headers={'Authorization':'Bearer '+app.token,'Content-Type':'application/json'})
            with build_opener(ProxyHandler({})).open(request,timeout=10) as response:
                content = response.read()
                return response.status, int(response.headers['Content-Length']), content
        with ThreadPoolExecutor(max_workers=1) as pool:
            cursor = None
            for index in range(2):
                future = pool.submit(fetch, {'command':'ui_snapshot','task_before':cursor})
                kind, command, reply = app.queue.get(timeout=5)
                assert kind == 'command'
                assert reply.set_running_or_notify_cancel()
                reply.set_result(app.command(command))
                status, length, body = future.result(timeout=10)
                value = json.loads(body)
                history = value['escalation']
                assert status == 200 and length == len(body) and length < 2_097_152
                assert len(history['tasks']) == 30 and history['total'] == 1001
                assert history['tasks'] == value['runtime']['escalation_tasks']
                report['requests'].append({'page':index+1,'http_status':status,'content_length':length,
                    'response_sha256':hashlib.sha256(body).hexdigest(),'tasks_in_page':len(history['tasks']),
                    'total_tasks':history['total'],'has_next_cursor':history['next_before'] is not None})
                cursor = history['next_before']
        unchanged = app.store.db.execute("SELECT value FROM state WHERE key='localpilot_tasks'").fetchone()[0]
        report['original_task_json_unchanged'] = raw == unchanged
        assert report['original_task_json_unchanged']
        report['scripted_backend_requests'] = len(fixture.backend.requests)
        assert report['scripted_backend_requests'] == 1
    finally:
        fixture.doCleanups()
        fixture.tearDown()
    report['source_sha256_after'] = files()
    report['source_unchanged'] = before == report['source_sha256_after']
    report['probe_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (OUT/'transport-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'stored_bytes':report['stored_json_bytes'],'responses':report['requests'],
                      'source_unchanged':report['source_unchanged']},ensure_ascii=False))


if __name__ == '__main__':
    main()
