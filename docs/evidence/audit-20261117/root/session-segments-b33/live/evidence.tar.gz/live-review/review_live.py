"""Read-only independent checks of the one live Luna rotation run.

No service/runtime is instantiated, no API request is made, and the database is
opened immutable/read-only. Opaque reasoning and the private credential never
appear in this review's output.
"""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import sqlite3
import subprocess
import sys

ROOT = Path('<SOURCE_ROOT>')
RAW = Path('<VALIDATION_ROOT>/live-luna-segments-r1')
RUNNER = RAW.parent/'live_segments.py'
OUT = Path(__file__).parent
sys.path.insert(0,str(ROOT))
from agent.persistence import unpack


def sha(value):
    return hashlib.sha256(value).hexdigest()


def canonical(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def read(name):
    return json.loads((RAW/name).read_text())


def inventory():
    return {str(path.relative_to(RAW)):{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
            for path in sorted(RAW.rglob('*')) if path.is_file()}


def nodes(value):
    if isinstance(value,dict):
        yield value
        for item in value.values():
            yield from nodes(item)
    elif isinstance(value,(list,tuple)):
        for item in value:
            yield from nodes(item)


def main():
    original=inventory()
    checks=[]
    def check(name,passed,**details):
        checks.append({'name':name,'passed':bool(passed),**details})
    report=read('RESULTS.json')
    requests=[read(f'request-{i:02}.json') for i in range(1,9)]
    responses=read('responses.json')
    tasks=[read(f'task-{i}.json') for i in range(1,5)]
    prompts=read('prompts.json')
    markers=read('fixtures.json')['markers']
    source=read('source-hashes.json')
    source_commit='b6f95da47f706581a780d6874382be53d99b33c4'
    source_mismatches=[]
    for path,digest in source.items():
        committed=subprocess.check_output(['git','show',f'{source_commit}:{path}'],cwd=ROOT)
        if sha(committed)!=digest or sha((ROOT/path).read_bytes())!=digest:
            source_mismatches.append(path)
    check('source_identity',report['source_commit']==source_commit and not source_mismatches,
          checked_files=len(source),mismatches=source_mismatches)
    check('recorded_source_clean_and_unchanged',report['source_dirty'] is False and report['source_unchanged'] is True)
    check('one_recorded_run',sum(path.is_dir() for path in RAW.parent.glob('live-luna-segments-r[0-9]*'))==1)
    check('request_response_counts',len(requests)==len(responses)==report['requests']==report['provider_responses']==8)
    check('one_session_four_completed_tasks',len({task['session_id'] for task in tasks})==1
          and len({task['id'] for task in tasks})==4
          and all(task['status']=='completed' and task['quiescent'] and task['error'] is None for task in tasks))
    check('original_prompts_preserved',[task['user_input'] for task in tasks]==prompts)
    expected_groups=[markers[:2],markers[:3],markers,markers]
    check('exact_answer_lines_in_required_order',all(task['result']['text'].splitlines()==expected
          for task,expected in zip(tasks,expected_groups)))
    expected_files={'first.txt':f'Marker: {markers[0]}\nNext file: second.txt\n',
                    'second.txt':f'Marker: {markers[1]}\n',
                    'third.txt':f'Marker: {markers[2]}\n',
                    'fourth.txt':f'Marker: {markers[3]}\n'}
    check('fixture_files_unchanged',all((RAW/'workspace'/path).read_text()==text for path,text in expected_files.items()))
    tools=[tool for task in tasks for tool in task['tools']]
    paths=[[json.loads(tool['arguments'])['path'] for tool in task['tools']] for task in tasks]
    check('only_four_required_read_file_executions',paths==[['first.txt','second.txt'],['third.txt'],['fourth.txt'],[]]
          and len(tools)==4 and len({tool['id'] for tool in tools})==4
          and all(tool['name']=='read_file' and tool['status']=='completed'
                  and tool['payload']['ok'] is True and not tool['receipt_reused'] for tool in tools),paths=paths)
    check('file_receipts_match_exact_fixture_bytes',all(tool['payload']['result']==expected_files[json.loads(tool['arguments'])['path']]
          for tool in tools))
    ledger={tool['id']:tool for tool in tools}
    final_calls={item['call_id']:item for item in requests[-1]['input'] if item.get('type')=='function_call'}
    final_outputs={item['call_id']:item for item in requests[-1]['input'] if item.get('type')=='function_call_output'}
    check('request_replays_match_tool_ledger',set(final_calls)==set(final_outputs)==set(ledger)
          and all(final_calls[key]['name']==tool['name'] and final_calls[key]['arguments']==tool['arguments']
                  and json.loads(final_outputs[key]['output'])==tool['payload'] for key,tool in ledger.items()))
    actual_visibility=[[index+1 for index,marker in enumerate(markers) if marker in canonical(request['input'])]
                       for request in requests]
    check('markers_enter_model_context_only_after_reads',actual_visibility==[[],[1],[1,2],[1,2],[1,2,3],[1,2,3],[1,2,3,4],[1,2,3,4]],
          visible_marker_indices=actual_visibility)
    prompt_calls=(0,3,5,7)
    check('each_current_task_prompt_reaches_model',all(any(item.get('role')=='user' and item.get('content')==prompt
          for item in requests[call]['input']) for prompt,call in zip(prompts,prompt_calls)))
    check('read_only_request_contract',all([tool['name'] for tool in request['tools']]==['file_info','list_directory','read_file','search_text']
          and request['model']=='gpt-6-luna' and request['reasoning']=={'effort':'medium'}
          and request['store'] is False and request['stream'] is False for request in requests))
    calls=[call for task in tasks for call in task['result']['model_calls']]
    check('model_calls_per_task',[len(task['result']['model_calls']) for task in tasks]==[3,2,2,1])
    check('provider_receipts_match_task_usage',len(calls)==8 and all(
        call['reported_model']==response['model']=='gpt-6-luna'
        and call['finish_reason']==response['finish_reason']
        and call['provider_diagnostics']==response['diagnostics']
        and call['input_tokens']==response['usage']['prompt_tokens']
        and call['output_tokens']==response['usage']['completion_tokens']
        and call['prompt_cache_hit_tokens']==response['usage']['prompt_cache_hit_tokens']
        and call['prompt_cache_miss_tokens']==response['usage']['prompt_cache_miss_tokens']
        for call,response in zip(calls,responses)))
    check('eight_distinct_provider_response_ids',len({response['diagnostics']['response_id'] for response in responses})==8)
    check('input_transformations_explicitly_empty',all(response['diagnostics'].get('input_transformations')==[] for response in responses))
    check('usage_arithmetic',all(response['usage']['prompt_tokens']+response['usage']['completion_tokens']==response['usage']['total_tokens']
          and response['usage']['prompt_cache_hit_tokens']+response['usage']['prompt_cache_miss_tokens']==response['usage']['prompt_tokens']
          and response['usage']['provider_usage']['input_tokens']==response['usage']['prompt_tokens']
          and response['usage']['provider_usage']['output_tokens']==response['usage']['completion_tokens'] for response in responses))
    check('product_unverified_status_retained',all(task['result']['task_outcome']=='unverified'
          and task['result']['task_succeeded'] is False and task['result']['verification_status']=='not_run'
          and task['result']['engineering_status']=='unverified' for task in tasks))
    check('delivery_hashes_match_answers',all(task['result']['completion']['execution']=='settled'
          and task['result']['completion']['delivery']=='delivered'
          and task['result']['completion']['history'][-1]['text_sha256']==sha(canonical(task['result']['text']).encode()) for task in tasks))

    database=sqlite3.connect('file:'+str(RAW/'private-runtime.sqlite')+'?mode=ro&immutable=1',uri=True)
    check('sqlite_integrity',database.execute('PRAGMA integrity_check').fetchall()==[('ok',)])
    check('schema_3',database.execute('PRAGMA user_version').fetchone()[0]==3)
    verified_rows=0
    checksum_errors=[]
    for table in ('checkpoints','runtime_segments','archived_tasks','archived_sessions'):
        for payload,digest in database.execute(f'SELECT payload,sha256 FROM {table}'):
            verified_rows+=1
            if sha(payload.encode())!=digest:
                checksum_errors.append(table)
    check('stored_payload_checksums',not checksum_errors,rows=verified_rows,errors=checksum_errors)
    checkpoint=json.loads(database.execute('SELECT payload FROM checkpoints').fetchone()[0])
    segments=[json.loads(row[0]) for row in database.execute('SELECT payload FROM runtime_segments ORDER BY generation')]
    archived=[unpack(json.loads(row[0])) for row in database.execute('SELECT payload FROM archived_tasks ORDER BY task_id')]
    active=[unpack(item) for item in checkpoint['tasks']]
    records={record['id']:record for record in archived+active}
    check('all_four_tasks_preserved_exactly',set(records)=={task['id'] for task in tasks}
          and all(records[task['id']]['result']==task['result'] and records[task['id']]['tools']==task['tools']
                  and records[task['id']]['output']==task['output'] and records[task['id']]['input']==task['user_input']
                  and records[task['id']]['status']==task['status'] for task in tasks))
    check('older_two_tasks_archived_latest_two_active',{item['id'] for item in archived}=={task['id'] for task in tasks[:2]}
          and {item['id'] for item in active}=={task['id'] for task in tasks[2:]})
    check('original_idempotency_keys_retained',all(records[task['id']]['request_key_digest']==sha(f'segment-live-{index}'.encode())
          for index,task in enumerate(tasks,1)))
    check('no_hidden_compaction',sum(event['data']['type']=='ContextCompacted' for record in records.values()
          for event in record['events'] if event['type']=='runtime.event')==report['compactions']==0)
    fields=unpack(checkpoint['runtime']['fields'])
    check('full_permission_gateway_recorded',fields['permission_mode']=='full-permission' and fields['plan_mode'] is False)
    points=database.execute('SELECT revision,point,sha256 FROM journal ORDER BY revision').fetchall()
    latest_revision,latest_sha=database.execute('SELECT revision,sha256 FROM checkpoints').fetchone()
    check('journal_contiguous_and_matches_checkpoint',[row[0] for row in points]==list(range(1,len(points)+1))
          and points[-1][0]==latest_revision and points[-1][2]==latest_sha)
    check('eight_durable_model_dispatches',sum(point=='model_start' for _,point,_ in points)==8
          and sum(point=='hybrid_dispatch_authorized' for _,point,_ in points)==8)
    check('four_task_creations',sum(point=='task.created' for _,point,_ in points)==4)
    rotations=[revision for revision,point,_ in points if point=='history_rotated']
    check('two_completed_rotations',len(rotations)==len(segments)==checkpoint['session']['history_generation']==2
          and [segment['generation'] for segment in segments]==[0,1])
    previous=read('before-rotation-size.json')
    check('first_archive_matches_recorded_original_size_and_counts',len(canonical(segments[0]['runtime']).encode())==previous['runtime_bytes']
          and len(segments[0]['runtime']['messages'])==previous['messages']
          and len(segments[0]['runtime']['history'])==previous['receipts'])
    check('intermediate_generation_one_sample_matches_archive',len(segments[1]['runtime']['messages'])==report['after_rotation']['canonical_messages']
          and len(segments[1]['runtime']['history'])==report['after_rotation']['receipts']
          and segments[1]['generation']==report['after_rotation']['generation']==1)
    suspended=[revision for revision,point,_ in points if point=='service_suspended']
    check('one_restart_and_no_spontaneous_dispatch',len(suspended)==1 and checkpoint['session']['recovery_epoch']==1
          and [point for revision,point,_ in points if suspended[0]<revision<next(revision for revision,point,_ in points if revision>suspended[0] and point=='task.created')]==['history_rotated'])
    check('owned_service_closed_without_post_task_model_call',checkpoint['session']['closed'] and report['owned_service_stopped'] is True
          and points[-1][1]=='session_closed' and points[-2][1]=='task.status')
    check('runner_restart_and_old_key_comparisons_pass',report['restart_preserved_result_without_model_request'] is True
          and report['archived_idempotency_without_model_request'] is True)

    opaque={}
    opaque_conflicts=[]
    runtime_snapshots=[segment['runtime'] for segment in segments]+[checkpoint['runtime']]
    endpoints=set()
    for snapshot in runtime_snapshots:
        for node in nodes(snapshot):
            if node.get('kind')=='openai_responses_v1':
                endpoints.add(node['base_url'])
            if node.get('type')=='reasoning' and isinstance(node.get('encrypted_content'),str):
                prior=opaque.setdefault(node['id'],node['encrypted_content'])
                if prior!=node['encrypted_content']:
                    opaque_conflicts.append(node['id'])
    check('persisted_openai_endpoint',endpoints=={'https://api.openai.com/v1'})
    restored=deepcopy(requests)
    verified_redactions=0
    redaction_errors=[]
    for request in restored:
        for item in request['input']:
            if 'encrypted_content' in item:
                spec=item['encrypted_content']
                value=opaque.get(item['id'])
                if value is None or spec!={'omitted':True,'sha256':sha(canonical(value).encode()),'characters':len(value)}:
                    redaction_errors.append(item['id'])
                else:
                    item['encrypted_content']=value
                    verified_redactions+=1
    check('opaque_reasoning_redactions_match_private_ledger',not opaque_conflicts and not redaction_errors
          and len(opaque)==1 and verified_redactions==4,opaque_items=len(opaque),verified_request_occurrences=verified_redactions)
    recomputed=[]
    for index,(previous_request,current_request) in enumerate(zip(restored,restored[1:]),1):
        recomputed.append({'from':index,'to':index+1,'previous_input_items':len(previous_request['input']),
            'input_prefix_equal':current_request['input'][:len(previous_request['input'])]==previous_request['input'],
            'tools_equal':current_request['tools']==previous_request['tools'],
            'reasoning_equal':current_request['reasoning']==previous_request['reasoning']})
    check('all_seven_exact_input_array_prefixes',all(item['input_prefix_equal'] and item['tools_equal'] and item['reasoning_equal'] for item in recomputed)
          and recomputed==read('prefix-comparisons.json'),pairs=recomputed)
    database.close()

    credential=Path('<PRIVATE_KEY_FILE>').read_bytes().strip()
    credential_hits=[path for path in original if credential in (RAW/path).read_bytes()]
    check('private_api_key_absent_from_saved_raw_artifacts',bool(credential) and not credential_hits,hits=credential_hits)
    del credential
    check('raw_evidence_unchanged',original==inventory())
    totals={'input_tokens':sum(item['usage']['prompt_tokens'] for item in responses),
            'output_tokens':sum(item['usage']['completion_tokens'] for item in responses),
            'cached_input_tokens':sum(item['usage']['prompt_cache_hit_tokens'] for item in responses),
            'cache_miss_tokens':sum(item['usage']['prompt_cache_miss_tokens'] for item in responses),
            'model_latency_seconds':sum(item['latency_seconds'] for item in calls),
            'run_elapsed_seconds':report['elapsed_seconds']}
    review={'status':'PASS_WITH_SCOPE_LIMITS' if all(check['passed'] for check in checks) else 'FAIL',
        'reviewer':'companion_audit independent read-only review', 'source_commit':source_commit,
        'checks_passed':sum(check['passed'] for check in checks), 'checks_total':len(checks), 'checks':checks,
        'totals':totals, 'external_semantic_result':'PASS: exact required marker lines in order on all four tasks',
        'product_result':'All four tasks remain task_outcome=unverified, verification_status=not_run, engineering_status=unverified, task_succeeded=false; completion is settled/delivered.',
        'final_storage':{'history_generation':checkpoint['session']['history_generation'],'rotations':rotations,
            'archived_runtime_segments':len(segments),'archived_tasks':len(archived),'active_tasks':len(active),
            'canonical_messages':len(checkpoint['runtime']['messages']),'active_receipts':len(checkpoint['runtime']['history']),
            'runtime_bytes':len(canonical(checkpoint['runtime']).encode()),'first_pre_rotation_runtime_bytes':read('before-rotation-size.json')['runtime_bytes']},
        'scope_limits':[
            'One approximately 64-second integration run; no AA score, long-run soak, default-threshold stress or unrestricted mutation qualification.',
            'Uses the production EngineV5/Hybrid/Responses path with explicit cloud-only routing and CLOUD_ALLOWED egress restricted to four fixture files. Gateway is full-permission but capabilities are read-only and only read_file was executed.',
            'Rotation threshold is explicitly overridden to 1 byte; production default is 2 MiB. Model context compactions are zero.',
            'RESULTS.after_rotation is the intermediate third-task sample at generation 1. The final private checkpoint has generation 2 and two archived segments.',
            'Input-prefix equality is equality of parsed input-array JSON values, including encrypted values independently matched against private durable data; this is not a wire-byte capture, and JSON object key order may change across restore.',
            'responses.json records parsed response diagnostics/usage/reasoning IDs, not complete raw HTTP response bodies. Final text/tool outputs are cross-checked against saved tasks, request replay and private persisted records.',
            'The runner directly compared the pre-rotation runtime object and restored task snapshots in memory. Independent offline checks additionally verify original size/counts, archived task records, journal/model-call counts and idempotency key digests; the separate complete pre-rotation object was not saved.',
            'The final small-run runtime is larger in bytes than the first pre-rotation runtime despite fewer canonical messages. This does not establish total checkpoint shrinkage or bounded long-term disk use.',
            'TaskService is invoked in-process; this run does not certify HTTP client authentication or native UI behavior.',
            'No new model/API calls or balance queries were made by this review. The original runner records balance_queried=false and contains no balance-query operation.'
        ],
        'runner_sha256':sha(RUNNER.read_bytes()),'review_helper_sha256':sha(Path(__file__).read_bytes()),
        'review_corrections':[
            'The preserved r1 reviewer counted the sibling r1.log as a second run. Final review counts run directories only; no additional run was found.',
            'The preserved r1 reviewer assumed text_sha256 hashed raw UTF-8. agent.finalization.sha hashes encoded JSON values; final review uses that documented encoding and all four text hashes match.'
        ],
        'raw_artifact_inventory':original}
    (OUT/'review-luna.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':review['status'],'checks':review['checks_total'],'passed':review['checks_passed'],
                      'failed':[check['name'] for check in checks if not check['passed']],'totals':totals},ensure_ascii=False))
    return 0 if review['status']=='PASS_WITH_SCOPE_LIMITS' else 1


if __name__=='__main__':
    raise SystemExit(main())
