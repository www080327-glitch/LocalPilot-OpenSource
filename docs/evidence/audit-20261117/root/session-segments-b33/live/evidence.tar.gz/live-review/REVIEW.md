# Luna 会话轮换独立审阅

结论：**PASS_WITH_SCOPE_LIMITS，43/43 项核对通过。** 原始 live 证据逐字节未改变，本审阅没有调用 API、模型或查询余额。

验证源码是 `b6f95da47f706581a780d6874382be53d99b33c4`；113 个运行源码文件同时匹配记录哈希和该 Git 提交。目录中仅有一次 live run。

## 独立核对结果

- 4 个同一 session 的任务，共 8 个 Responses 请求与 8 条 provider 记录，逐项匹配 task model_calls；各任务模型调用数为 3、2、2、1。
- 工具执行只有 first/second、third、fourth 三组 read_file，最后一任务无工具。4 条唯一收据都与 fixture 原文、模型输入中的函数调用/结果对应；原文件没有改变。
- 四次最终回答逐行严格匹配要求的 marker 顺序。后续任务没有重读旧文件；初始模型输入尚不含这些 marker。
- 7/7 相邻输入数组前缀、工具模式、reasoning 设置一致。唯一 opaque reasoning item 在四份后续请求中的摘要哈希/长度与私有持久化值匹配。
- 8 个不同 provider response ID 的 input_transformations 都明确为 []。累计 input 36,587、output 276、cached input 29,113、cache miss 7,474；模型延迟合计 64.11396 秒，整个 run 64.41703 秒。
- SQLite integrity、5 份存储 payload 校验、连续 journal 均通过。最终有 2 份 runtime segment、2 条归档任务、2 条活动窗口任务；4 个原任务的结果、工具、输出、问题文本均与单独保存的 task JSON 相同。
- 4 个原 idempotency key 的摘要完整保留；journal 只有 4 次创建和 8 次模型分发。中间 suspend/reopen 没有自发模型调用，最终 service 已关闭。
- 私钥只在审阅进程内用于精确扫描；保存的原始 artifacts 不含该 key，审阅输出不含 key 或 encrypted_content。

## 必须保留的解释范围

这是一次约 64 秒的受控集成验证，轮换阈值显式改为 **1 字节**；生产默认阈值是 **2 MiB**。本次模型上下文压缩次数为 0。它验证生产 EngineV5/Hybrid/Responses 路径上的归档、精确延续、恢复及旧键查询，不是默认阈值压力测试、长时间 soak、AA 排名或无限历史性能证明。

Gateway 是 full-permission，但 capability 只读，云端外发也仅明确授权四个 fixture 路径；没有验证写文件、执行命令或其他高权限长任务。

`RESULTS.after_rotation.generation=1` 是第三任务后的中间采样；最终数据库是 **generation=2**。最终 canonical messages 为 7、活动 receipts 为 1。最终 runtime 85,148 字节，比第一次轮换前 74,180 字节更大，因此本次小样本不能证明总 checkpoint 变小。

前缀核对指解析后的 input 数组 JSON 值精确一致；它不是 HTTP wire bytes 抓包，重启后 JSON 对象键顺序可能变化。`responses.json` 保存的是解析后的 usage/diagnostics/reasoning ID，并非完整原始 HTTP 响应体；回答和工具已与任务、请求重放及私有持久化记录交叉核验。

原 runner 对轮换前完整 runtime 和恢复后的快照做了内存精确比较。离线审阅额外核验了原始大小/计数、任务档案、journal、模型调用和幂等键；未单独保存的完整轮换前对象不能凭离线 artifacts 再做一次全对象比较。

**产品自身结果没有改写成成功验收。** 四个任务仍为 task_outcome=unverified、verification_status=not_run、engineering_status=unverified、task_succeeded=false；completion 为 settled/delivered。外部 marker 语义通过与产品验收状态分别记录。

本次直接调用进程内 TaskService，不覆盖面向用户的 HTTP 认证或任何 native UI。

## 审阅修正记录

保留的 r1 审阅中有两项审阅脚本错误：把同名 .log 计为第二个 run，以及把 text_sha256 误按原始 UTF-8 计算。最终脚本只计目录，并按 agent.finalization.sha 的 JSON 编码公式核验；两项均通过。没有为此修改产品或原 live 证据。

完整机器记录见 review-luna.json；可复现只读脚本为 review_live.py。r1 脚本、结果和日志也一并保留。
