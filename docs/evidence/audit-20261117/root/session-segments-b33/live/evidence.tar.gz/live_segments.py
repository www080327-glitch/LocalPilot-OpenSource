#!/usr/bin/env python3
"""Actual Luna/Responses + default Hybrid, atomic history rotation and restart."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
import uuid


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode()).hexdigest()


def published_payload(payload):
    result = deepcopy(payload)
    for item in result['input']:
        if 'encrypted_content' in item:
            value = item['encrypted_content']
            item['encrypted_content'] = {'omitted': True, 'sha256': fingerprint(value),
                                         'characters': len(value)}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--key-file', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(args.source_root.resolve()))
    from agent.engine_v5 import EngineV5Policy
    from agent.hybrid import CloudEgressPolicy, HybridPolicy
    from agent.persistence import dumps, snapshot_runtime
    from agent.registry import create_default_registry
    from agent.retry import RetryPolicy
    from agent.session import AgentSession, SessionBudgets
    from agent.safety import CapabilityPolicy
    from localpilot_api.service import TaskService, TaskRequest
    from localpilot_service.backend_contract import ServiceOpenAIResponsesBackend

    source = subprocess.check_output(['git', '-C', str(args.source_root), 'rev-parse', 'HEAD'], text=True).strip()
    source_paths = subprocess.check_output(['git', '-C', str(args.source_root), 'ls-files',
        'agent', 'localpilot_api', 'localpilot_service'], text=True).splitlines()
    source_hashes = {p: hashlib.sha256((args.source_root / p).read_bytes()).hexdigest()
                     for p in source_paths}
    requests, responses, prefixes = [], [], []

    class ObservedBackend(ServiceOpenAIResponsesBackend):
        def _payload(self, *values, **options):
            payload = super()._payload(*values, **options)
            if requests:
                previous = requests[-1]
                prefixes.append({'from': len(requests), 'to': len(requests) + 1,
                    'previous_input_items': len(previous['input']),
                    'input_prefix_equal': payload['input'][:len(previous['input'])] == previous['input'],
                    'tools_equal': payload.get('tools') == previous.get('tools'),
                    'reasoning_equal': payload.get('reasoning') == previous.get('reasoning')})
            requests.append(deepcopy(payload))
            save(args.output / f'request-{len(requests):02}.json', published_payload(payload))
            return payload

        def _response(self, data):
            response = super()._response(data)
            responses.append({'model': response.model, 'finish_reason': response.finish_reason,
                'usage': response.usage, 'diagnostics': response.diagnostics,
                'reasoning_output_ids': [item['id'] for item in data['output']
                                         if item['type'] == 'reasoning']})
            save(args.output / 'responses.json', responses)
            return response

    workspace = args.output / 'workspace'
    workspace.mkdir()
    markers = ['LP-CONTEXT-' + uuid.uuid4().hex[:12] for _ in range(4)]
    (workspace / 'first.txt').write_text(f'Marker: {markers[0]}\nNext file: second.txt\n')
    (workspace / 'second.txt').write_text(f'Marker: {markers[1]}\n')
    (workspace / 'third.txt').write_text(f'Marker: {markers[2]}\n')
    (workspace / 'fourth.txt').write_text(f'Marker: {markers[3]}\n')
    save(args.output / 'fixtures.json', {'markers': markers})

    def factory(callback=None):
        backend = ObservedBackend(model='gpt-6-luna', key_file=args.key_file,
                                  timeout=60, effective_context=65536)
        registry = create_default_registry(workspace, permission_mode='full-permission',
            capabilities=CapabilityPolicy(read=True, write=False, execute=False, read_only=True))
        return AgentSession(registry, backend=backend, policy='cloud-only', thinking='medium',
            streaming=False, event_callback=callback, engine_policy=EngineV5Policy(),
            runtime_tools=False,
            hybrid_policy=HybridPolicy(CloudEgressPolicy('CLOUD_ALLOWED', ('first.txt', 'second.txt', 'third.txt', 'fourth.txt'))),
            hybrid_backends={'cloud': backend}, hybrid_primary='cloud',
            budgets=SessionBudgets(max_steps=8, max_tool_calls=8,
                max_token_units=2000000, max_output_tokens=2048),
            retry_policy=RetryPolicy(max_attempts=1))

    database = args.output / 'private-runtime.sqlite'
    first_prompt = ('Read first.txt, then read only the next file named inside it. '
                    'Reply with the two exact markers in order. Use read_file to obtain both; '
                    'do not list the directory or modify any file.')
    next_prompt = ('Continue our earlier task. Read third.txt only. Reply with the two markers '
                   'from our preceding exchange followed by the new third marker. '
                   'Do not reread the first two files or list the directory.')
    third_prompt = ('Read fourth.txt only. Reply with all four exact markers in order, using the three '
                    'earlier markers already in our conversation. Do not reread any earlier file.')
    fourth_prompt = ('After restart, repeat exactly the four markers from our preceding exchange '
                     'in the same order. Do not use tools.')
    save(args.output / 'prompts.json', [first_prompt, next_prompt, third_prompt, fourth_prompt])
    report = {'kind': 'LIVE_HYBRID_SESSION_ROTATION_INTEGRATION', 'source_commit': source,
        'model': 'gpt-6-luna', 'protocol': 'responses', 'reasoning': 'medium',
        'host': platform.platform(), 'python': platform.python_version(),
        'scope': 'Four synthetic file-reading/memory tasks, actual Luna, default Hybrid and rotation; not an AA score, unrestricted mutation test or long-run soak.',
        'rotation_threshold_bytes': 1, 'threshold_scope': 'integration test override; production default is 2 MiB',
        'source_dirty': bool(subprocess.check_output(['git', '-C', str(args.source_root), 'status', '--porcelain'], text=True).strip()),
        'request_payload_transform': 'Only encrypted reasoning content replaced by exact-value digest/length.',
        'status': 'RUNNING', 'started_at_unix': time.time(), 'balance_queried': False}
    save(args.output / 'source-hashes.json', source_hashes)
    save(args.output / 'RESULTS.json', report)
    started = time.monotonic()
    service = None
    try:
        options = {'persistence': database, 'max_tasks': 32, 'history_rotation_bytes': 1}
        service = TaskService({'luna': factory}, **options)
        session_id = service.create_session('luna')['id']
        prompts = (first_prompt, next_prompt, third_prompt, fourth_prompt)
        results = []
        first_request = None
        before_rotation = None
        for index, prompt in enumerate(prompts, 1):
            if index == 3:
                before_rotation = snapshot_runtime(service.sessions[session_id].runtime)
                save(args.output / 'before-rotation-size.json', {
                    'runtime_bytes': len(dumps(before_rotation).encode()),
                    'messages': len(before_rotation['messages']), 'receipts': len(before_rotation['history'])})
            if index == 4:
                before_restart = len(requests)
                service.suspend()
                service = TaskService({'luna': factory}, **options)
                report['restart_preserved_result_without_model_request'] = (
                    all(service.task_snapshot(item['id']) == item for item in results)
                    and len(requests) == before_restart)
            request = TaskRequest(prompt, model='luna', session_id=session_id,
                timeout_seconds=180, idempotency_key=f'segment-live-{index}')
            if index == 1:
                first_request = request
            created = service.create_task(request)
            service.wait(created['id'])
            result = service.task_snapshot(created['id'])
            results.append(result)
            save(args.output / f'task-{index}.json', result)
            if result['status'] != 'completed':
                raise RuntimeError(f'Live task {index} did not complete: ' + result['status'])
            if index == 3:
                archived = service.store.runtime_segment(session_id, 0)
                report['archive_exact_original_runtime'] = archived is not None and archived['runtime'] == before_rotation
                runtime = service.sessions[session_id].runtime
                report['after_rotation'] = {'generation': service.sessions[session_id].history_generation,
                    'canonical_messages': len(runtime.messages), 'receipts': len(runtime.tool_history),
                    'active_tasks': len(service.tasks),
                    'first_task_archived': results[0]['id'] not in service.tasks}
        before_replay = len(requests)
        replay = service.create_task(first_request)
        report['archived_idempotency_without_model_request'] = replay == results[0] and len(requests) == before_replay
        expected = (markers[:2], markers[:3], markers, markers)
        texts = [str((task['result'] or {}).get('text', '')) for task in results]
        report['semantic_pass'] = all(all(marker in text for marker in group)
                                      for text, group in zip(texts, expected))
        paths = [[json.loads(receipt['arguments']).get('path') for receipt in task['tools']
                  if receipt['name'] == 'read_file'] for task in results]
        report['observed_read_paths'] = paths
        report['read_protocol_pass'] = paths == [['first.txt', 'second.txt'], ['third.txt'], ['fourth.txt'], []]
        report['input_prefix_pass'] = bool(prefixes) and all(p['input_prefix_equal'] for p in prefixes)
        report['tools_and_reasoning_stable'] = all(p['tools_equal'] and p['reasoning_equal'] for p in prefixes)
        report['compactions'] = sum(event['data']['type'] == 'ContextCompacted'
            for task in results for event in service.events(task['id'], wait_seconds=0)[0] if event['type'] == 'runtime.event')
        report['product_task_outcomes'] = [{'task_status': task['status'], **{key: (task['result'] or {}).get(key) for key in (
            'task_outcome', 'task_succeeded', 'verification_status', 'engineering_status', 'completion')}}
            for task in results]
        report['status'] = 'PASS' if all(report[k] for k in ('semantic_pass', 'read_protocol_pass',
            'input_prefix_pass', 'tools_and_reasoning_stable', 'restart_preserved_result_without_model_request',
            'archived_idempotency_without_model_request', 'archive_exact_original_runtime')) else 'FAIL'
    except Exception as error:
        report['status'] = 'FAIL'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if service is not None and not service.closed:
            service.shutdown(timeout=10)
        report.update(elapsed_seconds=time.monotonic() - started, requests=len(requests),
                      provider_responses=len(responses), owned_service_stopped=service is None or service.closed)
        report['source_unchanged'] = all(hashlib.sha256((args.source_root / p).read_bytes()).hexdigest() == h
                                       for p, h in source_hashes.items())
        save(args.output / 'prefix-comparisons.json', prefixes)
        save(args.output / 'RESULTS.json', report)
    print(json.dumps(report, ensure_ascii=False), flush=True)
    return 0 if report['status'] == 'PASS' and report['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
