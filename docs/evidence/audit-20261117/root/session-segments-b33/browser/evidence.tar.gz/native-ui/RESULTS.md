# RC15 Companion UI / native validation attempt

## Result

**BLOCKED_BY_ENVIRONMENT. No new native or browser UI pass is claimed.**

The source is PR #15 commit `b9615c72db68bcf0ee065c884882b26d2cf0a581` (Desktop `5.0.1-rc.15`). This attempt ran on the current managed Linux x86_64 executor. It did not access the user's Mac, Intel Mac hardware, or the previously installed Test APP.

## What was actually executed

- The existing command `npm run test:ui -- tests/ui/pet-history.spec.ts --output <new evidence directory>` ran with the existing supported `LP_UI_CHROMIUM_EXECUTABLE=/usr/bin/chromium` and `LP_UI_EVIDENCE_DIR` overrides. Configuration and tests were unchanged. The command exited **1**, after **6.6008865 seconds** of outer elapsed time.
- Playwright attempted all **8** history scenarios. Its JSON reports `unexpected: 8`, `expected: 0`, `skipped: 0`. Each failed at `browserType.launch`, before page creation or UI assertions, with Chromium `process_singleton_posix.cc` reporting `socket() failed: Operation not permitted (1)`. The report retains these failures; they are classified as **8 launch blockers / 0 page-level test results**, not product assertion failures.
- A direct standard-library socket capability probe confirmed that `AF_INET` socket creation succeeds while `AF_UNIX` socket creation raises `EPERM` in this executor. No launch flags, security settings, or isolation rules were changed to bypass that restriction.
- The repository's Vite command, `npm run dev -- --port 1441 --strictPort`, returned **HTTP 200** inside the process tree which started it, with a 557-byte HTML response containing `/@vite/client`. A separate executor call to the same loopback address failed with connection refused. The Cloud Browser's navigation to the same address also failed with `net::ERR_CONNECTION_REFUSED`.
- The Browser extension tool was retried using its documented bootstrap and returned the specific missing-originating-browser-context error. The Cloud Browser fallback was then exercised and its lifecycle was completed.
- `pkg-config --modversion gtk+-3.0` and `pkg-config --modversion webkit2gtk-4.1` each exited **1** because the packages are absent. The current user is UID 1000; no sudo command was found. No native candidate was compiled or packaged here.

## Scope and remaining acceptance

No model calls were made. No production code, tests, version files, existing test apps, databases, or user services were changed. The ignored dependency link reuses an existing installation only after identical lockfile SHA-256 verification.

The owned Vite terminal session was ended with Control-C; the tool returned terminal exit code 1. Its start/readiness report is retained and is not a service-shutdown health certificate. The loopback observations establish that this process tree served Vite successfully and other observed surfaces could not reach it; they do not establish the implementation of the environment's network isolation.

Current RC15 bubble focus, pagination scroll anchoring, memory-toggle ordering, cancellation/resume, scaling, multi-display behavior, and visible animation update rate therefore remain **not measured in a real UI by this attempt**. The older RC14 Linux animation sample must not be relabeled as current RC15 evidence. Apple Silicon and Intel macOS acceptance also remain unexecuted in this environment.

## Evidence

`environment.json` contains platform, dependency-lock checks, socket results and missing native dependencies. `playwright-run.json` captures the exact command, exit code, elapsed time and test-file hash. `playwright.log` and `playwright/browser-tests.json` retain all runner failures. `vite-readiness.json` and `separate-exec-readiness.json` record the HTTP probes. `browser-observations.json` is explicitly a transcription of tool observations, including fallback errors and owned-session termination, not an independently captured browser trace. `SOURCE.json` identifies the tested product/fixture files. `MANIFEST.json` hashes all evidence payloads.
