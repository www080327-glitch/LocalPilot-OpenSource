"""Compare real persistent sessions; scripted provider, real reads and SQLite."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--turns', type=int, default=180)
    args = parser.parse_args()
    args.output.mkdir(parents=True, mode=0o700, exist_ok=False)
    sys.path.insert(0, str(args.source_root))
    from agent.backends import BackendCapabilities, BackendResponse, Message, ModelInfo, ToolCall
    from agent.engine_v5 import EngineV5Policy
    from agent.hybrid import CloudEgressPolicy, HybridPolicy
    from agent.persistence import dumps, snapshot_runtime
    from agent.registry import create_default_registry
    from agent.retry import RetryPolicy
    from agent.session import AgentSession, SessionBudgets
    from localpilot_api.service import TaskRequest, TaskService

    class Backend:
        is_local = False
        service_cache_stable_prefix = True
        capabilities = BackendCapabilities(supports_tool_calling=True)
        model_info = ModelInfo('segment-storage-fixture', 'scripted', 16000)

        def __init__(self):
            self.calls = 0
            self.last = None
            self.prefix_equal = self.prefix_comparisons = 0

        def request(self, messages, **options):
            if self.last is not None:
                self.prefix_comparisons += 1
                self.prefix_equal += messages[:len(self.last)] == self.last
            self.last = deepcopy(messages)
            self.calls += 1
            tool_calls = [ToolCall('read', 'read_file', json.dumps({'path': 'sample.txt'}))] if self.calls % 2 else []
            message = Message('assistant', None if tool_calls else f'Read completed for turn {self.calls // 2}.', tool_calls)
            return BackendResponse(message, {'prompt_tokens': 1, 'completion_tokens': 1},
                                   'scripted', 'tool_calls' if tool_calls else 'stop')

    backend = Backend()
    workspace = args.output / 'workspace'
    workspace.mkdir()
    sample = '\n'.join(f'{index:05d}: independent storage evidence item {index:05d}' for index in range(700)) + '\n'
    (workspace / 'sample.txt').write_text(sample)
    database = args.output / 'private-runtime.sqlite3'

    def factory(callback):
        registry = create_default_registry(workspace, permission_mode='full-permission')
        return AgentSession(registry, backend=backend, policy='cloud-only', streaming=False,
            engine_policy=EngineV5Policy(max_completion_repairs=0), runtime_tools=False,
            hybrid_policy=HybridPolicy(CloudEgressPolicy('CLOUD_ALLOWED', ('sample.txt',))),
            hybrid_backends={'cloud': backend}, hybrid_primary='cloud', event_callback=callback,
            budgets=SessionBudgets(max_steps=4, max_tool_calls=4, max_output_tokens=512, max_token_units=1000000),
            retry_policy=RetryPolicy(max_attempts=1))

    names = subprocess.check_output(['git', 'ls-files', 'agent', 'localpilot_api', 'localpilot_service'],
                                    cwd=args.source_root, text=True).splitlines()
    names += [p.as_posix() for p in (Path('agent/session_history.py'),) if (args.source_root / p).exists() and p.as_posix() not in names]
    hashes = {name: hashlib.sha256((args.source_root / name).read_bytes()).hexdigest() for name in names}
    report = {'kind': 'SYNTHETIC_PERSISTENT_STORAGE_PROBE', 'source_commit': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=args.source_root, text=True).strip(),
        'source_files': hashes, 'source_dirty': bool(subprocess.check_output(
        ['git', 'status', '--porcelain'], cwd=args.source_root, text=True).strip()),
        'python': platform.python_version(), 'platform': platform.platform(),
        'turns_requested': args.turns, 'real_model_calls': False,
        'threshold': 'TaskService production default; no override', 'status': 'RUNNING', 'samples': []}
    save(args.output / 'RESULTS.json', report)
    start = time.monotonic()
    service = None
    try:
        service = TaskService({'localpilot': factory}, persistence=database)
        sid = service.create_session()['id']
        obligations = ['Unverified native Intel focus test; keep its exact device requirement.',
                       'Unverified Apple Silicon animation; retain actual 24 Hz acceptance target.']
        for text in obligations:
            service.sessions[sid].runtime.goals.create(text, status='blocked')
        goals = deepcopy(service.sessions[sid].runtime._goal_records())
        first_request = first_result = first_events = None
        compactions = 0
        for turn in range(1, args.turns + 1):
            request = TaskRequest(f'Read sample.txt once for storage trial {turn}. Preserve unresolved checks.',
                session_id=sid, idempotency_key=f'storage-trial-{turn}')
            task = service.create_task(request)
            result = service.wait(task['id'])
            if result['status'] not in {'completed', 'incomplete'}:
                raise RuntimeError(f'Turn {turn} unexpectedly ended as {result["status"]}')
            if turn == 1:
                first_request, first_result = request, deepcopy(result)
                first_events = deepcopy(service.events(task['id'], wait_seconds=0)[0])
            record = service._task(task['id'])
            compactions += sum(event['type'] == 'runtime.event' and event['data']['type'] == 'ContextCompacted'
                               for event in record.events)
            runtime = service.sessions[sid].runtime
            if runtime._goal_records() != goals:
                raise RuntimeError('Exact unfinished goals changed')
            runtime_bytes = len(dumps(snapshot_runtime(runtime)).encode())
            checkpoint_bytes = service.store.connection.execute(
                'SELECT length(CAST(payload AS BLOB)) FROM checkpoints WHERE session_id=?', (sid,)).fetchone()[0]
            sample = {'turn': turn, 'runtime_bytes': runtime_bytes, 'checkpoint_bytes': checkpoint_bytes,
                      'messages': len(runtime.messages), 'receipts': len(runtime.tool_history),
                      'completed_calls': len(runtime.completed_tool_calls),
                      'hybrid_attempts': len(runtime.hybrid.state['attempts']),
                      'hybrid_egress': len(runtime.hybrid.state['egress']),
                      'active_tasks': len(service.tasks),
                      'generation': getattr(service.sessions[sid], 'history_generation', 0)}
            report['samples'].append(sample)
            if turn % 20 == 0:
                print(json.dumps(sample), flush=True)
        before = backend.calls
        report['old_idempotency_exact_no_replay'] = service.create_task(first_request) == first_result and backend.calls == before
        report['old_events_exact'] = service.events(first_result['id'], wait_seconds=0)[0] == first_events
        service.suspend()
        restart = time.monotonic()
        service = TaskService({'localpilot': factory}, persistence=database)
        report['restart_seconds'] = time.monotonic() - restart
        report['old_receipt_after_restart'] = service.task_snapshot(first_result['id']) == first_result
        report['unfinished_goals_exact_after_restart'] = service.sessions[sid].runtime._goal_records() == goals
        report['restart_model_calls'] = backend.calls - before
        report['actual_provider_requests'] = backend.calls
        report['compactions'] = compactions
        report['exact_prefix_extensions'] = backend.prefix_equal
        report['prefix_comparisons'] = backend.prefix_comparisons
        report['status'] = 'PASS' if all(report[name] for name in (
            'old_idempotency_exact_no_replay', 'old_events_exact', 'old_receipt_after_restart',
            'unfinished_goals_exact_after_restart')) and report['restart_model_calls'] == 0 else 'FAIL'
    except Exception as error:
        report['status'] = 'FAIL'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if service is not None and not service.closed:
            service.suspend()
        report['elapsed_seconds'] = time.monotonic() - start
        report['owned_service_stopped'] = service is None or service.closed
        report['source_unchanged'] = all(hashlib.sha256((args.source_root / name).read_bytes()).hexdigest() == value
                                         for name, value in hashes.items())
        report['database_bytes'] = database.stat().st_size if database.exists() else None
        save(args.output / 'RESULTS.json', report)
    print(json.dumps({key: value for key, value in report.items() if key not in {'samples', 'source_files'}}), flush=True)
    return 0 if report['status'] == 'PASS' and report['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
