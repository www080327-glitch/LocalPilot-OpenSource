import json
import hashlib
from pathlib import Path
import sys
import tempfile
from agent.backends import ModelInfo
from agent.context_budget import request_budget
from agent.context import context_units
from agent.engine_v5 import EngineV5Policy
from agent.registry import ToolRegistry
from agent.session import AgentSession, SessionBudgets
from tests.test_runtime_api import Backend, answer

capacity = int(sys.argv[2]) if len(sys.argv) > 2 else 5500
with tempfile.TemporaryDirectory() as folder:
    backend = Backend(*(answer('observation-' + str(i) + ': ' + 'evidence ' * 110) for i in range(40)))
    backend.model_info = ModelInfo('bounded-fixture', 'scripted', capacity)
    session = AgentSession(ToolRegistry(Path(folder)), backend=backend, policy='cloud-only',
        streaming=False, engine_policy=EngineV5Policy(max_completion_repairs=0), runtime_tools=False,
        budgets=SessionBudgets(max_steps=12, max_token_units=1000000, max_output_tokens=512))
    for index, detail in enumerate(('missing cancellation receipt', 'unverified file hash',
                                  'Intel native interaction', 'Companion focus restoration')):
        session.goals.create(f'Problem {index}: {detail}; exact next action is retained.', status='blocked')
    task = 'Continue all four unresolved checks with these exact details: ' + 'specific input ' * 85
    results = [session.run_turn(task).status for _ in range(40)]
    windows = [request['messages'] for request in backend.requests]
    records = {
        'kind': 'deterministic_session_context_probe', 'provider_calls': 0,
        'source_sha256': {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in ('agent/context_v5.py', 'agent/session_models.py', 'agent/session.py', 'agent/persistence.py')},
        'turns': len(results), 'incomplete_turns': results.count('incomplete'),
        'model_requests': len(windows),
        'compactions': sum(e.type == 'ContextCompacted' for e in session.events.events),
        'consecutive_exact_input_prefix_extensions': sum(a == b[:len(a)] for a, b in zip(windows, windows[1:])),
        'canonical_messages': len(session.messages),
        'final_model_window_messages': len(session._request_history.messages),
        'maximum_request_estimated_tokens_with_output_and_margin': max(request_budget(r['messages'], r['tools'], r['max_tokens'])['total_tokens'] for r in backend.requests),
        'context_token_capacity': capacity,
        'final_canonical_message_bytes': context_units(session.messages, []),
        'final_model_window_bytes': context_units(session._request_history.messages, []),
        'blocked_goal_descriptions': [g.description for g in session.goals.list()],
        'all_latest_states_keep_exact_task_and_goals': all(json.loads(v[-1].content.split('\n', 1)[1])['original_task'] == task and json.loads(v[-1].content.split('\n', 1)[1])['goals'] == session._goal_records() for v in windows),
        'interpretation': 'Synthetic model outputs; full AgentSession context/compaction implementation. This measures request layout, not model quality, native installation or unbounded canonical storage.'
    }
    session.close()
Path(sys.argv[1]).write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
