#!/usr/bin/env python3
"""Actual Luna/Responses + V5/SQLite continuation; no synthetic model replies."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
import uuid


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode()).hexdigest()


def published_payload(payload):
    result = deepcopy(payload)
    for item in result['input']:
        if 'encrypted_content' in item:
            value = item['encrypted_content']
            item['encrypted_content'] = {'omitted': True, 'sha256': fingerprint(value),
                                         'characters': len(value)}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--key-file', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(args.source_root.resolve()))
    from agent.engine_v5 import EngineV5Policy
    from agent.registry import create_default_registry
    from agent.retry import RetryPolicy
    from agent.session import AgentSession, SessionBudgets
    from agent.safety import CapabilityPolicy
    from localpilot_api.service import TaskService, TaskRequest
    from localpilot_service.backend_contract import ServiceOpenAIResponsesBackend

    source = subprocess.check_output(['git', '-C', str(args.source_root), 'rev-parse', 'HEAD'], text=True).strip()
    source_paths = subprocess.check_output(['git', '-C', str(args.source_root), 'ls-files',
        'agent', 'localpilot_api', 'localpilot_service'], text=True).splitlines()
    source_hashes = {p: hashlib.sha256((args.source_root / p).read_bytes()).hexdigest()
                     for p in source_paths}
    requests, responses, prefixes = [], [], []

    class ObservedBackend(ServiceOpenAIResponsesBackend):
        def _payload(self, *values, **options):
            payload = super()._payload(*values, **options)
            if requests:
                previous = requests[-1]
                prefixes.append({'from': len(requests), 'to': len(requests) + 1,
                    'previous_input_items': len(previous['input']),
                    'input_prefix_equal': payload['input'][:len(previous['input'])] == previous['input'],
                    'tools_equal': payload.get('tools') == previous.get('tools'),
                    'reasoning_equal': payload.get('reasoning') == previous.get('reasoning')})
            requests.append(deepcopy(payload))
            save(args.output / f'request-{len(requests):02}.json', published_payload(payload))
            return payload

        def _response(self, data):
            response = super()._response(data)
            responses.append({'model': response.model, 'finish_reason': response.finish_reason,
                'usage': response.usage, 'diagnostics': response.diagnostics,
                'reasoning_output_ids': [item['id'] for item in data['output']
                                         if item['type'] == 'reasoning']})
            save(args.output / 'responses.json', responses)
            return response

    workspace = args.output / 'workspace'
    workspace.mkdir()
    markers = ['LP-CONTEXT-' + uuid.uuid4().hex[:12] for _ in range(3)]
    (workspace / 'first.txt').write_text(f'Marker: {markers[0]}\nNext file: second.txt\n')
    (workspace / 'second.txt').write_text(f'Marker: {markers[1]}\n')
    (workspace / 'third.txt').write_text(f'Marker: {markers[2]}\n')
    save(args.output / 'fixtures.json', {'markers': markers})

    def factory(callback=None):
        backend = ObservedBackend(model='gpt-6-luna', key_file=args.key_file,
                                  timeout=60, effective_context=65536)
        registry = create_default_registry(workspace, permission_mode='full-permission',
            capabilities=CapabilityPolicy(read=True, write=False, execute=False, read_only=True))
        return AgentSession(registry, backend=backend, policy='cloud-only', thinking='medium',
            streaming=False, event_callback=callback, engine_policy=EngineV5Policy(),
            runtime_tools=False, budgets=SessionBudgets(max_steps=8, max_tool_calls=8,
                max_token_units=2000000, max_output_tokens=2048),
            retry_policy=RetryPolicy(max_attempts=1))

    database = args.output / 'private-runtime.sqlite'
    first_prompt = ('Read first.txt, then read only the next file named inside it. '
                    'Reply with the two exact markers in order. Use read_file to obtain both; '
                    'do not list the directory or modify any file.')
    next_prompt = ('Continue our earlier task. Read third.txt only. Reply with the two markers '
                   'from our preceding exchange followed by the new third marker. '
                   'Do not reread the first two files or list the directory.')
    save(args.output / 'prompts.json', [first_prompt, next_prompt])
    report = {'kind': 'LIVE_PERSISTENT_CONTEXT_INTEGRATION', 'source_commit': source,
        'model': 'gpt-6-luna', 'protocol': 'responses', 'reasoning': 'medium',
        'host': platform.platform(), 'python': platform.python_version(),
        'scope': 'Synthetic file-reading, restart and archived idempotency; not an AA score or long-run soak.',
        'request_payload_transform': 'Only encrypted reasoning content replaced by exact-value digest/length.',
        'status': 'RUNNING', 'started_at_unix': time.time(), 'balance_queried': False}
    save(args.output / 'source-hashes.json', source_hashes)
    save(args.output / 'RESULTS.json', report)
    started = time.monotonic()
    service = None
    try:
        service = TaskService({'luna': factory}, persistence=database, max_tasks=1)
        session_id = service.create_session('luna')['id']
        first_request = TaskRequest(first_prompt, model='luna', session_id=session_id,
            timeout_seconds=180, idempotency_key='persistent-context-first')
        first_task = service.create_task(first_request)
        service.wait(first_task['id'])
        first = service.task_snapshot(first_task['id'])
        save(args.output / 'task-first.json', first)
        if first['status'] != 'completed':
            raise RuntimeError('First live task did not complete: ' + first['status'])
        service.suspend()
        service = TaskService({'luna': factory}, persistence=database, max_tasks=1)
        before_restart_query = len(requests)
        restored = service.task_snapshot(first['id'])
        report['restart_preserved_result_without_model_request'] = (
            restored['result'] == first['result'] and len(requests) == before_restart_query)
        second_task = service.create_task(TaskRequest(next_prompt, model='luna', session_id=session_id,
            timeout_seconds=180, idempotency_key='persistent-context-next'))
        service.wait(second_task['id'])
        second = service.task_snapshot(second_task['id'])
        save(args.output / 'task-next.json', second)
        before_replay = len(requests)
        replay = service.create_task(first_request)
        report['archived_idempotency_without_model_request'] = (
            replay['id'] == first['id'] and replay['result'] == first['result'] and len(requests) == before_replay)
        texts = [str((task['result'] or {}).get('text', '')) for task in (first, second)]
        report['semantic_pass'] = (all(marker in texts[0] for marker in markers[:2])
            and all(marker in texts[1] for marker in markers) and second['status'] == 'completed')
        report['input_prefix_pass'] = bool(prefixes) and all(p['input_prefix_equal'] for p in prefixes)
        report['tools_and_reasoning_stable'] = all(p['tools_equal'] and p['reasoning_equal'] for p in prefixes)
        report['compactions'] = sum(event['data']['type'] == 'ContextCompacted'
            for task in service.tasks.values() for event in task.events if event['type'] == 'runtime.event')
        report['status'] = 'PASS' if all(report[k] for k in ('semantic_pass', 'input_prefix_pass',
            'tools_and_reasoning_stable', 'restart_preserved_result_without_model_request',
            'archived_idempotency_without_model_request')) else 'FAIL'
    except Exception as error:
        report['status'] = 'FAIL'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if service is not None and not service.closed:
            service.shutdown(timeout=10)
        report.update(elapsed_seconds=time.monotonic() - started, requests=len(requests),
                      provider_responses=len(responses), owned_service_stopped=service is None or service.closed)
        report['source_unchanged'] = all(hashlib.sha256((args.source_root / p).read_bytes()).hexdigest() == h
                                       for p, h in source_hashes.items())
        save(args.output / 'prefix-comparisons.json', prefixes)
        save(args.output / 'RESULTS.json', report)
    print(json.dumps(report, ensure_ascii=False), flush=True)
    return 0 if report['status'] == 'PASS' and report['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
