"""Publish byte-preserving archives from an audited explicit file allowlist."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--secret-file', type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    base = args.plan.parent.resolve()
    secret = args.secret_file.read_bytes().strip()
    if not secret:
        raise ValueError('Credential scan input is empty')
    args.output.mkdir(parents=True, exist_ok=False)
    groups = [archive(base, args.output, group, secret) for group in plan['groups']]
    report = {'source_commit': plan['source_commit'], 'source_tree': plan['source_tree'],
              'kind': 'BYTE_PRESERVING_PUBLIC_EVIDENCE', 'groups': groups,
              'groups_count': len(groups), 'files_count': sum(group['files_count'] for group in groups),
              'known_credential_matches': 0, 'private_runtime_and_wheels_excluded': True,
              'packager_sha256': sha(Path(__file__).read_bytes()),
              'plan_sha256': sha(args.plan.read_bytes())}
    write(args.output / 'MANIFEST.json', report)
    (args.output / 'SHA256SUMS').write_text(''.join(group['sha256'] + '  ' + group['archive'] + '\n' for group in groups))
    lines = ['# RC17 续作原始证据', '',
             '| 证据组 | 内容 | 文件数 | 归档 | 清单 |', '|---|---|---:|---|---|']
    for group in groups:
        lines.append(f"| {group['name']} | {group['description']} | {group['files_count']} | [{group['archive']}]({group['archive']}) | [{group['manifest']}]({group['manifest']}) |")
    lines += ['', '仅公开明确列入清单的文件。原始字节、失败和跳过保留；私有 runtime、凭据、SQLite、模型和 wheel 不在归档内。', '']
    (args.output / 'SUMMARY.md').write_text('\n'.join(lines))
    print(json.dumps({key: report[key] for key in ['groups_count', 'files_count', 'known_credential_matches']}))


def archive(base, output, group, secret):
    target = output / (group['name'] + '.tar.gz')
    members = []
    forbidden = {'core-private', 'private', '.venv', 'runtime', 'node_modules', '.git', 'wheels', 'workspace'}
    with target.open('wb') as stream, gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for relative in sorted(group['files']):
                path = base / relative
                if (path.is_symlink() or not path.resolve().is_relative_to(base)
                        or forbidden & set(Path(relative).parts)
                        or '.sqlite' in path.name or path.suffix in {'.db', '.key', '.pem', '.whl'}):
                    raise ValueError('Private or external input: ' + relative)
                content = path.read_bytes()
                if secret in content:
                    raise ValueError('Credential match in public candidate: ' + relative)
                info = tarfile.TarInfo(relative)
                info.size, info.mode, info.mtime = len(content), 0o644, 0
                archive.addfile(info, io.BytesIO(content))
                members.append({'path': relative, 'bytes': len(content), 'original_sha256': sha(content)})
    with tarfile.open(target, 'r:gz') as check:
        for member in members:
            content = check.extractfile(member['path']).read()
            member['public_sha256'] = sha(content)
            if member['public_sha256'] != member['original_sha256'] or len(content) != member['bytes']:
                raise ValueError('Archive round-trip mismatch: ' + member['path'])
    result = {'name': group['name'], 'description': group['description'], 'archive': target.name,
              'sha256': sha(target.read_bytes()), 'bytes': target.stat().st_size,
              'manifest': group['name'] + '.MANIFEST.json', 'files_count': len(members)}
    write(output / result['manifest'], result | {'files': members})
    return result


def sha(content):
    return hashlib.sha256(content).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__':
    main()
