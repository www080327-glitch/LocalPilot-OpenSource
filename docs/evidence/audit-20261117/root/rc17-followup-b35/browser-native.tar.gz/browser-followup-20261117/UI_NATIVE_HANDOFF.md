# RC17 浏览器与原生门禁续验

基线：PR #15，`6c923a95c749d1db2c6d2548e2109cd79b02d938`。本项不修改源码、测试断言、依赖锁或 Chromium 参数。

## 结果

- 使用仓库原有 `LP_UI_CHROMIUM_EXECUTABLE` 配置及系统 Chromium 156.0.8078.79，原样运行 `tests/ui/model-configuration.spec.ts` 两项用例。
- 两项均在 `browserType.launch` 失败，底层报 `process_singleton_posix.cc:297 socket() failed: Operation not permitted (1)`；Playwright 退出码 1，2 unexpected，0 expected，0 skipped。
- **页面断言执行数 0，结果为 BLOCKED_AT_LAUNCH。** 这不能说明 UI 正确或错误。没有添加启动参数、修改测试以跳过或放宽检查。
- 核对旧 checkout 与当前的 `package.json`、`package-lock.json`、Playwright 配置和受测文件逐字相同后，通过 ignored symlink 复用旧 `node_modules`。未安装或升级依赖。
- Linux 执行器没有 `cargo` / `rustc`；pkg-config 找不到 GTK3、WebKitGTK 4.1、JavaScriptCoreGTK 4.1、Ayatana AppIndicator 或 libsoup 3 开发包；受支持的 `cloud-agent-packages` helper 不存在。
- 单独检查了 CUA / Sky 原生桌面：桌面连接可用，应用列表中没有 LocalPilot，也没有已打开窗口。不能将执行器缺少 DISPLAY 概括为整套 Cloud desktop 不存在。
- 当前候选的 Linux 原生构建、原生交互、Apple Silicon 和 Intel Mac 均未在这里运行。旧 RC14 原生证据未更改。

## Work 续接要点

1. 在支持 Chromium 正常启动的主机，核对最新候选 SHA 并建立独立 worktree。读取 `desktop/AGENTS.md`，使用项目锁文件和原有 `npm run test:ui`。首次补跑可用：

   ```sh
   cd desktop
   LP_UI_EVIDENCE_DIR="$LP_RUN/browser" npm run test:ui -- tests/ui/model-configuration.spec.ts --output="$LP_RUN/browser/test-results"
   ```

   若系统 Chromium 才可用，使用仓库已有 `LP_UI_CHROMIUM_EXECUTABLE`；不改断言、不把失败改 skip。保存原始 reporter JSON、日志、截图/trace，确认两项实际完成页面断言。

2. Apple Silicon Mac：按 `desktop/README.md` 和 `docs/development/MAC_PORTABILITY_20261114.md`，从当前候选四组件构建 wheels，准备并核验匹配架构的 `src-tauri/bundled-backends/`。隔离 GUI 构建使用现有入口：

   ```sh
   cd desktop
   LP_GUI_TEST_CONFIG=src-tauri/tauri.test.conf.json LP_GUI_USE_INSTALLED_DEPS=1 scripts/build-macos.sh
   ```

   `LP_GUI_USE_INSTALLED_DEPS=1` 仅在锁文件对应依赖已安装核对之后使用。不能用以前 RC17/b34 wheel 替换本轮修改后的 Core。归档、签名、架构、实际载入模块和源码对应都要核对。

3. Intel Mac：按 `desktop/docs/development/INTEL_MAC_20261116.md` 在真实 x86_64 Mac 构建。固定 watchdog / cryptography 依赖需要原生源码构建并生成真实产物哈希，不能拿 arm64 APP 代替。没有 Intel 主机就保留 NOT_RUN。

4. Linux：在具备项目所需 Rust/GTK/WebKitGTK 和正常桌面的匹配发行版、架构上，按 `desktop/docs/development/LINUX_20261116.md` 以系统 Python 构建匹配平台资源，使用 `scripts/build-linux.sh`。构建和安装证据要记录实际 OS/Python/架构；不能继承旧 RC14 原生通过结论。

5. 原生交互至少覆盖：冷启动/重启、模型角色选择保存、同一伙伴兼任、取消伙伴或改为主模型时清理角色；桌宠气泡焦点/输入/退出、拖动与六边缘姿态、缩放、多显示器、减少动态效果。测试安装用 `io.localpilot.desktop.test`、私有测试根及 owner 记录，按现有 installer plan/receipt 流程；保留日常应用和用户数据。

6. 动画用既有 `measure_animation` / `pet-animation-probe.json` 入口留存实际变化帧数据，同时观察/记录原生可见动画。既有探针采样 `.edge-sprite/.edge-water` 的几何/样式变化，不能只凭 requestAnimationFrame 数量宣称 ≥24 Hz。没有多显示器或有效动态段就分别标 NOT_RUN，不造 PASS。

7. 整理到新的 dated evidence 目录，区分测试夹具桥接、真实原生和真实模型；继续更新 PR #15，不把前端测试通过当作完整发布门禁通过。
