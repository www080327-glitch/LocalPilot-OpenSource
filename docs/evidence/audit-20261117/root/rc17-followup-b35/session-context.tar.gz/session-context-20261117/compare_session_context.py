"""Same-machine comparison using the actual RC17 and candidate implementations."""
from pathlib import Path
import hashlib
import json
import platform
import sqlite3
import statistics
import subprocess
import sys
import tempfile
import time
import types

ROOT = Path('/workspace/scratch/b0df9966d470/LocalPilot')
OUT = Path(__file__).resolve().parent
BASE = '6c923a95c749d1db2c6d2548e2109cd79b02d938'
sys.path.insert(0, str(ROOT))
from companion.memory.task_store import TaskStore
from companion.runtime.tasks import TaskController


def historical_module(path):
    source = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
    module = types.ModuleType('historical_' + Path(path).stem)
    exec(compile(source, BASE + ':' + path, 'exec'), module.__dict__)
    return module, hashlib.sha256(source).hexdigest()


def controller(cls, store):
    service = types.SimpleNamespace(store=types.SimpleNamespace(tasks=store),
                                    config=types.SimpleNamespace(localpilot_endpoint='synthetic'))
    return cls(service)


def record(index, revision='initial'):
    return {'timestamp': index, 'endpoint':'synthetic', 'transport':{'scope':'synthetic'},
            'result':{'session_id':'shared-session'},
            'last_status':{'status':'completed', 'agent_response':'synthetic response ' * 1000},
            'request':{'user_request':f'Question {index} {revision} ' + 'synthetic context ' * 100,
                       'relevant_memories':[], 'relevant_files':[], 'recent_events':[]}}


def samples(operation):
    operation()
    values = []
    for _ in range(5):
        start = time.perf_counter_ns()
        assert operation() is True
        values.append((time.perf_counter_ns() - start) / 1e6)
    return {'median_ms':statistics.median(values), 'warm_samples_ms':values}


def payload_digest(db):
    digest = hashlib.sha256()
    for row in db.execute('SELECT task_id,payload FROM localpilot_tasks ORDER BY task_id'):
        digest.update(json.dumps(list(row), ensure_ascii=False).encode())
    return digest.hexdigest()


def main():
    old_store, old_store_hash = historical_module('companion/memory/task_store.py')
    old_tasks, old_tasks_hash = historical_module('companion/runtime/tasks.py')
    report = {'baseline_commit':BASE, 'python':sys.version, 'platform':platform.platform(),
        'baseline_files':{'companion/memory/task_store.py':old_store_hash,
                          'companion/runtime/tasks.py':old_tasks_hash},
        'candidate_files':{path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in
                           ('companion/memory/task_store.py','companion/runtime/tasks.py')},
        'scope':'Real TaskStore and TaskController; synthetic same-session history; one shared empty dependency set; no HTTP, model or native UI measurement.',
        'method':'Baseline then candidate sequentially, one warmup and five timed steady queries; migration and old-writer invalidation/backfill reported separately.',
        'cases':[]}
    with tempfile.TemporaryDirectory(prefix='localpilot-session-context-') as directory:
        for count in (1000, 10000):
            base_db = sqlite3.connect(Path(directory)/f'baseline-{count}.sqlite3')
            base_db.row_factory = sqlite3.Row
            base_db.executescript('PRAGMA journal_mode=WAL; PRAGMA secure_delete=ON; CREATE TABLE state(key TEXT PRIMARY KEY,value TEXT NOT NULL);')
            baseline = old_store.TaskStore(base_db)
            with base_db:
                base_db.executemany(old_store.INSERT, (baseline._row(str(i),record(i)) for i in range(count)))
            baseline_controller = controller(old_tasks.TaskController, baseline)
            row = {'task_count':count,
                   'stored_payload_bytes':base_db.execute('SELECT sum(length(CAST(payload AS BLOB))) FROM localpilot_tasks').fetchone()[0],
                   'baseline':samples(lambda:baseline_controller.session_context_current('shared-session'))}
            before = payload_digest(base_db)
            db = sqlite3.connect(Path(directory)/f'candidate-{count}.sqlite3')
            db.row_factory = sqlite3.Row
            base_db.backup(db)
            start = time.perf_counter_ns()
            candidate = TaskStore(db)
            row['one_time_existing_row_upgrade_ms'] = (time.perf_counter_ns()-start)/1e6
            row['complete_payloads_and_ids_unchanged'] = payload_digest(db) == before
            current_controller = controller(TaskController, candidate)
            row['candidate'] = samples(lambda:current_controller.session_context_current('shared-session'))
            row['steady_projection_rows'] = len(list(candidate.session_contexts('synthetic','shared-session')))
            row['steady_pending_payload_rows'] = db.execute('SELECT count(*) FROM localpilot_tasks WHERE context_request IS NULL').fetchone()[0]
            row['query_plans'] = {query:[list(item) for item in db.execute('EXPLAIN QUERY PLAN '+query)] for query in (
                "SELECT DISTINCT context_request FROM localpilot_tasks WHERE session_id='shared-session' AND endpoint='synthetic'",
                'SELECT task_id,payload FROM localpilot_tasks WHERE context_request IS NULL')}
            statements = []
            db.set_trace_callback(statements.append)
            assert current_controller.session_context_current('shared-session')
            db.set_trace_callback(None)
            row['steady_sql_trace'] = statements
            previous_writer = old_store.TaskStore(db)
            previous_writer.put('0', record(0,'old-version-single-write'))
            row['old_single_write_pending'] = db.execute('SELECT count(*) FROM localpilot_tasks WHERE context_request IS NULL').fetchone()[0]
            start=time.perf_counter_ns()
            assert current_controller.session_context_current('shared-session')
            row['old_single_write_first_query_ms']=(time.perf_counter_ns()-start)/1e6
            with db:
                db.executemany(old_store.INSERT+old_store.UPDATE,
                    (previous_writer._row(str(i),record(i,'old-version-batch')) for i in range(count)))
            row['old_batch_write_pending'] = db.execute('SELECT count(*) FROM localpilot_tasks WHERE context_request IS NULL').fetchone()[0]
            start=time.perf_counter_ns()
            assert current_controller.session_context_current('shared-session')
            row['old_batch_write_first_query_ms']=(time.perf_counter_ns()-start)/1e6
            row['pending_after_backfill'] = db.execute('SELECT count(*) FROM localpilot_tasks WHERE context_request IS NULL').fetchone()[0]
            row['steady_after_backfill'] = samples(lambda:current_controller.session_context_current('shared-session'))
            report['cases'].append(row)
            db.close();base_db.close()
    report['limitations'] = ['SQLite still scans the smaller covering index for the requested session.',
        'Distinct dependency sets are revalidated on every request; all-unique dependencies remain proportional to their actual count.',
        'The legacy batch update setup uses the unchanged RC17 UPSERT SQL; it is not an HTTP workload.',
        'Initial row projection and invalidated old-writer rows require full payload reads once, as separately timed above.']
    (OUT/'PERF_COMPARISON.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
