import importlib,importlib.metadata,inspect,json,pathlib,sys,sysconfig
modules={n:importlib.import_module(n).__file__ for n in ('agent','localpilot_service','localpilot_suite','localpilot_channels','companion','companion.memory.task_store','companion.runtime.tasks')}
assert all(pathlib.Path(p).resolve().is_relative_to(sys.prefix) for p in modules.values())
names=('localpilot-agent-service','localpilot-suite','localpilot-companion','localpilot-channels','watchdog','psutil','pypdf','Pillow','defusedxml')
origins={n:json.loads(importlib.metadata.distribution(n).read_text('direct_url.json')) for n in names[:4]}
capabilities=importlib.import_module('localpilot_service.protocol').manifest()['capabilities']
assert 'worker_roles_v1' in capabilities
assert 'worker_roles' in inspect.signature(importlib.import_module('agent.session').AgentSession).parameters
assert hasattr(importlib.import_module('agent.session').AgentSession,'_recover_worker_output')
assert hasattr(importlib.import_module('companion.memory.task_store').TaskStore,'session_contexts')
print(json.dumps({'imports':modules,'versions':{n:importlib.metadata.version(n) for n in names},'wheel_origins':origins,'capabilities':capabilities,'service_version':importlib.import_module('localpilot_service').VERSION,'sqlite_schema':importlib.import_module('agent.persistence').SQLiteRuntimeStore.VERSION,'prefix':sys.prefix,'paths':sysconfig.get_paths(),'sys_path':sys.path},indent=2))
