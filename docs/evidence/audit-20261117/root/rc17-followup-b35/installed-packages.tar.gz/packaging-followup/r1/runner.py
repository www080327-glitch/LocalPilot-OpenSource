"""Build frozen Core/Companion wheels and verify a fresh installed composition."""
import argparse
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import subprocess
import sys
import tarfile
import time
import tomllib
from urllib.parse import unquote, urlsplit
import zipfile


EXPECTED = {'localpilot-agent-service': '5.0.0b35', 'localpilot-companion': '0.5.7b12',
            'localpilot-suite': '0.2.0b34', 'localpilot-channels': '0.1.0a4'}
DEPENDENCIES = ['psutil==7.2.2', 'pypdf==6.21.4', 'Pillow==12.3.0', 'defusedxml==0.7.1', 'watchdog==6.0.0']
OLD_MODULES = ['tests.test_worker_role_routes', 'tests.test_hybrid_history_rotation',
               'tests.test_context_v5', 'tests.test_engine_v5', 'tests.test_worker_role_runtime']
NEW_MODULES = ['tests.test_worker_output_recovery', 'companion.tests.test_task_store',
               'companion.tests.test_task_history', 'companion.tests.test_pa_context_lineage']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--root', type=Path, default=Path('/workspace/scratch/b0df9966d470/LocalPilot'))
    parser.add_argument('--out', type=Path, default=Path('/workspace/scratch/b0df9966d470/validation/packaging-followup/r1'))
    parser.add_argument('--previous', type=Path, default=Path('/workspace/scratch/c0f3ec78c621/validation/dispatch-20261117/packaging/r1'))
    args = parser.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    commit = git(root, 'rev-parse', args.source_commit + '^{commit}').strip()
    assert commit == args.source_commit and git(root, 'rev-parse', 'HEAD').strip() == commit
    assert not git(root, 'status', '--porcelain').strip(), 'Freeze the worktree before installation qualification'
    assert sys.version_info[:2] == (3, 12), sys.version
    out.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(__file__, out / 'runner.py')
    stage, wheels_dir = out / 'source', out / 'wheels'
    stage.mkdir(); wheels_dir.mkdir()
    env = {k: v for k, v in os.environ.items() if k not in {
        'PYTHONPATH', 'PYTHONHOME', 'LOCALPILOT_SOURCE', 'TMPDIR',
        'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'DEEPSEEK_API_KEY'}}
    env.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    record = {'source_commit': commit, 'source_tree': git(root, 'rev-parse', commit + '^{tree}').strip(),
              'start_utc': now(), 'python': sys.version, 'platform': platform.platform(),
              'build_tools': {n: importlib.metadata.version(n) for n in ('build', 'setuptools', 'wheel')},
              'expected_versions': EXPECTED, 'dependency_pins': DEPENDENCIES,
              'commands': [], 'system_install': False, 'real_model_calls': False,
              'temp_directory_policy': 'Default system tempfile directory; TMPDIR override removed'}
    selected, configs = frozen_sources(root, commit)
    before = {name: hashlib.sha256(git_bytes(root, 'show', f'{commit}:{name}')).hexdigest() for name in selected}
    write_json(out / 'source-before.json', before)
    try:
        archive = out / 'source.tar'
        run(['git', 'archive', '--format=tar', '--output', archive, commit, *selected], 'stage.log', root, env, out, record)
        with tarfile.open(archive) as source:
            source.extractall(stage, filter='data')
        assert all(sha(stage / name) == value for name, value in before.items())
        record['stage'] = {'kind': 'git archive of frozen code, tests and declared package data',
                           'archive_sha256': sha(archive), 'files': len(before)}
        for project in ('.', 'companion'):
            run([sys.executable, '-m', 'build', '--wheel', '--no-isolation', '--outdir', wheels_dir, project],
                'build-' + ('core' if project == '.' else project) + '.log', stage, env, out, record)
        built = sorted(wheels_dir.glob('*.whl'))
        assert len(built) == 2
        previous = json.loads((args.previous / 'run.json').read_text())
        reused = []
        for row in previous['wheels']:
            if row['file'].startswith(('localpilot_suite-', 'localpilot_channels-')):
                path = args.previous / 'wheels' / row['file']
                assert sha(path) == row['sha256'], ('Reused wheel hash mismatch', path.name)
                reused.append(path)
        assert len(reused) == 2
        wheels = sorted([*built, *reused])
        record['composition'] = {'new_core_companion_commit': commit,
            'reused_suite_channels_commit': previous['source_commit'],
            'reused_evidence': str(args.previous / 'run.json'), 'reused_hashes_verified': True}
        record['wheels'] = [{'file': p.name, 'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p),
            'source_commit': commit if p in built else previous['source_commit'],
            'built_this_run': p in built} for p in wheels]
        runtime = out / 'runtime'
        run([sys.executable, '-m', 'venv', runtime], 'venv.log', out, env, out, record)
        python = runtime / 'bin/python'
        run([python, '-m', 'pip', '--disable-pip-version-check', 'install', '--no-input', *DEPENDENCIES],
            'dependencies.log', out, env, out, record)
        run([python, '-m', 'pip', '--disable-pip-version-check', 'install', '--no-index', '--no-deps', *wheels],
            'install.log', out, env, out, record)
        run([python, '-I', '-m', 'pip', 'check'], 'pip-check.log', out, env, out, record)
        probe = out / 'import_probe.py'
        probe.write_text(IMPORT_PROBE)
        run([python, '-I', probe], 'import-proof.json', out, env, out, record, command_header=False)
        proof = json.loads((out / 'import-proof.json').read_text())
        assert {name: proof['versions'][name] for name in EXPECTED} == EXPECTED
        assert proof['service_version'] == EXPECTED['localpilot-agent-service'] and proof['sqlite_schema'] == 3
        by_path = {str(p.resolve()): sha(p) for p in wheels}
        for origin in proof['wheel_origins'].values():
            path = str(Path(unquote(urlsplit(origin['url']).path)).resolve())
            assert path in by_path and origin['archive_info']['hashes']['sha256'] == by_path[path]
            assert not origin.get('dir_info', {}).get('editable')
        run([python, '-I', '-m', 'localpilot_suite.cli', '--version'], 'cli-version.log', out, env, out, record)
        verified = compare_payloads(stage, wheels, configs, proof)
        write_json(out / 'installed-source-manifest.json', verified)
        record['verified_files_by_wheel'] = {name: {'all_payload': len(rows),
            'python_swift': sum(row['path'].endswith(('.py', '.swift')) and '.data/' not in row['path']
                                and '.dist-info/' not in row['path'] for row in rows)}
            for name, rows in verified.items()}
        harness = out / 'harness'
        harness.mkdir()
        shutil.copytree(stage / 'tests', harness / 'tests', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        shutil.copytree(stage / 'companion/tests', harness / 'companion/tests', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        harness_runner = harness / 'installed_tests.py'
        harness_runner.write_text(INSTALLED_TESTS)
        write_json(harness / 'modules.json', {'previous': OLD_MODULES, 'new': NEW_MODULES})
        test_env = {**env, 'LOCALPILOT_SOURCE': proof['paths']['purelib']}
        record['harness_kind'] = 'Unmodified frozen repository tests only; product code imports from new wheel installation. Companion fixture LOCALPILOT_SOURCE points to installed site-packages.'
        run([python, '-I', '-B', harness_runner], 'tests.log', harness, test_env, out, record)
        record['tests'] = json.loads((harness / 'test-result.json').read_text())
        assert record['tests']['groups']['previous'] == 36
        assert record['tests']['successful'] and record['tests']['skipped'] == 0
        assert compare_payloads(stage, wheels, configs, proof) == verified
        record['installed_sources_unchanged_after_tests'] = True
        run([python, '-I', '-m', 'pip', 'check'], 'pip-check-after-tests.log', out, env, out, record)
        record['status'] = 'PASS'
    except Exception as error:
        record.update(status='FAILED', failure=type(error).__name__, failure_message=str(error))
        raise
    finally:
        after = {name: sha(stage / name) for name in before if (stage / name).is_file()}
        write_json(out / 'source-after.json', after)
        record['frozen_stage_unchanged'] = before == after
        record['source_changes'] = sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k))
        record['live_head_after'] = git(root, 'rev-parse', 'HEAD').strip()
        record['live_selected_source_unchanged'] = all((root / n).is_file() and sha(root / n) == h for n, h in before.items())
        record['end_utc'] = now()
        if record.get('status') == 'PASS' and not record['frozen_stage_unchanged']:
            record['status'] = 'FAILED_SOURCE_CHANGED'
        write_json(out / 'run.json', record)
        print(json.dumps({k: record.get(k) for k in ('status', 'tests', 'verified_files_by_wheel', 'frozen_stage_unchanged', 'source_changes')}), flush=True)
    if record['status'] != 'PASS':
        raise SystemExit(1)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_bytes(root, *args):
    return subprocess.check_output(['git', *args], cwd=root)


def git(root, *args):
    return git_bytes(root, *args).decode()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def frozen_sources(root, commit):
    tracked = set(git(root, 'ls-tree', '-r', '--name-only', commit).splitlines())
    roots = {'agent', 'computer', 'localpilot_api', 'localpilot_service', 'localpilot_plugins',
             'localpilot_channels', 'companion', 'suite', 'channels', 'integrations', 'tests', 'scripts'}
    selected = {name for name in tracked if
        (PurePosixPath(name).parts[0] in roots or name in {'catalog.py', 'recommender.py', 'hardware.py', 'selector_mlp.py', 'pyproject.toml'})
        and PurePosixPath(name).suffix in {'.py', '.swift', '.mjs', '.json', '.toml'}
        and not set(PurePosixPath(name).parts) & {'build', 'dist', 'node_modules', '__pycache__', 'evidence'}}
    configs = {}
    for project in ('', 'companion', 'suite', 'channels'):
        file = str(PurePosixPath(project) / 'pyproject.toml')
        config = tomllib.loads(git(root, 'show', f'{commit}:{file}'))
        configs[config['project']['name']] = (project, config)
        assert config['project']['version'] == EXPECTED[config['project']['name']]
        selected.add(file)
        prefix = '' if project == 'channels' else project
        for sources in config['tool']['setuptools'].get('data-files', {}).values():
            selected.update(str(PurePosixPath(prefix) / name) for name in sources)
        selected.update(str(PurePosixPath(prefix) / name) for name in config['project'].get('license-files', []))
        for package, patterns in config['tool']['setuptools'].get('package-data', {}).items():
            package_path = PurePosixPath(project) / ('' if project == 'companion' and package == 'companion' else package.replace('.', '/'))
            for pattern in patterns:
                selected.update(name for name in tracked if PurePosixPath(name).match(str(package_path / pattern)))
    assert selected <= tracked, sorted(selected - tracked)
    return sorted(selected), configs


def run(command, log, cwd, env, out, record, *, command_header=True):
    step = {'argv': list(map(str, command)), 'cwd': str(cwd), 'log': log, 'start_utc': now()}
    record['commands'].append(step)
    started = time.monotonic()
    with (out / log).open('w') as stream:
        if command_header:
            stream.write(json.dumps(step['argv']) + '\n'); stream.flush()
        result = subprocess.run(step['argv'], cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
    step.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started, end_utc=now())
    write_json(out / 'PROGRESS.json', record)
    print(json.dumps({'log': log, 'exit_code': result.returncode, 'seconds': step['elapsed_seconds']}), flush=True)
    result.check_returncode()


def compare_payloads(stage, wheels, configs, proof):
    from email.parser import Parser
    verified = {}
    for wheel in wheels:
        rows = []
        with zipfile.ZipFile(wheel) as archive:
            metadata = next(n for n in archive.namelist() if n.endswith('.dist-info/METADATA'))
            distribution = Parser().parsestr(archive.read(metadata).decode())['Name']
            project, config = configs[distribution]
            prefix = '' if project == 'channels' else project
            data_sources = {str(PurePosixPath(destination) / PurePosixPath(name).name): str(PurePosixPath(prefix) / name)
                            for destination, names in config['tool']['setuptools'].get('data-files', {}).items() for name in names}
            for name in archive.namelist():
                assert not name.endswith(('.sqlite3', '.sqlite', '.db', '.key')) and PurePosixPath(name).name not in {'.env', 'credentials.json'}, name
                if '.dist-info/' in name:
                    if '.dist-info/licenses/' not in name:
                        continue
                    source = stage / prefix / name.split('.dist-info/licenses/', 1)[1]
                    installed = Path(proof['paths']['purelib']) / name
                elif '.data/data/' in name:
                    relative = name.split('.data/data/', 1)[1]
                    source = stage / data_sources[relative]
                    installed = Path(proof['paths']['data']) / relative
                else:
                    assert '.data/' not in name, ('Unhandled wheel payload', name)
                    source = stage / ('suite' if name.startswith('localpilot_suite/') else '') / name
                    installed = Path(proof['paths']['purelib']) / name
                payload = archive.read(name)
                digest = hashlib.sha256(payload).hexdigest()
                assert source.read_bytes() == payload, ('Frozen source mismatch', wheel.name, name)
                assert installed.read_bytes() == payload, ('Installed payload mismatch', wheel.name, name)
                rows.append({'path': name, 'source_path': str(source.relative_to(stage)),
                             'installed_path': str(installed), 'bytes': len(payload), 'sha256': digest})
        verified[wheel.name] = rows
    return verified


IMPORT_PROBE = '''import importlib,importlib.metadata,inspect,json,pathlib,sys,sysconfig
modules={n:importlib.import_module(n).__file__ for n in ('agent','localpilot_service','localpilot_suite','localpilot_channels','companion','companion.memory.task_store','companion.runtime.tasks')}
assert all(pathlib.Path(p).resolve().is_relative_to(sys.prefix) for p in modules.values())
names=('localpilot-agent-service','localpilot-suite','localpilot-companion','localpilot-channels','watchdog','psutil','pypdf','Pillow','defusedxml')
origins={n:json.loads(importlib.metadata.distribution(n).read_text('direct_url.json')) for n in names[:4]}
capabilities=importlib.import_module('localpilot_service.protocol').manifest()['capabilities']
assert 'worker_roles_v1' in capabilities
assert 'worker_roles' in inspect.signature(importlib.import_module('agent.session').AgentSession).parameters
assert hasattr(importlib.import_module('agent.session').AgentSession,'_recover_worker_output')
assert hasattr(importlib.import_module('companion.memory.task_store').TaskStore,'session_contexts')
print(json.dumps({'imports':modules,'versions':{n:importlib.metadata.version(n) for n in names},'wheel_origins':origins,'capabilities':capabilities,'service_version':importlib.import_module('localpilot_service').VERSION,'sqlite_schema':importlib.import_module('agent.persistence').SQLiteRuntimeStore.VERSION,'prefix':sys.prefix,'paths':sysconfig.get_paths(),'sys_path':sys.path},indent=2))
'''


INSTALLED_TESTS = '''import importlib,importlib.util,json,os,pathlib,sys,unittest

def main():
    root=pathlib.Path(__file__).resolve().parent
    sys.path.insert(0,str(root))
    import companion
    assert pathlib.Path(companion.__file__).resolve().is_relative_to(sys.prefix)
    spec=importlib.util.spec_from_file_location('companion.tests',root/'companion/tests/__init__.py',submodule_search_locations=[str(root/'companion/tests')])
    test_package=importlib.util.module_from_spec(spec)
    sys.modules['companion.tests']=test_package
    spec.loader.exec_module(test_package)
    companion.tests=test_package
    groups=json.loads((root/'modules.json').read_text())
    modules={name:unittest.defaultTestLoader.loadTestsFromName(name) for names in groups.values() for name in names}
    counts={name:suite.countTestCases() for name,suite in modules.items()}
    class Result(unittest.TextTestResult):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs);self.test_records=[]
        def addSuccess(self,test):
            self.test_records.append({'id':test.id(),'status':'PASS'});super().addSuccess(test)
        def addFailure(self,test,err):
            self.test_records.append({'id':test.id(),'status':'FAIL'});super().addFailure(test,err)
        def addError(self,test,err):
            self.test_records.append({'id':test.id(),'status':'ERROR'});super().addError(test,err)
        def addSkip(self,test,reason):
            self.test_records.append({'id':test.id(),'status':'SKIP','reason':reason});super().addSkip(test,reason)
    suite=unittest.TestSuite(modules.values())
    result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
    product_roots={'agent','computer','localpilot_api','localpilot_service','localpilot_plugins','localpilot_suite','localpilot_channels','companion','catalog','recommender','hardware','selector_mlp'}
    loaded={name:module.__file__ for name,module in sys.modules.items() if name.split('.')[0] in product_roots and not name.startswith('companion.tests') and getattr(module,'__file__',None)}
    assert all(pathlib.Path(p).resolve().is_relative_to(sys.prefix) for p in loaded.values()),loaded
    value={'successful':result.wasSuccessful(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'groups':{group:sum(counts[n] for n in names) for group,names in groups.items()},'module_counts':counts,'tests':result.test_records,'product_imports':loaded,'companion_test_fixture_source_override':os.environ.get('LOCALPILOT_SOURCE'),'sys_path_after':sys.path}
    (root/'test-result.json').write_text(json.dumps(value,indent=2)+'\\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)

if __name__=='__main__':main()
'''


if __name__ == '__main__':
    main()
