import importlib,importlib.util,json,os,pathlib,sys,unittest

def main():
    root=pathlib.Path(__file__).resolve().parent
    sys.path.insert(0,str(root))
    import companion
    assert pathlib.Path(companion.__file__).resolve().is_relative_to(sys.prefix)
    spec=importlib.util.spec_from_file_location('companion.tests',root/'companion/tests/__init__.py',submodule_search_locations=[str(root/'companion/tests')])
    test_package=importlib.util.module_from_spec(spec)
    sys.modules['companion.tests']=test_package
    spec.loader.exec_module(test_package)
    companion.tests=test_package
    groups=json.loads((root/'modules.json').read_text())
    modules={name:unittest.defaultTestLoader.loadTestsFromName(name) for names in groups.values() for name in names}
    counts={name:suite.countTestCases() for name,suite in modules.items()}
    class Result(unittest.TextTestResult):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs);self.test_records=[]
        def addSuccess(self,test):
            self.test_records.append({'id':test.id(),'status':'PASS'});super().addSuccess(test)
        def addFailure(self,test,err):
            self.test_records.append({'id':test.id(),'status':'FAIL'});super().addFailure(test,err)
        def addError(self,test,err):
            self.test_records.append({'id':test.id(),'status':'ERROR'});super().addError(test,err)
        def addSkip(self,test,reason):
            self.test_records.append({'id':test.id(),'status':'SKIP','reason':reason});super().addSkip(test,reason)
    suite=unittest.TestSuite(modules.values())
    result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
    product_roots={'agent','computer','localpilot_api','localpilot_service','localpilot_plugins','localpilot_suite','localpilot_channels','companion','catalog','recommender','hardware','selector_mlp'}
    loaded={name:module.__file__ for name,module in sys.modules.items() if name.split('.')[0] in product_roots and not name.startswith('companion.tests') and getattr(module,'__file__',None)}
    assert all(pathlib.Path(p).resolve().is_relative_to(sys.prefix) for p in loaded.values()),loaded
    value={'successful':result.wasSuccessful(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'groups':{group:sum(counts[n] for n in names) for group,names in groups.items()},'module_counts':counts,'tests':result.test_records,'product_imports':loaded,'companion_test_fixture_source_override':os.environ.get('LOCALPILOT_SOURCE'),'sys_path_after':sys.path}
    (root/'test-result.json').write_text(json.dumps(value,indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)

if __name__=='__main__':main()
