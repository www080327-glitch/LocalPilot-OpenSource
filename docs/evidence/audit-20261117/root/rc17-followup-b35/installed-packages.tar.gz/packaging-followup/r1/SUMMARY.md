# b35 / b12 安装态复验

**PASS：66/66，零失败、错误、跳过。** 本项使用 Python 3.12.14 的独立环境，只安装 wheel，不使用源码 editable 安装。

- 冻结源码提交：`8e27340e3d0cabbb37ace7a652de9b1f2f0d0eee`。
- 完整 tree：`42461b0b85f4aaf07290854277a5d54fe531dd70`。
- 新构建：Core `5.0.0b35`、Companion `0.5.7b12`，来自上述提交的 `git archive`。
- 复用且验证历史 SHA：Suite `0.2.0b34`、Channels `0.1.0a4`，原构建来自 `37570b9a7c6b64e0ac67ab2706c15eeebc714069`，对应历史公开源码 `ce9264b2e958c163debb0b350eeb32ce7c4e56e0`，不能称为本轮重新构建。
- 实际安装、导入来源、`direct_url.json` 的 wheel 散列、CLI 版本及安装前后 `pip check` 均通过。
- **346 份 wheel payload**（包含声明的数据与许可证，其中 **288 份 Python/Swift 源文件**）逐字匹配冻结源码与实际安装目录；测试后再次比对一致。
- 新旧组件实际 source 文件与本轮冻结源相同；冻结 stage 与选定工作区源码前后散列均未变化。
- 使用默认系统临时目录，没有设置会改变权限祖先语义的 TMPDIR。

## 原有门禁与新增覆盖

| 组 | 模块 | 测试数 |
|---|---|---:|
| 原有 | worker_role_routes / hybrid_history_rotation / context_v5 / engine_v5 / worker_role_runtime | 36 |
| 新增 | worker_output_recovery | 8 |
| 新增 | Companion task_store | 12 |
| 新增 | Companion task_history | 4 |
| 新增 | Companion pa_context_lineage | 6 |
| 合计 | 全部实际执行 | 66 |

测试直接复制冻结版本的仓库测试，不抄写业务逻辑。Companion 仅将 `companion.tests` 测试包挂载到隔离 harness，原 fixture 的 `LOCALPILOT_SOURCE` 指向新安装的 site-packages。所有已载入产品模块经核对均位于新 runtime prefix 内；测试源码不充当产品源码。新增截断恢复用例实际运行 Gateway、子任务账本、SQLite 与 shell 自测；lineage 走真实 localhost HTTP 和 SQLite，模型为脚本夹具。

## 证据

`run.json` 保存每条命令、退出码、时间、构建和安装来源。`installed-source-manifest.json` 保存每个 payload 的源码路径、安装路径、长度与 SHA256；`import-proof.json` 和 `harness/test-result.json` 保存模块来源与逐项测试结果。构建、依赖、安装、pip check 和测试原始日志均保留。

`wheels/` 集中放置四个经核对的 wheel，`ARTIFACTS.json` 保留“实际安装来源”和“交付副本”区别。在该目录的父目录执行 `sha256sum -c SHA256SUMS` 可验证四包。

本项不是原生 APP/DEB 构建、系统安装、macOS/Linux 原生 UI、可见动画或真实模型能力验收。
