import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import unittest

validation = Path(__file__).resolve().parent
runtime = Path(sys.prefix).resolve()
package = Path(sys.argv[1]).resolve()
testdir = validation / "tests"
suite = unittest.TestSuite()
start = time.monotonic()
for path in sorted(testdir.glob("test_*.py")):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    case = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(case)
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(case))
with (validation / "tests.log").open("w") as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
paths = {name: Path(m.__file__).resolve() for name, m in sys.modules.items()
         if (name == "companion" or name.startswith("companion.")) and getattr(m, "__file__", None)}
assert paths and {"companion.memory.task_store","companion.runtime.service"}.issubset(paths)
assert all(runtime in path.parents and "site-packages" in path.parts for path in paths.values())
assert sys.flags.isolated and (runtime / "pyvenv.cfg").is_file()
sha = lambda p: hashlib.file_digest(p.open("rb"), "sha256").hexdigest()
receipt = {"status": "PASS" if result.wasSuccessful() else "FAIL", "scope": "Tests use only the Companion Python modules from the extracted Debian Test package; no system-level package installation or GUI fixture.", "source_commit":"2071edb96b6a286c0336bea9adfe99710d0439e4", "deb_name":package.name, "deb_sha256":sha(package), "python":sys.version, "runtime":str(runtime), "isolated":bool(sys.flags.isolated), "tests_run": result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skips":len(result.skipped),"seconds":round(time.monotonic()-start,3),"suite_files":{p.name:sha(p) for p in sorted(testdir.glob("test_*.py"))},"module_locations":{n:str(p.relative_to(runtime)) for n,p in sorted(paths.items())}}
(validation / "RESULTS.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(receipt["status"],receipt["tests_run"],len(paths))
raise SystemExit(0 if result.wasSuccessful() else 1)
