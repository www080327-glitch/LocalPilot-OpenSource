#!/bin/bash
set -eu
run=$(CDPATH= cd -- "$(dirname -- "$0")/../r1" && pwd)
checkout=$run/../r2/build-source
log=/workspace/scratch/b0df9966d470/nov18-validation/pet/native-edge-tests.log
export CARGO_HOME="$run/cargo" CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$run/native-target"
export PATH="$run/node-v22.23.4-linux-x64/bin:/workspace/scratch/c0f3ec78c621/validation/context-20261117/toolchain/rustup/toolchains/1.100.0-x86_64-unknown-linux-gnu/bin:$run/sysroot/usr/bin:$PATH"
export PKG_CONFIG_SYSROOT_DIR="$run/sysroot"
export PKG_CONFIG_LIBDIR="$run/sysroot/usr/lib/x86_64-linux-gnu/pkgconfig:$run/sysroot/usr/share/pkgconfig:$run/sysroot/usr/lib/pkgconfig"
export LIBRARY_PATH="$run/sysroot/usr/lib/x86_64-linux-gnu"
export LD_LIBRARY_PATH="$run/sysroot/usr/lib/x86_64-linux-gnu"
export RUSTFLAGS="-C link-arg=-Wl,-rpath-link,$run/sysroot/usr/lib/x86_64-linux-gnu"
export LP_GUI_USE_INSTALLED_DEPS=1 LP_GUI_TEST_CONFIG=src-tauri/tauri.test.conf.json
cd "$checkout"
# The package installer verifies Test identity separately. This is the actual Rust import test.
cargo test --release --locked --manifest-path desktop/src-tauri/Cargo.toml rejected_edge_import_preserves_the_installed_pack_and_accepts_a_valid_replacement -- --nocapture > "$log" 2>&1
python - <<'PY'
from pathlib import Path
import os,re,subprocess,hashlib,json
root=Path('/workspace/scratch/b0df9966d470/nov18-validation/linux/r2')
log=Path('/workspace/scratch/b0df9966d470/nov18-validation/pet/native-edge-tests.log')
line=next(x for x in log.read_text().splitlines() if 'Running unittests' in x)
exe=Path(re.search(r'\((.+)\)$',line).group(1)).resolve()
command=[str(exe),'--test-threads=1']
with (root/'native-rust-suite.log').open('w') as out:
    p=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,cwd=root/'build-source/desktop/src-tauri')
proof={'product_commit':'2071edb96b6a286c0336bea9adfe99710d0439e4','product_tree':'819741f0607c758521684acc19292770a961c93a','test_binary':str(exe),'sha256':hashlib.file_digest(exe.open('rb'),'sha256').hexdigest(),'command':command,'exit':p.returncode,'result_lines':[x for x in (root/'native-rust-suite.log').read_text().splitlines() if 'test result:' in x]}
(root/'native-rust-suite.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof);raise SystemExit(p.returncode)
PY
