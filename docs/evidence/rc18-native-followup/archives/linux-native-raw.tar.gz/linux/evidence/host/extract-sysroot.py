from pathlib import Path, PurePosixPath
import hashlib, json, os, subprocess, tarfile

base = Path(__file__).resolve().parent
root = base / 'sysroot'
root.mkdir(exist_ok=False)
manifest = {}
for deb in sorted((base/'apt/cache/archives').glob('*.deb')):
    manifest[deb.name] = hashlib.file_digest(deb.open('rb'), 'sha256').hexdigest()
    with subprocess.Popen(['dpkg-deb', '--fsys-tarfile', str(deb)], stdout=subprocess.PIPE) as p:
        with tarfile.open(mode='r|', fileobj=p.stdout) as tar:
            for item in tar:
                path = PurePosixPath(item.name)
                if not (str(path).startswith(('usr/lib/','usr/libexec/','usr/include/','usr/share/pkgconfig/')) or str(path)=='usr/bin/patchelf'):
                    continue
                if item.issym() and os.path.isabs(item.linkname):
                    item = item.replace(linkname=os.path.relpath(root / item.linkname.lstrip('/'),root / str(path.parent)))
                tar.extract(item,root,filter='data')
        assert p.wait()==0, deb.name
(base/'sysroot-packages.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Extracted package inputs',len(manifest))
