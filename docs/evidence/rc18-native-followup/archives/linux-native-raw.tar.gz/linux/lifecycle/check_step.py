"""Exercise one LocalPilot Test DEB transaction in a dedicated empty-initialized dpkg root."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
from datetime import datetime, timezone

slot = Path(__file__).resolve().parent
root = slot / 'root'
step = int(sys.argv[1])
deb = Path(sys.argv[2]).resolve()
expected_sha = sys.argv[3]
versions = {1: '5.0.1-rc.17', 2: '5.0.1-rc.18', 3: '5.0.1-rc.17', 4: '5.0.1-rc.18'}
stem = slot / f'step-{step}-{versions[step]}'
assert not stem.with_suffix('.json').exists()
report_path = slot / (stem.name + '.json')
if report_path.exists():
    raise SystemExit('Use new evidence path for a retry')

def sha256(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

evidence = {
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'step': step,
    'private_root': str(root),
    'real_uid': os.getuid(),
    'effective_uid': os.geteuid(),
    'package_artifact': deb.name,
    'package_sha256': sha256(deb),
    'host_status_exists_before': Path('/var/lib/dpkg/status').exists(),
    'commands': [],
}
assert os.geteuid() != 0 and root.is_relative_to(slot) and root.is_dir() and not root.is_symlink()
assert evidence['package_sha256'] == expected_sha
assert (json.loads((deb.parent / 'RESULTS.json').read_text())['sha256'] == expected_sha)

def save():
    report_path.write_text(json.dumps(evidence, indent=2) + '\n')

def command(argv):
    result = subprocess.run(argv, env={'LC_ALL':'C','PATH':'/usr/sbin:/usr/bin:/sbin:/bin'},
                            stdin=subprocess.DEVNULL, capture_output=True, text=True)
    evidence['commands'].append(dict(argv=[str(x) for x in argv], code=result.returncode, stdout=result.stdout, stderr=result.stderr))
    save()
    return result

data = subprocess.check_output(['dpkg-deb', '--ctrl-tarfile', deb])
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    inventory = [m.name for m in archive]
    assert set(inventory) == {'.', './control', './md5sums'}, inventory
    metadata = archive.extractfile('./control').read().decode()
    assert f'Version: {versions[step]}\n' in metadata
    assert 'Package: local-pilot-test\n' in metadata
    sums = archive.extractfile('./md5sums').read()
evidence.update(control_archive_members=inventory,control=metadata,package_md5_entries=len(sums.splitlines()))
binfile = root / 'usr/bin/localpilot-desktop-test'
marker = root / 'home/fixture/localpilot-unrelated-state.txt'
if step == 1:
    marker.parent.mkdir(parents=True)
    marker.write_text('Independent private-root user file for the LocalPilot unpack cycle.\n')
else:
    assert marker.is_file()
assert marker.read_text() == 'Independent private-root user file for the LocalPilot unpack cycle.\n'
evidence['marker_sha256_before'] = sha256(marker)
opts = ['dpkg','--root='+str(root),'--log='+str(root/'var/log/dpkg.log')]
unpriv = opts + ['--force-not-root']
query = ['dpkg-query','--root='+str(root),'-W','-f=${Status}\t${Version}\n','local-pilot-test']
before = command(query)
if step == 1:
    assert before.returncode == 1
    default_install = command(opts + ['--install', deb])
    assert default_install.returncode == 2 and 'requires superuser privilege' in default_install.stderr
else:
    assert before.returncode == 0 and before.stdout == 'install ok unpacked\t' + versions[step-1] + '\n'
unpacked = command(unpriv + ['--unpack',deb])
assert unpacked.returncode == 0, unpacked.stderr
query_unpacked = command(query)
assert query_unpacked.stdout == 'install ok unpacked\t' + versions[step] + '\n'
checked = command(unpriv + ['--configure','local-pilot-test'])
evidence['configure_installed'] = checked.returncode == 0
query_final = command(query)
verified = command(opts + ['--verify','local-pilot-test'])
assert verified.returncode == 0 and not verified.stdout and not verified.stderr
assert binfile.is_file() and not binfile.is_symlink()
evidence.update(desktop_elf_sha256=sha256(binfile),marker_sha256_after=sha256(marker),
                file_owner_uid=binfile.stat().st_uid, host_status_exists_after=Path('/var/lib/dpkg/status').exists(),
                package_state=query_final.stdout.strip(), finished_utc=datetime.now(timezone.utc).isoformat())
assert evidence['marker_sha256_after'] == evidence['marker_sha256_before']
assert query_final.stdout == 'install ok unpacked\t'+versions[step]+'\n'
assert checked.returncode == 1 and 'dependency problems prevent configuration' in checked.stderr
if step >= 3:
    previous = json.loads((slot/f'step-{step-2}-{versions[step]}.json').read_text())
    assert previous['desktop_elf_sha256'] == evidence['desktop_elf_sha256']
    assert previous['marker_sha256_after'] == evidence['marker_sha256_after']
evidence['verdict'] = 'UNPACK_VERIFIED_CONFIGURE_BLOCKED_MISSING_REAL_DEPENDENCIES'
save()
print(json.dumps({k:evidence[k] for k in ('step','package_artifact','package_state','desktop_elf_sha256','package_md5_entries','verdict')}))
