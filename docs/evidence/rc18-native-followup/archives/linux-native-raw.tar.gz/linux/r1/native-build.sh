#!/bin/bash
set -eu
run=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
checkout=${1:-$run/build-source}
log=${2:-$run/native-build.log}
export CARGO_HOME="$run/cargo" CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$run/native-target"
export PATH="$run/node-v22.23.4-linux-x64/bin:/workspace/scratch/c0f3ec78c621/validation/context-20261117/toolchain/rustup/toolchains/1.100.0-x86_64-unknown-linux-gnu/bin:$run/sysroot/usr/bin:$PATH"
export PKG_CONFIG_SYSROOT_DIR="$run/sysroot"
export PKG_CONFIG_LIBDIR="$run/sysroot/usr/lib/x86_64-linux-gnu/pkgconfig:$run/sysroot/usr/share/pkgconfig:$run/sysroot/usr/lib/pkgconfig"
export LIBRARY_PATH="$run/sysroot/usr/lib/x86_64-linux-gnu"
export LD_LIBRARY_PATH="$run/sysroot/usr/lib/x86_64-linux-gnu"
export RUSTFLAGS="-C link-arg=-Wl,-rpath-link,$run/sysroot/usr/lib/x86_64-linux-gnu"
export LP_GUI_USE_INSTALLED_DEPS=1 LP_GUI_TEST_CONFIG=src-tauri/tauri.test.conf.json
cd "$checkout/desktop"
npm run release:linux > "$log" 2>&1
