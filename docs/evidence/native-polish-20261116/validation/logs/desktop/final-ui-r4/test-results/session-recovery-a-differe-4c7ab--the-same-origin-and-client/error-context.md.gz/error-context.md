# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: session-recovery.spec.ts >> a different Suite root invalidates the old selection even at the same origin and client
- Location: tests/ui/session-recovery.spec.ts:237:1

# Error details

```
Error: expect(locator).not.toContainText(expected) failed

Locator: locator('.conversation')
Expected substring: not "Original answer"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "not toContainText" locator('.conversation') with timeout 5000ms
  - waiting for locator('.conversation')

```

```yaml
- complementary:
  - text: LocalPilot RC.7 · 思考修复
  - button "新会话 ⌘ N":
    - img
    - text: 新会话 ⌘ N
  - button "模型库 模型、下载与推理服务":
    - img
    - text: 模型库 模型、下载与推理服务
    - img
  - img
  - textbox "搜索历史任务":
    - /placeholder: 搜索会话…
  - text: ⌘ K 工作区
  - button "工作区设置":
    - img
  - button "work 服务端绑定":
    - img
    - text: work 服务端绑定
    - img
  - text: 项目与会话
  - button "创建项目":
    - img
  - button "刷新任务列表":
    - img
  - navigation "任务历史": 你的下一件作品 从一次对话开始。
  - button "服务已连接 Core fixture":
    - text: 服务已连接 Core fixture
    - img
  - button "设置":
    - img
    - text: 设置
  - button "切换浅色或深色主题":
    - img
  - button "键盘快捷键":
    - img
  - separator "调整侧栏宽度"
- main:
  - button "切换左侧栏":
    - img
  - text: work
  - img
  - text: 新会话
  - img
  - text: 独立客户端
  - button "切换任务详情":
    - img
  - heading "今天，想完成什么？" [level=1]
  - paragraph: 从一个问题，或一件待办开始。
  - button "调整本会话偏好":
    - img
    - text: 平衡
    - img
  - text: 仅此会话
  - textbox "给 LocalPilot 发送消息":
    - /placeholder: 描述一个明确目标，让 Agent 帮你推进…
  - button "授权文件夹": 选择文件夹
  - button "添加附件":
    - img
  - button "导入附件文件夹": 文件夹
  - button "权限模式":
    - img
    - text: 工作区写入
    - img
  - button "极简 Agent":
    - img
    - text: 极简 Agent
  - button "标准 Agent" [pressed]:
    - img
    - text: 标准 Agent
  - button "选择模型":
    - text: 选择模型
    - img
  - button "调整思考强度":
    - img
  - button "发送消息" [disabled]:
    - img
  - button "查看本地、云端调用占比及子代理":
    - img
    - text: 本地/云端占比：暂无真实调用记录
    - img
  - img
  - text: 操作按当前权限执行 · 云端使用所选模型 Enter 换行 · ⌘ Enter 发送
```

# Test source

```ts
  152 |   await page.goto("/");
  153 |   await expect(page.locator(".conversation")).toContainText("Original answer");
  154 |   await expect(
  155 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  156 |   ).toHaveValue("Unsent original text");
  157 |   await expect
  158 |     .poll(
  159 |       async () =>
  160 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  161 |           .length,
  162 |     )
  163 |     .toBe(1);
  164 |   const observed = await calls(page);
  165 |   expect(
  166 |     observed.find((c) => c.args.operation === "documents")!.args.args
  167 |       .session_id,
  168 |   ).toBe("sess_cached");
  169 |   expect(
  170 |     observed.filter(
  171 |       (c) =>
  172 |         c.args.path?.includes("/sessions/") ||
  173 |         ["submit_task", "recover_submission"].includes(c.command),
  174 |     ),
  175 |   ).toEqual([]);
  176 | });
  177 | 
  178 | test("503 leaves the selected Session intact and a later refresh can confirm it", async ({
  179 |   page,
  180 | }) => {
  181 |   await recoveryBridge(page, "transient");
  182 |   await page.goto("/");
  183 |   await expect(page.getByText(/HTTP 503 ·/)).toBeVisible();
  184 |   expect(
  185 |     await page.evaluate(() =>
  186 |       JSON.parse(localStorage.getItem("lp.currentChat")!),
  187 |     ),
  188 |   ).toBe("sess_cached");
  189 |   expect(
  190 |     (await calls(page)).filter((c) => c.args.operation === "documents"),
  191 |   ).toEqual([]);
  192 |   await page.evaluate(() => {
  193 |     (window as any).fixtureLookupStatus = 200;
  194 |   });
  195 |   await page.getByRole("button", { name: "刷新任务列表", exact: true }).click();
  196 |   await expect
  197 |     .poll(
  198 |       async () =>
  199 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  200 |           .length,
  201 |     )
  202 |     .toBe(1);
  203 |   await expect(
  204 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  205 |   ).toHaveValue("Unsent original text");
  206 |   await expect(page.getByText(/HTTP 503 ·/)).toHaveCount(0);
  207 |   expect(
  208 |     (await calls(page)).filter((c) => c.command === "submit_task"),
  209 |   ).toEqual([]);
  210 | });
  211 | 
  212 | test("a confirmed Session without tasks keeps staged documents available", async ({
  213 |   page,
  214 | }) => {
  215 |   await recoveryBridge(page, "empty");
  216 |   await page.goto("/");
  217 |   await expect
  218 |     .poll(
  219 |       async () =>
  220 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  221 |           .length,
  222 |     )
  223 |     .toBe(1);
  224 |   expect(
  225 |     await page.evaluate(() =>
  226 |       JSON.parse(localStorage.getItem("lp.currentChat")!),
  227 |     ),
  228 |   ).toBe("sess_cached");
  229 |   await expect(
  230 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  231 |   ).toHaveValue("Unsent original text");
  232 |   expect(
  233 |     (await calls(page)).filter((c) => c.command === "submit_task"),
  234 |   ).toEqual([]);
  235 | });
  236 | 
  237 | test("a different Suite root invalidates the old selection even at the same origin and client", async ({
  238 |   page,
  239 | }) => {
  240 |   await recoveryBridge(page, "existing");
  241 |   await page.goto("/");
  242 |   await expect(page.locator(".conversation")).toContainText("Original answer");
  243 |   await page.evaluate(() => {
  244 |     (window as any).fixtureService = 1;
  245 |   });
  246 |   await page.getByRole("button", { name: "刷新任务列表", exact: true }).click();
  247 |   await expect
  248 |     .poll(() =>
  249 |       page.evaluate(() => JSON.parse(localStorage.getItem("lp.currentChat")!)),
  250 |     )
  251 |     .toMatch(/^draft-/);
> 252 |   await expect(page.locator(".conversation")).not.toContainText(
      |                                                   ^ Error: expect(locator).not.toContainText(expected) failed
  253 |     "Original answer",
  254 |   );
  255 |   expect(
  256 |     (await calls(page)).filter(
  257 |       (c) => c.service === 1 && c.args.operation === "documents",
  258 |     ),
  259 |   ).toEqual([]);
  260 |   expect(
  261 |     await page.evaluate(
  262 |       () => JSON.parse(localStorage.getItem("lp.chats.v1")!).sess_cached.input,
  263 |     ),
  264 |   ).toBe("Unsent original text");
  265 | });
  266 | 
```