# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: session-recovery.spec.ts >> a confirmed Session without tasks keeps staged documents available
- Location: tests/ui/session-recovery.spec.ts:212:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 2

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e6]:
      - generic [ref=e11]: LocalPilot
      - generic "5.0.1-rc.8 · 思考修复版" [ref=e12]: RC.7 · 思考修复
    - button "新会话 ⌘ N" [ref=e13] [cursor=pointer]:
      - text: 新会话
      - generic [ref=e15]: ⌘ N
    - button "模型库 模型、下载与推理服务" [ref=e16] [cursor=pointer]:
      - generic [ref=e21]:
        - text: 模型库
        - generic [ref=e22]: 模型、下载与推理服务
    - generic [ref=e25]:
      - textbox "搜索历史任务" [ref=e29]:
        - /placeholder: 搜索会话…
      - generic [ref=e30]: ⌘ K
    - generic [ref=e31]:
      - generic [ref=e32]: 工作区
      - button "工作区设置" [ref=e33] [cursor=pointer]
    - button "work 服务端绑定" [ref=e35] [cursor=pointer]:
      - generic [ref=e38]:
        - text: work
        - generic [ref=e39]: 服务端绑定
    - generic [ref=e42]:
      - generic [ref=e43]: 项目与会话
      - button "创建项目" [ref=e44] [cursor=pointer]
      - button "刷新任务列表" [ref=e47] [cursor=pointer]
    - navigation "任务历史" [ref=e53]:
      - generic [ref=e54]: 你的下一件作品从一次对话开始。
    - generic [ref=e55]:
      - button "服务已连接 Core fixture" [ref=e56] [cursor=pointer]:
        - generic [ref=e58]:
          - text: 服务已连接
          - generic [ref=e59]: Core fixture
      - generic [ref=e62]:
        - button "设置" [ref=e63] [cursor=pointer]
        - button "切换浅色或深色主题" [ref=e67] [cursor=pointer]
        - button "键盘快捷键" [ref=e70] [cursor=pointer]
    - separator "调整侧栏宽度" [ref=e73]
  - main [ref=e74]:
    - generic [ref=e75]:
      - generic [ref=e76]:
        - button "切换左侧栏" [ref=e77] [cursor=pointer]
        - generic [ref=e80]: work
        - generic [ref=e83]: 新会话
      - generic [ref=e84]:
        - generic [ref=e85]: 独立客户端
        - button "切换任务详情" [ref=e89] [cursor=pointer]
    - generic [ref=e93]:
      - heading "今天，想完成什么？" [level=1] [ref=e99]
      - paragraph [ref=e100]: 从一个问题，或一件待办开始。
    - generic [ref=e101]:
      - generic [ref=e102]:
        - button "调整本会话偏好" [ref=e103] [cursor=pointer]:
          - generic [ref=e105]: 平衡
        - generic [ref=e108]: 仅此会话
      - generic [ref=e109]:
        - textbox "给 LocalPilot 发送消息" [ref=e111]:
          - /placeholder: 描述一个明确目标，让 Agent 帮你推进…
          - text: Unsent original text
        - button "授权文件夹" [ref=e113] [cursor=pointer]: 选择文件夹
        - generic [ref=e114]:
          - generic [ref=e115]:
            - button "添加附件" [ref=e116] [cursor=pointer]
            - button "导入附件文件夹" [ref=e120] [cursor=pointer]: 文件夹
            - button "权限模式" [ref=e122] [cursor=pointer]: 工作区写入
            - generic "工作模式" [ref=e128]:
              - button "极简 Agent" [ref=e129] [cursor=pointer]
              - button "标准 Agent" [pressed] [ref=e133] [cursor=pointer]
            - button "选择模型" [ref=e140] [cursor=pointer]:
              - generic [ref=e142]: Recovery fixture
            - button "调整思考强度" [ref=e146] [cursor=pointer]
          - button "发送消息" [ref=e148] [cursor=pointer]
      - generic [ref=e151]:
        - button "查看本地、云端调用占比及子代理" [ref=e152] [cursor=pointer]: 本地/云端占比：暂无真实调用记录
        - generic [ref=e159]: 操作按当前权限执行 · 云端使用所选模型
        - generic [ref=e163]: Enter 换行 · ⌘ Enter 发送
```

# Test source

```ts
  123 |   await page.goto("/");
  124 |   await expect
  125 |     .poll(() =>
  126 |       page.evaluate(() => JSON.parse(localStorage.getItem("lp.currentChat")!)),
  127 |     )
  128 |     .toMatch(/^draft-/);
  129 |   const observed = await calls(page);
  130 |   expect(
  131 |     observed.filter(
  132 |       (c) => c.args.path === "/localpilot/v1/sessions/sess_cached",
  133 |     ),
  134 |   ).toHaveLength(1);
  135 |   expect(observed.filter((c) => c.args.operation === "documents")).toEqual([]);
  136 |   expect(
  137 |     observed.filter((c) =>
  138 |       ["submit_task", "recover_submission"].includes(c.command),
  139 |     ),
  140 |   ).toEqual([]);
  141 |   expect(
  142 |     await page.evaluate(
  143 |       () => JSON.parse(localStorage.getItem("lp.chats.v1")!).sess_cached.input,
  144 |     ),
  145 |   ).toBe("Unsent original text");
  146 | });
  147 | 
  148 | test("service task history confirms the document Session and retains unknown receipts", async ({
  149 |   page,
  150 | }) => {
  151 |   await recoveryBridge(page, "existing");
  152 |   await page.goto("/");
  153 |   await expect(page.locator(".conversation")).toContainText("Original answer");
  154 |   await expect(
  155 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  156 |   ).toHaveValue("Unsent original text");
  157 |   await expect
  158 |     .poll(
  159 |       async () =>
  160 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  161 |           .length,
  162 |     )
  163 |     .toBe(1);
  164 |   const observed = await calls(page);
  165 |   expect(
  166 |     observed.find((c) => c.args.operation === "documents")!.args.args
  167 |       .session_id,
  168 |   ).toBe("sess_cached");
  169 |   expect(
  170 |     observed.filter(
  171 |       (c) =>
  172 |         c.args.path?.includes("/sessions/") ||
  173 |         ["submit_task", "recover_submission"].includes(c.command),
  174 |     ),
  175 |   ).toEqual([]);
  176 | });
  177 | 
  178 | test("503 leaves the selected Session intact and a later refresh can confirm it", async ({
  179 |   page,
  180 | }) => {
  181 |   await recoveryBridge(page, "transient");
  182 |   await page.goto("/");
  183 |   await expect(page.getByText(/HTTP 503 ·/)).toBeVisible();
  184 |   expect(
  185 |     await page.evaluate(() =>
  186 |       JSON.parse(localStorage.getItem("lp.currentChat")!),
  187 |     ),
  188 |   ).toBe("sess_cached");
  189 |   expect(
  190 |     (await calls(page)).filter((c) => c.args.operation === "documents"),
  191 |   ).toEqual([]);
  192 |   await page.evaluate(() => {
  193 |     (window as any).fixtureLookupStatus = 200;
  194 |   });
  195 |   await page.getByRole("button", { name: "刷新任务列表", exact: true }).click();
  196 |   await expect
  197 |     .poll(
  198 |       async () =>
  199 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  200 |           .length,
  201 |     )
  202 |     .toBe(1);
  203 |   await expect(
  204 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  205 |   ).toHaveValue("Unsent original text");
  206 |   await expect(page.getByText(/HTTP 503 ·/)).toHaveCount(0);
  207 |   expect(
  208 |     (await calls(page)).filter((c) => c.command === "submit_task"),
  209 |   ).toEqual([]);
  210 | });
  211 | 
  212 | test("a confirmed Session without tasks keeps staged documents available", async ({
  213 |   page,
  214 | }) => {
  215 |   await recoveryBridge(page, "empty");
  216 |   await page.goto("/");
  217 |   await expect
  218 |     .poll(
  219 |       async () =>
  220 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  221 |           .length,
  222 |     )
> 223 |     .toBe(1);
      |      ^ Error: expect(received).toBe(expected) // Object.is equality
  224 |   expect(
  225 |     await page.evaluate(() =>
  226 |       JSON.parse(localStorage.getItem("lp.currentChat")!),
  227 |     ),
  228 |   ).toBe("sess_cached");
  229 |   await expect(
  230 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  231 |   ).toHaveValue("Unsent original text");
  232 |   expect(
  233 |     (await calls(page)).filter((c) => c.command === "submit_task"),
  234 |   ).toEqual([]);
  235 | });
  236 | 
  237 | test("a different Suite root invalidates the old selection even at the same origin and client", async ({
  238 |   page,
  239 | }) => {
  240 |   await recoveryBridge(page, "existing");
  241 |   await page.goto("/");
  242 |   await expect(page.locator(".conversation")).toContainText("Original answer");
  243 |   await page.evaluate(() => {
  244 |     (window as any).fixtureService = 1;
  245 |   });
  246 |   await page.getByRole("button", { name: "刷新任务列表", exact: true }).click();
  247 |   await expect
  248 |     .poll(() =>
  249 |       page.evaluate(() => JSON.parse(localStorage.getItem("lp.currentChat")!)),
  250 |     )
  251 |     .toMatch(/^draft-/);
  252 |   await expect(page.locator(".conversation")).not.toContainText(
  253 |     "Original answer",
  254 |   );
  255 |   expect(
  256 |     (await calls(page)).filter(
  257 |       (c) => c.service === 1 && c.args.operation === "documents",
  258 |     ),
  259 |   ).toEqual([]);
  260 |   expect(
  261 |     await page.evaluate(
  262 |       () => JSON.parse(localStorage.getItem("lp.chats.v1")!).sess_cached.input,
  263 |     ),
  264 |   ).toBe("Unsent original text");
  265 | });
  266 | 
```