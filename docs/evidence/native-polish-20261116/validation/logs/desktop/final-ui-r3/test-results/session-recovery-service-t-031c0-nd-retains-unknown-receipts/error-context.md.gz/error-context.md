# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: session-recovery.spec.ts >> service task history confirms the document Session and retains unknown receipts
- Location: tests/ui/session-recovery.spec.ts:148:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 3

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e6]:
      - generic [ref=e11]: LocalPilot
      - generic "5.0.1-rc.8 · 思考修复版" [ref=e12]: RC.7 · 思考修复
    - button "新会话 ⌘ N" [ref=e13] [cursor=pointer]:
      - text: 新会话
      - generic [ref=e15]: ⌘ N
    - button "模型库 模型、下载与推理服务" [ref=e16] [cursor=pointer]:
      - generic [ref=e21]:
        - text: 模型库
        - generic [ref=e22]: 模型、下载与推理服务
    - generic [ref=e25]:
      - textbox "搜索历史任务" [ref=e29]:
        - /placeholder: 搜索会话…
      - generic [ref=e30]: ⌘ K
    - generic [ref=e31]:
      - generic [ref=e32]: 工作区
      - button "工作区设置" [ref=e33] [cursor=pointer]
    - button "work 服务端绑定" [ref=e35] [cursor=pointer]:
      - generic [ref=e38]:
        - text: work
        - generic [ref=e39]: 服务端绑定
    - generic [ref=e42]:
      - generic [ref=e43]: 项目与会话
      - button "创建项目" [ref=e44] [cursor=pointer]
      - button "刷新任务列表" [ref=e47] [cursor=pointer]
    - navigation "任务历史" [ref=e53]:
      - generic [ref=e54]: 未分类
      - generic [ref=e55]:
        - button "Original question 执行完成" [ref=e56] [cursor=pointer]:
          - generic [ref=e59]:
            - text: Original question
            - generic [ref=e60]: 执行完成
        - button "置顶会话" [ref=e62] [cursor=pointer]
        - combobox "选择会话所属项目" [ref=e65]:
          - option "未分类" [selected]
    - generic [ref=e66]:
      - button "服务已连接 Core fixture" [ref=e67] [cursor=pointer]:
        - generic [ref=e69]:
          - text: 服务已连接
          - generic [ref=e70]: Core fixture
      - generic [ref=e73]:
        - button "设置" [ref=e74] [cursor=pointer]
        - button "切换浅色或深色主题" [ref=e78] [cursor=pointer]
        - button "键盘快捷键" [ref=e81] [cursor=pointer]
    - separator "调整侧栏宽度" [ref=e84]
  - main [ref=e85]:
    - generic [ref=e86]:
      - generic [ref=e87]:
        - button "切换左侧栏" [ref=e88] [cursor=pointer]
        - generic [ref=e91]: work
        - generic [ref=e94]: 任务会话
      - generic [ref=e95]:
        - generic [ref=e96]: 独立客户端
        - button "切换任务详情" [ref=e100] [cursor=pointer]
    - generic [ref=e104]:
      - article [ref=e105]:
        - generic [ref=e106]: 你
        - generic [ref=e108]: Original question
      - article [ref=e109]:
        - generic [ref=e110]:
          - strong [ref=e115]: LocalPilot
          - generic [ref=e116]: Agent
        - paragraph [ref=e118]: Original answer
        - generic [ref=e119]:
          - generic [ref=e120]: 执行完成
          - generic [ref=e122]: 未验证
          - button "查看证据" [ref=e126] [cursor=pointer]
        - generic [ref=e129]:
          - generic [ref=e130]: 服务快照 · 原请求保存在本机
          - button "复制回复" [ref=e131] [cursor=pointer]
    - generic [ref=e135]:
      - generic [ref=e136]:
        - button "调整本会话偏好" [ref=e137] [cursor=pointer]:
          - generic [ref=e139]: 平衡
        - generic [ref=e142]: 仅此会话
      - generic [ref=e143]:
        - textbox "给 LocalPilot 发送消息" [ref=e145]:
          - /placeholder: 描述一个明确目标，让 Agent 帮你推进…
          - text: Unsent original text
        - button "授权文件夹" [ref=e147] [cursor=pointer]: 选择文件夹
        - generic [ref=e148]:
          - generic [ref=e149]:
            - button "添加附件" [ref=e150] [cursor=pointer]
            - button "导入附件文件夹" [ref=e154] [cursor=pointer]: 文件夹
            - button "权限模式" [ref=e156] [cursor=pointer]: 工作区写入
            - generic "工作模式" [ref=e162]:
              - button "极简 Agent" [ref=e163] [cursor=pointer]
              - button "标准 Agent" [pressed] [ref=e167] [cursor=pointer]
            - button "选择模型" [ref=e174] [cursor=pointer]:
              - generic [ref=e176]: Recovery fixture
            - button "调整思考强度" [ref=e180] [cursor=pointer]
          - button "发送消息" [ref=e182] [cursor=pointer]
      - generic [ref=e185]:
        - button "查看本地、云端调用占比及子代理" [ref=e186] [cursor=pointer]: 本地/云端占比：暂无真实调用记录
        - generic [ref=e193]: 操作按当前权限执行 · 云端使用所选模型
        - generic [ref=e197]: Enter 换行 · ⌘ Enter 发送
  - complementary [ref=e198]:
    - separator "调整任务栏宽度" [ref=e199]
    - generic [ref=e200]:
      - generic [ref=e201]: 任务详情
      - button "关闭任务详情" [ref=e202] [cursor=pointer]
    - generic [ref=e205]:
      - generic [ref=e206]:
        - generic [ref=e207]: LIVE WORKSPACE
        - generic [ref=e208]:
          - heading "每一步，都有依据。" [level=2] [ref=e209]
          - button "重新查询任务" [ref=e210] [cursor=pointer]
        - generic [ref=e216]: 执行完成
        - code [ref=e218]: resp_cached
      - tablist "任务详情" [ref=e219]:
        - tab "进度" [selected] [ref=e220] [cursor=pointer]
        - tab "协同" [ref=e221] [cursor=pointer]
        - tab "证据" [ref=e222] [cursor=pointer]
        - tab "Diff" [ref=e223] [cursor=pointer]
      - generic [ref=e224]:
        - heading "任务计划" [level=3] [ref=e225]
        - paragraph [ref=e232]: 服务未提供结构化计划
      - generic [ref=e233]:
        - heading "工具调用 1" [level=3] [ref=e234]:
          - text: 工具调用
          - generic [ref=e237]: "1"
        - group [ref=e238]:
          - generic "tool 未知" [ref=e239] [cursor=pointer]:
            - code [ref=e242]: tool
            - generic [ref=e243]: 未知
      - generic [ref=e244]:
        - heading "事件时间线" [level=3] [ref=e245]
        - paragraph [ref=e248]: 等待服务事件。流中断后使用原任务和游标恢复。
      - generic [ref=e249]:
        - generic [ref=e250]:
          - generic [ref=e251]: 上下文
          - strong [ref=e252]: 未知
        - generic [ref=e253]:
          - generic [ref=e254]: Tokens
          - strong [ref=e255]: 未知
        - generic [ref=e256]:
          - generic [ref=e257]: 实际费用
          - strong [ref=e258]: 未知
        - button "关于这些指标" [ref=e259] [cursor=pointer]
    - generic [ref=e262]:
      - text: 任务已静止 · 快照保留
      - button "重连 SSE" [ref=e264] [cursor=pointer]
```

# Test source

```ts
  63  |         if(command==='api' && args.path==='/localpilot/v1/sessions/sess_cached'){
  64  |           if(window.fixtureLookupStatus===200)return {id:'sess_cached',model:'fixture',active_task_id:null,last_task_id:null};
  65  |           const code=window.fixtureLookupStatus===404?'session_not_found':'service_unavailable';
  66  |           throw 'HTTP '+window.fixtureLookupStatus+' · '+JSON.stringify({error:{code,message:'Fixture service response'}});
  67  |         }
  68  |         if(command==='product_control' && args.operation==='documents'){
  69  |           if(window.fixtureService || !['existing','empty','transient'].includes(mode))throw Error('Unconfirmed Session reached document list');
  70  |           return {files:[],count:0};
  71  |         }
  72  |         if(command==='product_control' && args.operation==='workspace_grants')return {grants:[]};
  73  |         if(command==='pending_submissions')return [{key:'unknown_original',status:'unknown',body:{session_id:'sess_cached',input:'Unknown original request',model:'fixture'}}];
  74  |         if(command==='submission_history')return {};
  75  |         if(command==='session_preferences')return null;
  76  |         if(command==='setup_progress')return {stage:0};
  77  |         if(command==='discover_suites')return {installations:[]};
  78  |         return {};
  79  |       }
  80  |     `,
  81  |     }),
  82  |   );
  83  | }
  84  | 
  85  | async function calls(page: Page) {
  86  |   return page.evaluate(
  87  |     () =>
  88  |       ((window as any).recoveryCalls || []) as {
  89  |         command: string;
  90  |         args: any;
  91  |         service: number;
  92  |       }[],
  93  |   );
  94  | }
  95  | 
  96  | test("first setup never sends cached Session ids to the new service", async ({
  97  |   page,
  98  | }) => {
  99  |   await recoveryBridge(page, "onboarding");
  100 |   await page.goto("/");
  101 |   await expect
  102 |     .poll(async () =>
  103 |       (await calls(page)).some((c) => c.command === "submission_history"),
  104 |     )
  105 |     .toBe(true);
  106 |   expect(
  107 |     (await calls(page)).filter(
  108 |       (c) =>
  109 |         c.args.operation === "documents" || c.args.path?.includes("/sessions/"),
  110 |     ),
  111 |   ).toEqual([]);
  112 |   expect(
  113 |     await page.evaluate(
  114 |       () => JSON.parse(localStorage.getItem("lp.chats.v1")!).sess_cached.input,
  115 |     ),
  116 |   ).toBe("Unsent original text");
  117 | });
  118 | 
  119 | test("confirmed missing Session opens a draft without clearing foreign history or replaying UNKNOWN", async ({
  120 |   page,
  121 | }) => {
  122 |   await recoveryBridge(page, "missing");
  123 |   await page.goto("/");
  124 |   await expect
  125 |     .poll(() =>
  126 |       page.evaluate(() => JSON.parse(localStorage.getItem("lp.currentChat")!)),
  127 |     )
  128 |     .toMatch(/^draft-/);
  129 |   const observed = await calls(page);
  130 |   expect(
  131 |     observed.filter(
  132 |       (c) => c.args.path === "/localpilot/v1/sessions/sess_cached",
  133 |     ),
  134 |   ).toHaveLength(1);
  135 |   expect(observed.filter((c) => c.args.operation === "documents")).toEqual([]);
  136 |   expect(
  137 |     observed.filter((c) =>
  138 |       ["submit_task", "recover_submission"].includes(c.command),
  139 |     ),
  140 |   ).toEqual([]);
  141 |   expect(
  142 |     await page.evaluate(
  143 |       () => JSON.parse(localStorage.getItem("lp.chats.v1")!).sess_cached.input,
  144 |     ),
  145 |   ).toBe("Unsent original text");
  146 | });
  147 | 
  148 | test("service task history confirms the document Session and retains unknown receipts", async ({
  149 |   page,
  150 | }) => {
  151 |   await recoveryBridge(page, "existing");
  152 |   await page.goto("/");
  153 |   await expect(page.locator(".conversation")).toContainText("Original answer");
  154 |   await expect(
  155 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  156 |   ).toHaveValue("Unsent original text");
  157 |   await expect
  158 |     .poll(
  159 |       async () =>
  160 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  161 |           .length,
  162 |     )
> 163 |     .toBe(1);
      |      ^ Error: expect(received).toBe(expected) // Object.is equality
  164 |   const observed = await calls(page);
  165 |   expect(
  166 |     observed.find((c) => c.args.operation === "documents")!.args.args
  167 |       .session_id,
  168 |   ).toBe("sess_cached");
  169 |   expect(
  170 |     observed.filter(
  171 |       (c) =>
  172 |         c.args.path?.includes("/sessions/") ||
  173 |         ["submit_task", "recover_submission"].includes(c.command),
  174 |     ),
  175 |   ).toEqual([]);
  176 | });
  177 | 
  178 | test("503 leaves the selected Session intact and a later refresh can confirm it", async ({
  179 |   page,
  180 | }) => {
  181 |   await recoveryBridge(page, "transient");
  182 |   await page.goto("/");
  183 |   await expect(page.getByText(/HTTP 503 ·/)).toBeVisible();
  184 |   expect(
  185 |     await page.evaluate(() =>
  186 |       JSON.parse(localStorage.getItem("lp.currentChat")!),
  187 |     ),
  188 |   ).toBe("sess_cached");
  189 |   expect(
  190 |     (await calls(page)).filter((c) => c.args.operation === "documents"),
  191 |   ).toEqual([]);
  192 |   await page.evaluate(() => {
  193 |     (window as any).fixtureLookupStatus = 200;
  194 |   });
  195 |   await page.getByRole("button", { name: "刷新任务列表", exact: true }).click();
  196 |   await expect
  197 |     .poll(
  198 |       async () =>
  199 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  200 |           .length,
  201 |     )
  202 |     .toBe(1);
  203 |   await expect(
  204 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  205 |   ).toHaveValue("Unsent original text");
  206 |   await expect(page.getByText(/HTTP 503 ·/)).toHaveCount(0);
  207 |   expect(
  208 |     (await calls(page)).filter((c) => c.command === "submit_task"),
  209 |   ).toEqual([]);
  210 | });
  211 | 
  212 | test("a confirmed Session without tasks keeps staged documents available", async ({
  213 |   page,
  214 | }) => {
  215 |   await recoveryBridge(page, "empty");
  216 |   await page.goto("/");
  217 |   await expect
  218 |     .poll(
  219 |       async () =>
  220 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  221 |           .length,
  222 |     )
  223 |     .toBe(1);
  224 |   expect(
  225 |     await page.evaluate(() =>
  226 |       JSON.parse(localStorage.getItem("lp.currentChat")!),
  227 |     ),
  228 |   ).toBe("sess_cached");
  229 |   await expect(
  230 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  231 |   ).toHaveValue("Unsent original text");
  232 |   expect(
  233 |     (await calls(page)).filter((c) => c.command === "submit_task"),
  234 |   ).toEqual([]);
  235 | });
  236 | 
  237 | test("a different Suite root invalidates the old selection even at the same origin and client", async ({
  238 |   page,
  239 | }) => {
  240 |   await recoveryBridge(page, "existing");
  241 |   await page.goto("/");
  242 |   await expect(page.locator(".conversation")).toContainText("Original answer");
  243 |   await page.evaluate(() => {
  244 |     (window as any).fixtureService = 1;
  245 |   });
  246 |   await page.getByRole("button", { name: "刷新任务列表", exact: true }).click();
  247 |   await expect
  248 |     .poll(() =>
  249 |       page.evaluate(() => JSON.parse(localStorage.getItem("lp.currentChat")!)),
  250 |     )
  251 |     .toMatch(/^draft-/);
  252 |   await expect(page.locator(".conversation")).not.toContainText(
  253 |     "Original answer",
  254 |   );
  255 |   expect(
  256 |     (await calls(page)).filter(
  257 |       (c) => c.service === 1 && c.args.operation === "documents",
  258 |     ),
  259 |   ).toEqual([]);
  260 |   expect(
  261 |     await page.evaluate(
  262 |       () => JSON.parse(localStorage.getItem("lp.chats.v1")!).sess_cached.input,
  263 |     ),
```