# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: session-recovery.spec.ts >> first setup never sends cached Session ids to the new service
- Location: tests/ui/session-recovery.spec.ts:96:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 28

- Array []
+ Array [
+   Object {
+     "args": Object {
+       "args": Object {
+         "cursor": 0,
+         "limit": 100,
+         "operation": "list",
+         "session_id": "sess_cached",
+       },
+       "operation": "documents",
+     },
+     "command": "product_control",
+     "service": 0,
+   },
+   Object {
+     "args": Object {
+       "args": Object {
+         "cursor": 0,
+         "limit": 100,
+         "operation": "list",
+         "session_id": "sess_cached",
+       },
+       "operation": "documents",
+     },
+     "command": "product_control",
+     "service": 0,
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e6]:
      - generic [ref=e11]: LocalPilot
      - generic "5.0.1-rc.8 · 思考修复版" [ref=e12]: RC.7 · 思考修复
    - button "新会话 ⌘ N" [ref=e13] [cursor=pointer]:
      - text: 新会话
      - generic [ref=e15]: ⌘ N
    - button "模型库 模型、下载与推理服务" [ref=e16] [cursor=pointer]:
      - generic [ref=e21]:
        - text: 模型库
        - generic [ref=e22]: 模型、下载与推理服务
    - generic [ref=e25]:
      - textbox "搜索历史任务" [ref=e29]:
        - /placeholder: 搜索会话…
      - generic [ref=e30]: ⌘ K
    - generic [ref=e31]:
      - generic [ref=e32]: 工作区
      - button "工作区设置" [ref=e33] [cursor=pointer]
    - button "work 服务端绑定" [ref=e35] [cursor=pointer]:
      - generic [ref=e38]:
        - text: work
        - generic [ref=e39]: 服务端绑定
    - generic [ref=e42]:
      - generic [ref=e43]: 项目与会话
      - button "创建项目" [ref=e44] [cursor=pointer]
      - button "刷新任务列表" [ref=e47] [cursor=pointer]
    - navigation "任务历史" [ref=e53]:
      - generic [ref=e54]: 你的下一件作品从一次对话开始。
    - generic [ref=e55]:
      - button "服务已连接 Core fixture" [ref=e56] [cursor=pointer]:
        - generic [ref=e58]:
          - text: 服务已连接
          - generic [ref=e59]: Core fixture
      - generic [ref=e62]:
        - button "设置" [ref=e63] [cursor=pointer]
        - button "切换浅色或深色主题" [ref=e67] [cursor=pointer]
        - button "键盘快捷键" [ref=e70] [cursor=pointer]
    - separator "调整侧栏宽度" [ref=e73]
  - main [ref=e74]:
    - generic [ref=e75]:
      - generic [ref=e76]:
        - button "切换左侧栏" [ref=e77] [cursor=pointer]
        - generic [ref=e80]: work
        - generic [ref=e83]: 新会话
      - generic [ref=e84]:
        - generic [ref=e85]: 独立客户端
        - button "切换任务详情" [ref=e89] [cursor=pointer]
    - alert [ref=e92]:
      - generic [ref=e95]: "Error: Unconfirmed Session reached document list"
      - button "关闭错误" [ref=e96] [cursor=pointer]
    - generic [ref=e101]:
      - heading "今天，想完成什么？" [level=1] [ref=e107]
      - paragraph [ref=e108]: 从一个问题，或一件待办开始。
    - generic [ref=e109]:
      - generic [ref=e110]:
        - button "调整本会话偏好" [ref=e111] [cursor=pointer]:
          - generic [ref=e113]: 平衡
        - generic [ref=e116]: 仅此会话
      - generic [ref=e117]:
        - textbox "给 LocalPilot 发送消息" [ref=e119]:
          - /placeholder: 描述一个明确目标，让 Agent 帮你推进…
        - button "授权文件夹" [ref=e121] [cursor=pointer]: 选择文件夹
        - generic [ref=e122]:
          - generic [ref=e123]:
            - button "添加附件" [ref=e124] [cursor=pointer]
            - button "导入附件文件夹" [ref=e128] [cursor=pointer]: 文件夹
            - button "权限模式" [ref=e130] [cursor=pointer]: 工作区写入
            - generic "工作模式" [ref=e136]:
              - button "极简 Agent" [ref=e137] [cursor=pointer]
              - button "标准 Agent" [pressed] [ref=e141] [cursor=pointer]
            - button "选择模型" [ref=e148] [cursor=pointer]:
              - generic [ref=e150]: Recovery fixture
            - button "调整思考强度" [ref=e154] [cursor=pointer]
          - button "发送消息" [disabled] [ref=e156]
      - generic [ref=e159]:
        - button "查看本地、云端调用占比及子代理" [ref=e160] [cursor=pointer]: 本地/云端占比：暂无真实调用记录
        - generic [ref=e167]: 操作按当前权限执行 · 云端使用所选模型
        - generic [ref=e171]: Enter 换行 · ⌘ Enter 发送
  - dialog "让 LocalPilot 按你的习惯开始" [ref=e173]:
    - heading "让 LocalPilot 按你的习惯开始" [level=2] [ref=e175]
    - generic [ref=e176]:
      - generic [ref=e181]: WELCOME TO LOCALPILOT · 5.0.1-rc.8 · 思考修复版
      - paragraph [ref=e182]: 检测设备、准备服务，再接受推荐或跳过下载。以后可以在模型库随时调整。
    - generic [ref=e183]:
      - list "首次设置进度" [ref=e184]:
        - listitem [ref=e185]:
          - generic [ref=e186]: "1"
          - text: 欢迎使用
        - listitem [ref=e187]:
          - generic [ref=e188]: "2"
          - text: 准备 Agent
        - listitem [ref=e189]:
          - generic [ref=e190]: "3"
          - text: 连接消息平台
        - listitem [ref=e191]:
          - generic [ref=e192]: "4"
          - text: 完成设置
      - generic [ref=e193]:
        - heading "让 AI 帮你完成电脑上的任务" [level=3] [ref=e194]
        - paragraph [ref=e195]: 选择本地模型或填写 DeepSeek 密钥，即可开始。微信连接可以稍后再做。
        - paragraph [ref=e196]: macOS 需要 15 或更新版本。已有安装、模型和工作区会保留；需要下载时会单独确认。
      - generic [ref=e197]:
        - strong [ref=e200]: 正在检测安装状态
        - button "重新检测设备" [active] [ref=e201] [cursor=pointer]
      - button "开始准备 Agent" [ref=e208] [cursor=pointer]
    - alert [ref=e209]: "Error: Unconfirmed Session reached document list"
```

# Test source

```ts
  11  |       localStorage.setItem("lp.currentChat", JSON.stringify("sess_cached"));
  12  |       localStorage.setItem("lp.currentTask", JSON.stringify("resp_cached"));
  13  |       localStorage.setItem(
  14  |         "lp.chats.v1",
  15  |         JSON.stringify({
  16  |           sess_cached: {
  17  |             scope:
  18  |               mode === "missing"
  19  |                 ? "/old/home|http://127.0.0.1:8|old-client"
  20  |                 : "/fixture/home|http://127.0.0.1:9|fixture",
  21  |             title: "Preserved draft",
  22  |             input: "Unsent original text",
  23  |             preferences: {
  24  |               source: "balanced",
  25  |               objective: "balanced",
  26  |               effort: null,
  27  |             },
  28  |             model: "fixture",
  29  |           },
  30  |         }),
  31  |       );
  32  |     },
  33  |     { mode },
  34  |   );
  35  |   await page.route(
  36  |     "**/node_modules/.vite/deps/@tauri-apps_api_event.js*",
  37  |     (route) =>
  38  |       route.fulfill({
  39  |         contentType: "text/javascript",
  40  |         body: "export async function listen(){return ()=>{}};export async function once(){return ()=>{}};export async function emit(){};export async function emitTo(){}",
  41  |       }),
  42  |   );
  43  |   await page.route("**/src/bridge.ts", (route) =>
  44  |     route.fulfill({
  45  |       contentType: "text/javascript",
  46  |       body: `
  47  |       export const desktop=true;
  48  |       export async function streamListener(){return ()=>{}};
  49  |       const mode=${JSON.stringify(mode)};
  50  |       const caps=['durable_tasks','durable_idempotency','sse_cursor','verification_dimensions','model_registry','desktop_session_v1','desktop_session_idempotency_v1','attachments_v2'];
  51  |       const task={id:'resp_cached',session_id:'sess_cached',status:'completed',quiescent:true,model:'fixture',session_model:'fixture',user_input:'Original question',result:{text:'Original answer'},created_at:1,tools:[{receipt_id:'receipt_unknown',side_effect_status:'unknown'}],required_action:null,last_event_id:1};
  52  |       window.recoveryCalls=[];
  53  |       window.fixtureService=0;
  54  |       window.fixtureLookupStatus=mode==='transient'?503:mode==='empty'?200:404;
  55  |       export async function call(command,args={}){
  56  |         window.recoveryCalls.push({command,args:structuredClone(args),service:window.fixtureService});
  57  |         if(command==='profile')return {home:window.fixtureService?'/fixture/new-home':'/fixture/home',cli:'/fixture/cli',origin:'http://127.0.0.1:9',workspace:'/fixture/work'};
  58  |         if(command==='global_preferences')return {version:1,completed:mode!=='onboarding',defaults:{source:'balanced',objective:'balanced',effort:null}};
  59  |         if(command==='api' && args.path==='/healthz')return {status:'ready',persistence:true,version:'fixture',client_subject:'fixture',client_generation:1,compatibility:{agent_service_api:'1.0',companion_client_contract:'1.0',capabilities:caps}};
  60  |         if(command==='api' && args.path==='/localpilot/v1/model-registry')return {models:[{id:'fixture',model:'Recovery fixture',adapter:'local-openai',deployment_status:'ready',capabilities:['tool_calling'],cloud_egress:'LOCAL_ONLY'}]};
  61  |         if(command==='api' && args.path==='/localpilot/v1/tasks')return {tasks:mode==='existing' && !window.fixtureService?[structuredClone(task)]:[]};
  62  |         if(command==='api' && args.path==='/localpilot/v1/tasks/resp_cached')return structuredClone(task);
  63  |         if(command==='api' && args.path==='/localpilot/v1/sessions/sess_cached'){
  64  |           if(window.fixtureLookupStatus===200)return {id:'sess_cached',model:'fixture',active_task_id:null,last_task_id:null};
  65  |           const code=window.fixtureLookupStatus===404?'session_not_found':'service_unavailable';
  66  |           throw 'HTTP '+window.fixtureLookupStatus+' · '+JSON.stringify({error:{code,message:'Fixture service response'}});
  67  |         }
  68  |         if(command==='product_control' && args.operation==='documents'){
  69  |           if(window.fixtureService || !['existing','empty','transient'].includes(mode))throw Error('Unconfirmed Session reached document list');
  70  |           return {files:[],count:0};
  71  |         }
  72  |         if(command==='product_control' && args.operation==='workspace_grants')return {grants:[]};
  73  |         if(command==='pending_submissions')return [{key:'unknown_original',status:'unknown',body:{session_id:'sess_cached',input:'Unknown original request',model:'fixture'}}];
  74  |         if(command==='submission_history')return {};
  75  |         if(command==='session_preferences')return null;
  76  |         if(command==='setup_progress')return {stage:0};
  77  |         if(command==='discover_suites')return {installations:[]};
  78  |         return {};
  79  |       }
  80  |     `,
  81  |     }),
  82  |   );
  83  | }
  84  | 
  85  | async function calls(page: Page) {
  86  |   return page.evaluate(
  87  |     () =>
  88  |       ((window as any).recoveryCalls || []) as {
  89  |         command: string;
  90  |         args: any;
  91  |         service: number;
  92  |       }[],
  93  |   );
  94  | }
  95  | 
  96  | test("first setup never sends cached Session ids to the new service", async ({
  97  |   page,
  98  | }) => {
  99  |   await recoveryBridge(page, "onboarding");
  100 |   await page.goto("/");
  101 |   await expect
  102 |     .poll(async () =>
  103 |       (await calls(page)).some((c) => c.command === "submission_history"),
  104 |     )
  105 |     .toBe(true);
  106 |   expect(
  107 |     (await calls(page)).filter(
  108 |       (c) =>
  109 |         c.args.operation === "documents" || c.args.path?.includes("/sessions/"),
  110 |     ),
> 111 |   ).toEqual([]);
      |     ^ Error: expect(received).toEqual(expected) // deep equality
  112 |   expect(
  113 |     await page.evaluate(
  114 |       () => JSON.parse(localStorage.getItem("lp.chats.v1")!).sess_cached.input,
  115 |     ),
  116 |   ).toBe("Unsent original text");
  117 | });
  118 | 
  119 | test("confirmed missing Session opens a draft without clearing foreign history or replaying UNKNOWN", async ({
  120 |   page,
  121 | }) => {
  122 |   await recoveryBridge(page, "missing");
  123 |   await page.goto("/");
  124 |   await expect
  125 |     .poll(() =>
  126 |       page.evaluate(() => JSON.parse(localStorage.getItem("lp.currentChat")!)),
  127 |     )
  128 |     .toMatch(/^draft-/);
  129 |   const observed = await calls(page);
  130 |   expect(
  131 |     observed.filter(
  132 |       (c) => c.args.path === "/localpilot/v1/sessions/sess_cached",
  133 |     ),
  134 |   ).toHaveLength(1);
  135 |   expect(observed.filter((c) => c.args.operation === "documents")).toEqual([]);
  136 |   expect(
  137 |     observed.filter((c) =>
  138 |       ["submit_task", "recover_submission"].includes(c.command),
  139 |     ),
  140 |   ).toEqual([]);
  141 |   expect(
  142 |     await page.evaluate(
  143 |       () => JSON.parse(localStorage.getItem("lp.chats.v1")!).sess_cached.input,
  144 |     ),
  145 |   ).toBe("Unsent original text");
  146 | });
  147 | 
  148 | test("service task history confirms the document Session and retains unknown receipts", async ({
  149 |   page,
  150 | }) => {
  151 |   await recoveryBridge(page, "existing");
  152 |   await page.goto("/");
  153 |   await expect(page.locator(".conversation")).toContainText("Original answer");
  154 |   await expect(
  155 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  156 |   ).toHaveValue("Unsent original text");
  157 |   await expect
  158 |     .poll(
  159 |       async () =>
  160 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  161 |           .length,
  162 |     )
  163 |     .toBe(1);
  164 |   const observed = await calls(page);
  165 |   expect(
  166 |     observed.find((c) => c.args.operation === "documents")!.args.args
  167 |       .session_id,
  168 |   ).toBe("sess_cached");
  169 |   expect(
  170 |     observed.filter(
  171 |       (c) =>
  172 |         c.args.path?.includes("/sessions/") ||
  173 |         ["submit_task", "recover_submission"].includes(c.command),
  174 |     ),
  175 |   ).toEqual([]);
  176 | });
  177 | 
  178 | test("503 leaves the selected Session intact and a later refresh can confirm it", async ({
  179 |   page,
  180 | }) => {
  181 |   await recoveryBridge(page, "transient");
  182 |   await page.goto("/");
  183 |   await expect(page.getByText(/HTTP 503 ·/)).toBeVisible();
  184 |   expect(
  185 |     await page.evaluate(() =>
  186 |       JSON.parse(localStorage.getItem("lp.currentChat")!),
  187 |     ),
  188 |   ).toBe("sess_cached");
  189 |   expect(
  190 |     (await calls(page)).filter((c) => c.args.operation === "documents"),
  191 |   ).toEqual([]);
  192 |   await page.evaluate(() => {
  193 |     (window as any).fixtureLookupStatus = 200;
  194 |   });
  195 |   await page.getByRole("button", { name: "刷新任务列表", exact: true }).click();
  196 |   await expect
  197 |     .poll(
  198 |       async () =>
  199 |         (await calls(page)).filter((c) => c.args.operation === "documents")
  200 |           .length,
  201 |     )
  202 |     .toBe(1);
  203 |   await expect(
  204 |     page.getByRole("textbox", { name: "给 LocalPilot 发送消息" }),
  205 |   ).toHaveValue("Unsent original text");
  206 |   await expect(page.getByText(/HTTP 503 ·/)).toHaveCount(0);
  207 |   expect(
  208 |     (await calls(page)).filter((c) => c.command === "submit_task"),
  209 |   ).toEqual([]);
  210 | });
  211 | 
```