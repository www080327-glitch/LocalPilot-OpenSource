# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: intel-setup.spec.ts >> Linux setup uses the same explicit HTTP route without offering MLX
- Location: tests/ui/intel-setup.spec.ts:48:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - list "首次设置进度" [ref=e5]:
      - listitem [ref=e6]:
        - generic [ref=e7]: "1"
        - text: 欢迎使用
      - listitem [ref=e8]:
        - generic [ref=e9]: "2"
        - text: 准备 Agent
      - listitem [ref=e10]:
        - generic [ref=e11]: "3"
        - text: 连接消息平台
      - listitem [ref=e12]:
        - generic [ref=e13]: "4"
        - text: 完成设置
    - generic [ref=e14]:
      - strong [ref=e17]: 正在检测安装状态
      - button "重新检测设备" [ref=e18] [cursor=pointer]
    - group [ref=e24]:
      - generic "高级 · 设备信息" [ref=e25] [cursor=pointer]
    - region "连接本机模型服务" [ref=e26]:
      - heading "连接本机模型服务" [level=3] [ref=e27]
      - paragraph [ref=e28]: Intel Mac 可使用 llama.cpp 等推理程序的本机 OpenAI 兼容服务。 先启动服务并加载支持工具调用的模型，再填写地址。CPU 或 GPU 加速由推理服务选择；模型权重不包含在 LocalPilot 中。
      - generic [ref=e29]:
        - text: 本机路由名称
        - textbox "本机路由名称" [ref=e30]: local-cpu
      - generic [ref=e31]:
        - text: 本机端点
        - textbox "本机端点" [ref=e32]:
          - /placeholder: http://127.0.0.1:1234/v1
          - text: http://127.0.0.1:1234/v1
      - button "检查连接并读取模型列表" [ref=e33] [cursor=pointer]
      - paragraph [ref=e34]: 此检查只读取模型列表，不发送推理请求。
      - generic [ref=e35]:
        - text: 服务报告的模型
        - combobox "服务报告的模型" [ref=e36]:
          - option "选择模型"
          - option "fixture-gguf" [selected]
      - generic [ref=e37]:
        - text: 模型 ID
        - textbox "模型 ID" [ref=e38]: fixture-gguf
      - generic [ref=e39]:
        - text: 上下文 token 上限
        - spinbutton "上下文 token 上限" [active] [ref=e40]: "2048"
      - paragraph [ref=e41]: 模型列表不能证明上下文容量；请使用服务实际加载时的配置。
      - generic [ref=e42]:
        - checkbox "请求后端关闭模型思考输出" [ref=e43]
        - text: 请求后端关闭模型思考输出
      - paragraph [ref=e44]: 仅向支持该选项的后端发送关闭请求；是否生效仍需实际回答验证。
      - generic [ref=e45]:
        - checkbox "同时让 Companion 使用这个本机端点" [checked] [ref=e46]
        - text: 同时让 Companion 使用这个本机端点
      - generic [ref=e47]:
        - text: Companion 推理电源策略
        - combobox "Companion 推理电源策略 跟随系统时，低功耗或未知电源状态可能阻止未受管端点推理。 关闭低功耗限制只改变 Companion 的策略，不改变系统电源设置。 电池推理授权仍单独检查。" [ref=e48]:
          - option "跟随系统电源策略" [selected]
          - option "保留现有策略"
          - option "关闭 Companion 低功耗限制"
        - text: 跟随系统时，低功耗或未知电源状态可能阻止未受管端点推理。 关闭低功耗限制只改变 Companion 的策略，不改变系统电源设置。 电池推理授权仍单独检查。
      - button "保存本机模型配置" [disabled] [ref=e49]
      - status [ref=e50]:
        - paragraph [ref=e51]: 已连接服务；真实推理尚未验证。
    - button "连接 LocalPilot" [ref=e52] [cursor=pointer]
    - generic [ref=e53]:
      - heading "使用 DeepSeek" [level=3] [ref=e54]
      - textbox "首次设置 DeepSeek API 密钥" [ref=e55]:
        - /placeholder: DeepSeek API 密钥
      - button "保存并连接" [disabled] [ref=e56]
      - paragraph [ref=e57]: 密钥仅保存到本机私有目录，添加配置不会发送任务。
    - group [ref=e58]:
      - generic "高级 · 工作文件夹" [ref=e59] [cursor=pointer]
    - paragraph [ref=e60]: 当前没有同时满足可用内存与 Core 主 Agent 上下文要求的本地建议。你可以跳过下载，稍后在模型库选择，或连接云端模型。
    - button "跳过，稍后自行选择" [ref=e61] [cursor=pointer]
    - generic [ref=e62]:
      - button "上一步" [ref=e63] [cursor=pointer]
      - button "继续 · 连接消息平台" [ref=e64] [cursor=pointer]
```