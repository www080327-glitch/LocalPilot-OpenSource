#!/bin/bash
set -eu
cd <WORKSPACE>/LocalPilot-polish-final-20261116
source <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
export PYTHONPATH="$PWD/suite"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export LOCALPILOT_WORKER_BUDGET_LEGACY_SOURCE=<WORKSPACE>/LocalPilot-polish-20261116
nice -n 15 <WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python -m unittest discover -s suite/tests -v > <WORKSPACE>/validation/polish-20261116/regression/suite-final-r4.log 2>&1
