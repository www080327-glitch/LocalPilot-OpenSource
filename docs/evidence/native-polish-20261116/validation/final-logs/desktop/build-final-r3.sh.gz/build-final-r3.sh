#!/bin/bash
set -eu
cd <WORKSPACE>/LocalPilot-polish-final-20261116
source <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
export PATH="/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:$PATH"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
LP_FINAL_WHEELS=<WORKSPACE>/validation/polish-20261116/desktop/wheels-final-r3
mkdir "$LP_FINAL_WHEELS"
<WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python -m build --wheel --no-isolation --outdir "$LP_FINAL_WHEELS" . > <WORKSPACE>/validation/polish-20261116/desktop/component-wheel-final-r3-core.log 2>&1
<WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python -m build --wheel --no-isolation --outdir "$LP_FINAL_WHEELS" companion > <WORKSPACE>/validation/polish-20261116/desktop/component-wheel-final-r3-companion.log 2>&1
<WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python -m build --wheel --no-isolation --outdir "$LP_FINAL_WHEELS" suite > <WORKSPACE>/validation/polish-20261116/desktop/component-wheel-final-r3-suite.log 2>&1
<WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python scripts/build_channels_wheel.py --no-isolation --out "$LP_FINAL_WHEELS" > <WORKSPACE>/validation/polish-20261116/desktop/component-wheel-final-r3-channels.log 2>&1
mv desktop/src-tauri/bundled-backends <WORKSPACE>/validation/polish-20261116/desktop/resources-before-final-r3
<WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python desktop/scripts/linux_backends.py prepare --python /usr/bin/python3 --wheels "$LP_FINAL_WHEELS" --dependencies <WORKSPACE>/validation/linux-20261116/desktop/dependencies --dependency-lock desktop/runtime-dependencies-linux-x86_64-py313.json --channel-runtime <WORKSPACE>/validation/linux-20261116/runtime-inputs/node-v22.23.4-linux-x64.tar.gz > <WORKSPACE>/validation/polish-20261116/desktop/prepare-resources-final-r3.log 2>&1
cd desktop
LP_GUI_USE_INSTALLED_DEPS=1 LP_GUI_TEST_CONFIG=src-tauri/tauri.test.conf.json npm run release:linux > <WORKSPACE>/validation/polish-20261116/desktop/build-linux-test-final-r3.log 2>&1
