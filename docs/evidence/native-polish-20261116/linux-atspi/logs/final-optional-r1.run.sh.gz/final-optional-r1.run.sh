#!/bin/bash
set -eu
cd <WORKSPACE>/LocalPilot-polish-final-20261116
export PYTHONPATH="<WORKSPACE>/LocalPilot-polish-final-20261116"
export LOCALPILOT_SOURCE="<WORKSPACE>/LocalPilot-polish-final-20261116"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export TOKENIZERS_PARALLELISM=false
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export LOCALPILOT_TEST_WHISPER_CLI="<WORKSPACE>/validation/linux-20261116/companion/whisper-build/bin/whisper-cli"
export LOCALPILOT_TEST_WHISPER_MODEL="<WORKSPACE>/validation/linux-20261116/companion/ggml-tiny.en.bin"
export LOCALPILOT_TEST_WHISPER_WAV="<WORKSPACE>/validation/linux-20261116/companion/whisper-reference/samples/jfk.wav"
export LOCALPILOT_TEST_WHISPER_SHA256="921e4cf8686fdd993dcd081a5da5b6c365bfde1162e72b08d75ac75289920b1f"
<WORKSPACE>/validation/linux-20261116/training-env/bin/python - <<'VERIFY'
from pathlib import Path
import hashlib,json
run=Path('<WORKSPACE>/validation/polish-20261116/companion/final-optional-r1')
identity=json.loads((run/'preflight-identity.json').read_text())
for name,record in identity['asr_files'].items():
    if hashlib.sha256(Path(record['path']).read_bytes()).hexdigest()!=record['expected_sha256']:
        raise SystemExit('ASR artifact changed since verified preflight: '+name)
repo=Path.cwd()
files=sorted((repo/'companion').rglob('*.py'))+[repo/'companion/pyproject.toml',repo/'companion/MODULE_RELEASE.json']
(run/'source-before.json').write_text(json.dumps({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
VERIFY
status=0
nice -n 15 <WORKSPACE>/validation/linux-20261116/training-env/bin/python -m unittest companion.tests.test_portable_training companion.tests.test_linux_whisper -v > <WORKSPACE>/validation/polish-20261116/companion/final-optional-r1/run.log 2>&1 || status=$?
printf '%s\n' "$status" > <WORKSPACE>/validation/polish-20261116/companion/final-optional-r1/exitcode
exit "$status"
