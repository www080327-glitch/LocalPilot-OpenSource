#!/bin/bash
set -eu
. <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
exec dbus-run-session -- <WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python <WORKSPACE>/validation/polish-20261116/desktop/linux-native-diagnostic-r1/fixture_diagnostic.py > <WORKSPACE>/validation/polish-20261116/desktop/linux-native-diagnostic-r1/run.log 2>&1
