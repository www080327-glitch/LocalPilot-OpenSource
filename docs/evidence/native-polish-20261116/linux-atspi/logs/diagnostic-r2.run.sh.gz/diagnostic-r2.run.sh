#!/bin/bash
set -eu
. <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
unset AT_SPI_BUS_ADDRESS
export XDG_RUNTIME_DIR
XDG_RUNTIME_DIR=$(mktemp -d /tmp/localpilot-owned-atspi.XXXXXX)
trap 'rm -rf -- "$XDG_RUNTIME_DIR"' EXIT
status=0
dbus-run-session -- <WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python <WORKSPACE>/validation/polish-20261116/desktop/linux-native-diagnostic-r2/fixture_diagnostic.py > <WORKSPACE>/validation/polish-20261116/desktop/linux-native-diagnostic-r2/run.log 2>&1 || status=$?
printf '%s\n' "$status" > <WORKSPACE>/validation/polish-20261116/desktop/linux-native-diagnostic-r2/exitcode
exit "$status"
