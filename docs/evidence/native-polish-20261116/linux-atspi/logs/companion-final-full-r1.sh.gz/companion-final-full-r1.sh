#!/bin/bash
set -eu
cd <WORKSPACE>/LocalPilot-polish-final-20261116
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export PYTHONPATH="<WORKSPACE>/LocalPilot-polish-final-20261116"
export LOCALPILOT_SOURCE="<WORKSPACE>/LocalPilot-polish-final-20261116"
status=0
nice -n 15 <WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python -m unittest discover -s companion/tests -t . -v > <WORKSPACE>/validation/polish-20261116/companion/final-full-r1/run.log 2>&1 || status=$?
printf '%s\n' "$status" > <WORKSPACE>/validation/polish-20261116/companion/final-full-r1/exitcode
exit "$status"
