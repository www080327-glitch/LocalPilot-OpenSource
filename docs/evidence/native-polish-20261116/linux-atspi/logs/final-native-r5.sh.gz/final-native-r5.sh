#!/bin/bash
set -eu
. <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
cd <WORKSPACE>/LocalPilot-polish-final-20261116
export PYTHONPATH="<WORKSPACE>/LocalPilot-polish-final-20261116"
status=0
<WORKSPACE>/LocalPilot-OpenSource/.venv/bin/python -m unittest companion.tests.test_linux_native companion.tests.test_linux_runtime.LinuxObservationTests -v > <WORKSPACE>/validation/polish-20261116/desktop/linux-native-final-r5/run.log 2>&1 || status=$?
printf '%s\n' "$status" > <WORKSPACE>/validation/polish-20261116/desktop/linux-native-final-r5/exitcode
exit "$status"
