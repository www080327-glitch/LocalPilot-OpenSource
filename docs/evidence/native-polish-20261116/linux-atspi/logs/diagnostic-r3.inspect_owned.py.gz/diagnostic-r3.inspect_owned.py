import json,sys,time,os
from pathlib import Path
sys.path.insert(0, '<WORKSPACE>/LocalPilot-polish-20261116')
from companion.observers.linux_helper import atspi_module, atspi_snapshot, x11_window, read_atspi_tree
pid=int(sys.argv[1]);options=json.loads(sys.argv[2]);atspi=atspi_module();atspi.set_timeout(500,1000)
start=time.monotonic();result={'phase':'owned_accessibility','pid':pid,'foreground':x11_window(),'owned_windows':[]}
try:
 desktop=atspi.get_desktop(0);result['application_count']=desktop.get_child_count()
 for i in range(min(desktop.get_child_count(),100)):
  app=desktop.get_child_at_index(i)
  if app.get_process_id()!=pid: continue
  result['found_owned_application']=True
  for j in range(min(app.get_child_count(),8)):
   window=app.get_child_at_index(j)
   row={'title':window.get_name(),'role':str(window.get_role()),'states':[str(s) for s in window.get_state_set().get_states()],'child_count':window.get_child_count()}
   row['tree']=read_atspi_tree(window,atspi,options)
   row['static_text_probe']=[]
   for box_index in range(window.get_child_count()):
    box=window.get_child_at_index(box_index)
    for item_index in range(box.get_child_count()):
     item=box.get_child_at_index(item_index)
     if item.get_role()!=atspi.Role.LABEL:continue
     interface=item.get_text_iface()
     static={'class':str(type(interface)), 'method':interface.get_text.__doc__}
     try:static['old_call']=interface.get_text(0, min(500,interface.get_character_count()))
     except Exception as e:static['old_error']=repr(e)
     try:static['explicit_interface_call']=atspi.Text.get_text(interface,0,min(500,atspi.Text.get_character_count(interface)))
     except Exception as e:static['new_error']=repr(e)
     row['static_text_probe'].append(static)
   result['owned_windows'].append(row)
 result['actual_product_snapshot']=atspi_snapshot(atspi,options,result['foreground'])
except Exception as e:result['exception']=repr(e)
result['seconds']=time.monotonic()-start
print(json.dumps(result,ensure_ascii=False),flush=True)
