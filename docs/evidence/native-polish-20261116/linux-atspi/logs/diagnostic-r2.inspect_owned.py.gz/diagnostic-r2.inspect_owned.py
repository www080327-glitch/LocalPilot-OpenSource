import json,sys,time,os
from pathlib import Path
sys.path.insert(0, '<WORKSPACE>/LocalPilot-polish-20261116')
from companion.observers.linux_helper import atspi_module, atspi_snapshot, x11_window, read_atspi_tree
pid=int(sys.argv[1]);options=json.loads(sys.argv[2]);atspi=atspi_module();atspi.set_timeout(500,1000)
start=time.monotonic();result={'phase':'owned_accessibility','pid':pid,'foreground':x11_window(),'owned_windows':[]}
try:
 desktop=atspi.get_desktop(0);result['application_count']=desktop.get_child_count()
 for i in range(min(desktop.get_child_count(),100)):
  app=desktop.get_child_at_index(i)
  if app.get_process_id()!=pid: continue
  result['found_owned_application']=True
  for j in range(min(app.get_child_count(),8)):
   window=app.get_child_at_index(j)
   row={'title':window.get_name(),'role':str(window.get_role()),'states':[str(s) for s in window.get_state_set().get_states()],'child_count':window.get_child_count()}
   row['tree']=read_atspi_tree(window,atspi,options)
   result['owned_windows'].append(row)
 result['actual_product_snapshot']=atspi_snapshot(atspi,options,result['foreground'])
except Exception as e:result['exception']=repr(e)
result['seconds']=time.monotonic()-start
print(json.dumps(result,ensure_ascii=False),flush=True)
