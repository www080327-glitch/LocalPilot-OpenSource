#!/bin/bash
set -eu
source <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
exec bash <WORKSPACE>/validation/polish-20261116/desktop/webkit-namespace-preflight-r1/launch-owned-webview.sh <WORKSPACE>/validation/polish-20261116/desktop/native-final-r2-extracted/usr/bin/localpilot-desktop-test <WORKSPACE>/validation/polish-20261116/desktop/native-final-profile-a >> <WORKSPACE>/validation/polish-20261116/desktop/native-final-r2-a.log 2>&1
