# Minimal read-only WebKit helper overlay (diagnostic only)

The candidate is the final extracted Linux x86_64 Test APP, Desktop 5.0.1-rc.9 / Core 5.0.0b25 / Suite 0.2.0b30 / Companion 0.5.7b6 / Channels 0.1.0a3. Executable SHA-256: `d606f5e1f1cee68a25a2a88c7e8fa300d49b7c5f272f6518bca06efa9fc1a8c0`.

This validation-only layer contains six unmodified files: the five regular files in the existing WebKit helper directory (three process helpers, MiniBrowser, and the injected bundle) and xdg-dbus-proxy. `package-origin-check.json` verifies every byte against members of the already acquired, SHA-256-verified Debian packages. No sysroot shared libraries or other /usr/bin files are added to the overlay. The original toolchain LD_LIBRARY_PATH remains unchanged.

The CLI checks passed: exact helper/proxy hashes, read-only overlay mounts, unchanged network namespace, preserved seccomp mode/filter count and privilege limits, and an ordinary nested bubblewrap process. These checks are not proof of a live WebKit child sandbox. The prior CUA baseline has Seccomp=0, while the exec baseline has Seccomp=2; both were preserved. No OS policy or sandbox configuration was weakened.

The same final candidate passes `--bundle-self-check` in plain, full sysroot overlay, and minimal overlay modes: 40 wheels, no services started, no user database opened. `ldd` in the three modes resolves 169 lines without missing dependencies; after removing runtime addresses the paths are identical. This does not qualify the graphical path.

Actual CUA attempts are retained outside this directory: r3 (full overlay) and r4 (minimal overlay) both exit 139 during graphical startup with empty logs and no observed window. The test root does contain an empty `client/webview/...` directory. Thus there is no basis to describe these failures as necessarily preceding Rust main or as a general ELF loader failure.

The same final candidate without the namespace wrapper (r5), using the same test root, TMPDIR, XDG_RUNTIME_DIR and LD_LIBRARY_PATH, instead exits -5 and explicitly reports that `/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/WebKitNetworkProcess` does not exist. This distinguishes the wrapper-specific 139 from the known missing system helper path; it does not prove why the wrapper path failed.

Only the root agent operates the CUA desktop. The launcher and diagnostic scripts do not install the DEB, modify host /usr, patch any binary, disable WebKit sandboxing, or alter kernel/network policy. No candidate substitution was made. The next optional r6 trace is a separate owned-process diagnostic, not a product or installation test.
