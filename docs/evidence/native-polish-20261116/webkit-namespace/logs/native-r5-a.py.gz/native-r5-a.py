import hashlib,json,os,subprocess,time
from pathlib import Path
out=Path('<WORKSPACE>/validation/polish-20261116/desktop')
command=[str(out/'native-final-r2-extracted/usr/bin/localpilot-desktop-test')]
launch_env=os.environ.copy()
launch_env['LP_INSTALL_TEST_ROOT']=str(out/'native-final-profile-a')
launch_env['TMPDIR']=str(out/'native-final-profile-a/tmp')
launch_env['XDG_RUNTIME_DIR']=str(out/'native-final-profile-a/runtime')
record={'command':command,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'display':os.environ.get('DISPLAY'),'xdg_session_type':os.environ.get('XDG_SESSION_TYPE'),'webkit_disable_sandbox_present':'WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS' in os.environ}
record['candidate_sha256']=hashlib.sha256(Path(command[0]).read_bytes()).hexdigest()
record['scope']='Plain same final RC9 candidate, same test root/TMPDIR/XDG_RUNTIME_DIR and LD_LIBRARY_PATH, no namespace wrapper, no system installation, no WebKit sandbox disable.'
with (out/'native-final-r5-a.log').open('x') as log:
 p=subprocess.Popen(command,stdout=log,stderr=log,env=launch_env)
 record['pid']=p.pid
 (out/'native-final-r5-a-process.json').write_text(json.dumps(record,indent=2))
 record['returncode']=p.wait()
 record['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (out/'native-final-r5-a-process.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
