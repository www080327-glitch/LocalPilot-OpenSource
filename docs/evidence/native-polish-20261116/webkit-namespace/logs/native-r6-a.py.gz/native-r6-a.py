import hashlib,json,os,subprocess,time
from pathlib import Path
out=Path('<WORKSPACE>/validation/polish-20261116/desktop')
strace='/usr/bin/strace'
selection=['-e','trace=%file,%process,%signal,prctl,seccomp','-e','raw=execve,execveat','-s','160']
record={'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'display':os.environ.get('DISPLAY'),'xdg_session_type':os.environ.get('XDG_SESSION_TYPE'),'webkit_disable_sandbox_present':'WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS' in os.environ,'strace_sha256':hashlib.sha256(Path(strace).read_bytes()).hexdigest(),'policy_changed':False,'trace_scope':'Only this owned test process descendants: file/process/signal/prctl/seccomp; no read/write calls, execve/execveat raw addresses omit argv/environment values.'}
status={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in Path('/proc/self/status').read_text().splitlines() if line.startswith(('CapEff:','CapBnd:','Seccomp:','Seccomp_filters:','NoNewPrivs:'))}
record['outer_status']=status
probe=[strace,'-f','-o',str(out/'native-final-r6-true.trace'),*selection,'--','/usr/bin/true']
p=subprocess.run(probe,capture_output=True,text=True,timeout=8)
record['ptrace_probe']={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
if p.returncode!=0:
 record['status']='BLOCKED_PTRACE'
 record['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (out/'native-final-r6-a-process.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2))
 raise SystemExit(0)
app=out/'native-final-r2-extracted/usr/bin/localpilot-desktop-test'
launch=['bash',str(out/'webkit-minimal-overlay-r4/launch-owned-webview-minimal.sh'),str(app),str(out/'native-final-profile-a')]
command=[strace,'-f','-ttt','-k','--stack-trace-frame-limit=24','-o',str(out/'native-final-r6-a.trace'),*selection,'--',*launch]
record['command']=command
record['candidate_sha256']=hashlib.sha256(app.read_bytes()).hexdigest()
record['scope']='Same minimal read-only helper overlay and final RC9 candidate; instrumentation may affect namespace child behavior and is diagnostic only.'
with (out/'native-final-r6-a.log').open('x') as log:
 p=subprocess.Popen(command,stdout=log,stderr=log)
 record['pid']=p.pid
 (out/'native-final-r6-a-process.json').write_text(json.dumps(record,indent=2)+'\n')
 record['returncode']=p.wait()
 record['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (out/'native-final-r6-a-process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
