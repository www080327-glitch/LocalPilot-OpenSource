#!/bin/bash
set -eu
export LP_PREFLIGHT_BASELINE_JSON="$(/usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r7/audit_readonly.py --baseline)"
exec /usr/bin/bwrap --unshare-user --unshare-pid --ro-bind / / --proc /proc --dev /dev --die-with-parent \
 --overlay-src /usr/lib/x86_64-linux-gnu \
 --overlay-src <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r4/layer/lib \
 --ro-overlay /usr/lib/x86_64-linux-gnu \
 --overlay-src /usr/bin \
 --overlay-src <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r4/layer/bin \
 --ro-overlay /usr/bin \
 -- /usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r7/audit_readonly.py
