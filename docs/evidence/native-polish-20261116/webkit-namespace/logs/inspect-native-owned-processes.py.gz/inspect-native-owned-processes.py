import json,os,sys,time
from pathlib import Path
base=Path('<WORKSPACE>/validation/polish-20261116/desktop')
run=base/'native-final-r9-a-process.json'
root_pid=int(json.loads(run.read_text())['pid'])
statuses={}
fields={'Name','State','Pid','PPid','Uid','Gid','NSpid','NoNewPrivs','Seccomp','Seccomp_filters','CapEff','CapBnd'}
for path in Path('/proc').iterdir():
 if not path.name.isdigit():
  continue
 try:
  status={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in (path/'status').read_text().splitlines() if ':' in line and line.split(':',1)[0] in fields}
  statuses[int(path.name)]=status
 except (OSError,ValueError):
  continue
owned={root_pid}
while True:
 expanded=owned|{pid for pid,status in statuses.items() if int(status.get('PPid','-1')) in owned}
 if expanded==owned: break
 owned=expanded
rows=[]
for pid in sorted(owned):
 if pid not in statuses: continue
 row={'pid':pid,'status':statuses[pid],'namespaces':{}}
 for name in ['user','mnt','pid','net']:
  try: row['namespaces'][name]=os.readlink('/proc/'+str(pid)+'/ns/'+name)
  except OSError as error: row['namespaces'][name]={'errno':error.errno}
 try: row['executable']=os.readlink('/proc/'+str(pid)+'/exe')
 except OSError as error: row['executable']={'errno':error.errno}
 rows.append(row)
result={'captured_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'root_pid':root_pid,'root_found':root_pid in statuses,'scope':'Only descendants of the owned r9 candidate wrapper. No argv, environment, file contents, cookie or user database reads. Namespace/status metadata alone does not prove every sandbox rule.', 'processes':rows}
print(json.dumps(result,indent=2))
