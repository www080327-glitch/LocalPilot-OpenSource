from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import sys


def process_identity():
    wanted = ('CapEff:', 'CapBnd:', 'NoNewPrivs:', 'Seccomp:', 'Seccomp_filters:')
    status = {line.split(':', 1)[0]: line.split(':', 1)[1].strip()
              for line in Path('/proc/self/status').read_text().splitlines()
              if line.startswith(wanted)}
    return {'status': status, 'net_namespace': os.readlink('/proc/self/ns/net')}


if sys.argv[1:] == ['--baseline']:
    print(json.dumps(process_identity()))
    raise SystemExit(0)

baseline = json.loads(os.environ['LP_PREFLIGHT_BASELINE_JSON'])
current = process_identity()
paths = ['/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/WebKitNetworkProcess',
         '/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/WebKitWebProcess',
         '/usr/bin/xdg-dbus-proxy', '/usr/bin/bwrap']
expected = {
    paths[0]: 'c46b720e9f2c295dd96ae95fbbe299554f444c3d4ebd77d04e8a8349a0570091',
    paths[1]: 'c39f4bd3efcef47e2b0f19911d44c3cbb97e75ebd237cbb26e6bdf607cc927c1',
    paths[2]: 'e7610831aa4572582775420b61ed1deb83d18aacf8cfd62dcf598eefc9be86c0',
    paths[3]: '573236e5328ac2ebb08f59ae3a9805b4f8d12bdef14be8af4450d5463294985f',
}
actual = {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in paths}
nested = subprocess.run(['/usr/bin/bwrap', '--unshare-user', '--unshare-pid',
                         '--ro-bind', '/', '/', '--proc', '/proc', '--die-with-parent',
                         '--', '/usr/bin/true'], capture_output=True, text=True, timeout=5)
with open('/dev/urandom', 'rb', buffering=0) as entropy_source:
    entropy_bytes_read = len(entropy_source.read(32))
dev_mount_rows = [line.split(' - ', 1) for line in Path('/proc/self/mountinfo').read_text().splitlines() if line.split()[4] == '/dev']
dev_filesystems = [row[1].split()[0] for row in dev_mount_rows]
x11_baseline = json.loads(os.environ['LP_PREFLIGHT_X11_IDENTITY_JSON'])
x11_path = Path(os.environ['XAUTHORITY'])
x11_stat = x11_path.stat()
x11_file = {'path': str(x11_path), 'mode': oct(stat.S_IMODE(x11_stat.st_mode)), 'uid': x11_stat.st_uid, 'gid': x11_stat.st_gid, 'device': x11_stat.st_dev, 'inode': x11_stat.st_ino, 'regular_file': stat.S_ISREG(x11_stat.st_mode), 'readonly_mount': bool(os.statvfs(x11_path).f_flag & os.ST_RDONLY), 'cookie_contents_read': False}
x11_fd = os.open(x11_path, os.O_RDONLY)
os.close(x11_fd)
checks = {
    'existing_x11_file_same_inode': x11_file['device'] == x11_baseline['file']['device'] and x11_file['inode'] == x11_baseline['file']['inode'],
    'existing_x11_file_mode_and_owner_preserved': all(x11_file[k] == x11_baseline['file'][k] for k in ['mode', 'uid', 'gid']),
    'existing_x11_file_regular_and_readonly': x11_file['regular_file'] and x11_file['readonly_mount'],
    'urandom_read_32_bytes': entropy_bytes_read == 32,
    'private_dev_tmpfs_present': 'tmpfs' in dev_filesystems,
    'same_net_namespace': current['net_namespace'] == baseline['net_namespace'],
    'readonly_library_mount': bool(os.statvfs('/usr/lib/x86_64-linux-gnu').f_flag & os.ST_RDONLY),
    'readonly_bin_mount': bool(os.statvfs('/usr/bin').f_flag & os.ST_RDONLY),
    'binary_hashes_match_verified_packages': actual == expected,
    'seccomp_mode_preserved': current['status']['Seccomp'] == baseline['status']['Seccomp'],
    'seccomp_filter_count_not_reduced': int(current['status'].get('Seccomp_filters', '0')) >= int(baseline['status'].get('Seccomp_filters', '0')),
    'no_new_privileges_not_reduced': int(current['status']['NoNewPrivs']) >= int(baseline['status']['NoNewPrivs']),
    'no_new_privileges_enabled_in_bwrap': current['status']['NoNewPrivs'] == '1',
    'effective_capabilities_not_added': int(current['status']['CapEff'], 16) & ~int(baseline['status']['CapEff'], 16) == 0,
    'capability_bounding_set_not_expanded': int(current['status']['CapBnd'], 16) & ~int(baseline['status']['CapBnd'], 16) == 0,
    'sandbox_disable_env_absent': 'WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS' not in os.environ,
    'nested_bwrap_completed': nested.returncode == 0,
}
result = {'status': 'PASS' if all(checks.values()) else 'FAIL',
          'outer_baseline': baseline, 'inside_overlay': current, 'checks': checks,
          'private_dev': {'filesystem_types': dev_filesystems, 'entropy_bytes_read': entropy_bytes_read, 'entropy_bytes_saved': False, 'entries': sorted(p.name for p in Path('/dev').iterdir())},
          'existing_x11_file': x11_file,
          'binaries': actual, 'nested_bwrap': {'returncode': nested.returncode, 'stderr': nested.stderr},
          'scope': 'CLI read-only overlay and ordinary nested bwrap only. Outer Seccomp=0 remains 0; it is not evidence that WebKit sandboxing is enabled.',
          'gui_started': False, 'webkit_process_started': False, 'webkit_sandbox': 'NOT_RUN'}
print(json.dumps(result, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
