#!/bin/bash
set -eu
export LP_PREFLIGHT_BASELINE_JSON="$(/usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r9/audit_readonly.py --baseline)"
export LP_PREFLIGHT_X11_IDENTITY_JSON="$(/usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/webkit-x11-identity-r8/inspect_identity.py)"
exec /usr/bin/bwrap --unshare-user --unshare-pid --ro-bind / / --proc /proc --dev /dev --die-with-parent \
 --ro-bind /dev/shm/codex-orbit-desktop/Xauthority /dev/shm/codex-orbit-desktop/Xauthority \
 --overlay-src /usr/lib/x86_64-linux-gnu \
 --overlay-src <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r4/layer/lib \
 --ro-overlay /usr/lib/x86_64-linux-gnu \
 --overlay-src /usr/bin \
 --overlay-src <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r4/layer/bin \
 --ro-overlay /usr/bin \
 -- /usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r9/audit_readonly.py
