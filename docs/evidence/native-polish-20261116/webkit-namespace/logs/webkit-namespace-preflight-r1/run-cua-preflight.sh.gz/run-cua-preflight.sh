#!/bin/bash
set -eu
export LP_PREFLIGHT_EXPECT_NET
LP_PREFLIGHT_EXPECT_NET=$(readlink /proc/self/ns/net)
exec /usr/bin/bwrap --unshare-user --unshare-pid --ro-bind / / --proc /proc --die-with-parent \
 --overlay-src /usr/lib/x86_64-linux-gnu \
 --overlay-src <WORKSPACE>/validation/linux-20261116/desktop/toolchain/sysroot/usr/lib/x86_64-linux-gnu \
 --ro-overlay /usr/lib/x86_64-linux-gnu \
 --overlay-src /usr/bin \
 --overlay-src <WORKSPACE>/validation/linux-20261116/desktop/toolchain/sysroot/usr/bin \
 --ro-overlay /usr/bin \
 -- /usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/webkit-namespace-preflight-r1/audit_readonly.py
