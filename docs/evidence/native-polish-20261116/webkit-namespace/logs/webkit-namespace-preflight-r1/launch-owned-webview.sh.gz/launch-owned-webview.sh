#!/bin/bash
# Validation-only launch; the caller owns CUA and must supply the reviewed candidate and marked root.
set -eu
if [ "$#" -ne 2 ]; then
  printf '%s\n' 'usage: launch-owned-webview.sh ABSOLUTE_CANDIDATE_EXECUTABLE ABSOLUTE_MARKED_TEST_ROOT' >&2
  exit 2
fi
LP_WEBKIT_CANDIDATE="$1"
LP_WEBKIT_TEST_ROOT="$2"
case "$LP_WEBKIT_CANDIDATE" in /*) ;; *) printf '%s\n' 'Candidate path must be absolute' >&2; exit 2 ;; esac
case "$LP_WEBKIT_TEST_ROOT" in /*) ;; *) printf '%s\n' 'Test root must be absolute' >&2; exit 2 ;; esac
[ -x "$LP_WEBKIT_CANDIDATE" ] || { printf '%s\n' 'Reviewed candidate is not executable' >&2; exit 2; }
[ -f "$LP_WEBKIT_TEST_ROOT/test-owner.json" ] || { printf '%s\n' 'Prepare a private marked test root first; the APP validates its identity' >&2; exit 2; }
if [ "${WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS+x}" = x ]; then
  printf '%s\n' 'Refusing inherited WebKit sandbox-disable environment' >&2
  exit 2
fi
mkdir -p "$LP_WEBKIT_TEST_ROOT/tmp" "$LP_WEBKIT_TEST_ROOT/runtime"
chmod 700 "$LP_WEBKIT_TEST_ROOT/tmp" "$LP_WEBKIT_TEST_ROOT/runtime"
exec /usr/bin/bwrap --unshare-user --unshare-pid --ro-bind / / --proc /proc --die-with-parent \
 --overlay-src /usr/lib/x86_64-linux-gnu \
 --overlay-src <WORKSPACE>/validation/linux-20261116/desktop/toolchain/sysroot/usr/lib/x86_64-linux-gnu \
 --ro-overlay /usr/lib/x86_64-linux-gnu \
 --overlay-src /usr/bin \
 --overlay-src <WORKSPACE>/validation/linux-20261116/desktop/toolchain/sysroot/usr/bin \
 --ro-overlay /usr/bin \
 --bind "$LP_WEBKIT_TEST_ROOT" "$LP_WEBKIT_TEST_ROOT" \
 --setenv LP_INSTALL_TEST_ROOT "$LP_WEBKIT_TEST_ROOT" \
 --setenv TMPDIR "$LP_WEBKIT_TEST_ROOT/tmp" \
 --setenv XDG_RUNTIME_DIR "$LP_WEBKIT_TEST_ROOT/runtime" \
 -- "$LP_WEBKIT_CANDIDATE"
