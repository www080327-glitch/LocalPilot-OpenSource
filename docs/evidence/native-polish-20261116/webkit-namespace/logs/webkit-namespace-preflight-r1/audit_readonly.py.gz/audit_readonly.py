from pathlib import Path
import hashlib,json,os,subprocess
paths=['/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/WebKitNetworkProcess','/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/WebKitWebProcess','/usr/bin/xdg-dbus-proxy','/usr/bin/bwrap']
status={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in Path('/proc/self/status').read_text().splitlines() if line.startswith(('NoNewPrivs:','Seccomp:','CapEff:'))}
net=os.readlink('/proc/self/ns/net')
nested=subprocess.run(['/usr/bin/bwrap','--unshare-user','--unshare-pid','--ro-bind','/','/','--proc','/proc','--die-with-parent','--','/usr/bin/true'],capture_output=True,text=True,timeout=5)
result={'status':status,'net_namespace':net,'same_net_namespace':net==os.environ['LP_PREFLIGHT_EXPECT_NET'],'readonly_mounts':{p:bool(os.statvfs(p).f_flag & os.ST_RDONLY) for p in ('/usr/bin','/usr/lib/x86_64-linux-gnu')},'binaries':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},'nested_bwrap':{'returncode':nested.returncode,'stderr':nested.stderr},'webkit_sandbox_disable_env_present':'WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS' in os.environ,'gui_started':False,'webkit_process_started':False}
print(json.dumps(result,indent=2))
assert result['same_net_namespace']
assert all(result['readonly_mounts'].values())
assert result['status']['NoNewPrivs']=='1'
assert result['status']['Seccomp']=='2'
assert not result['webkit_sandbox_disable_env_present']
assert nested.returncode==0
