#!/bin/bash
set -eu
source <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
bash <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r7/run-preflight.sh > <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r7/cua-preflight.log 2>&1
exec /usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/native-r7-a.py
