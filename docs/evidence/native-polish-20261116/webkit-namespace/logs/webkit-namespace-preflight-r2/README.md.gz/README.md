# WebKit readonly namespace preflight

2026-11-16. This is validation tooling only. No production source, host `/usr`, binary bytes, kernel policy or network permissions were changed. No GUI or WebKit subprocess was started by these checks.

## Result

Both the shell executor and the real CUA terminal pass the r2 CLI preflight. Bubblewrap 0.12.0 can mount the existing verified Debian sysroot over the compiled WebKit paths using read-only unions of:

- host `/usr/lib/x86_64-linux-gnu` + sysroot `usr/lib/x86_64-linux-gnu`;
- host `/usr/bin` + sysroot `usr/bin`.

A standard private PID namespace with a fresh `/proc` permits a second ordinary unprivileged bubblewrap to execute `/usr/bin/true`. Neither layer disables user namespaces or WebKit sandboxing. This only proves that nested bubblewrap is available; actual WebKit child sandboxing remains **NOT_RUN** until the final candidate is started and its real child processes are inspected.

CUA outer/inner values are identical: effective/bounding capabilities zero, NoNewPrivs=1, Seccomp=0 with zero filters, and the same existing network namespace. The executor separately has Seccomp=2 with one filter, preserved inside its overlay. The CUA's original Seccomp=0 is recorded honestly and is **not** evidence that WebKit sandboxing is enabled. Every mounted `/usr/bin` and library union was checked read-only. No sandbox-disable environment variable was present.

The mapped WebKitNetworkProcess, WebKitWebProcess and xdg-dbus-proxy have no unresolved shared libraries even with LD_LIBRARY_PATH removed for the dependency check. The real helpers and proxy match their corresponding Debian archive members byte for byte; archive SHA-256 values match the pre-existing package manifest. Host bubblewrap and sysroot bubblewrap are also byte-identical.

## Preserved failures

1. Direct readonly bind to the absent compiled helper directory failed with `Read-only file system`; no host directory was created.
2. A readonly-root wrapper without a fresh private `/proc` prevented nested bubblewrap from writing its own UID map. Adding standard `--unshare-pid --proc /proc` resolved this without changing a host policy.
3. r1 CUA preflight incorrectly assumed that CUA inherited the executor's Seccomp=2. All filesystem/hash/network/nesting checks passed but that hardcoded assertion failed. The original `r1/cua-preflight.log` and script remain untouched. r2 records the real outer baseline before creating the namespace and checks preservation instead.

## Handoff

`../wk-r2.sh` is the CLI-only preflight, used in both environments. `../webkit-namespace-preflight-r1/launch-owned-webview.sh` is prepared and shell-syntax checked, but has **not** been executed. It takes the final reviewed candidate executable and a private marked LP_INSTALL_TEST_ROOT as two absolute arguments.

The launch script keeps the root filesystem and sysroot unions read-only, binds only the explicitly provided test root writable, and puts TMPDIR and XDG_RUNTIME_DIR under that root. HOME, XDG_DATA_HOME and XDG_CACHE_HOME are not redirected per profile, so they cannot silently create the A/B persistent storage separation that the product must demonstrate. It refuses an inherited WebKit sandbox-disable variable. It retains the caller's existing network namespace; there are no network namespace expansion or policy flags.

Wait for the final package. Use a fresh marked owned A/B test root and the newly extracted verified binary, not the earlier RC.9 package. The root agent owns CUA and GUI launch. Record actual WebKit child process identity, nested namespace and sandbox state before reporting normal sandboxed native behavior. An image of a window alone is insufficient. Any WebKit sandbox or resource error must remain a failure; do not disable the sandbox or patch a binary to turn it green.

This environment is a namespaced validation process, **not a system DEB installation**. It cannot establish apt dependency installation, desktop launcher integration, ordinary system service lifetime, upgrade rollback or complete daily operation. The private PID namespace also differs from an ordinary installed app environment.

## Docker and Harbor

The read-only executor inspection found no Docker client, dockerd, rootlesskit, containerd, podman/nerdctl, networking helpers, fuse-overlayfs or uid/gid-map helpers on PATH; no configured DOCKER_HOST/CONTEXT; no daemon process or standard Docker socket. Subuid/subgid mappings exist for the user, but do not supply a rootless runtime. No existing executable Docker/rootless materials were found in the scoped validation inventory. The precise scope and values are retained in r1/docker-rootless-readonly.json. No daemon was installed, downloaded or started. Harbor has no usable Docker execution endpoint in this checked environment.

## Files

Exact help, shipped overlay manual, package/archive-member hashes, dependency outputs, failed and successful namespace invocations, CUA/error logs, and the launch script are retained under r1 and r2. SHA-256 inventory is in PREFLIGHT_SHA256.json; scripts are validation artifacts, not product wrappers.
