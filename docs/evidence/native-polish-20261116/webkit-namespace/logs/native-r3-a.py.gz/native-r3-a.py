import json,os,subprocess,time
from pathlib import Path
out=Path('<WORKSPACE>/validation/polish-20261116/desktop')
command=['bash',str(out/'webkit-namespace-preflight-r1/launch-owned-webview.sh'),str(out/'native-final-r2-extracted/usr/bin/localpilot-desktop-test'),str(out/'native-final-profile-a')]
record={'command':command,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'display':os.environ.get('DISPLAY'),'xdg_session_type':os.environ.get('XDG_SESSION_TYPE'),'webkit_disable_sandbox_present':'WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS' in os.environ}
with (out/'native-final-r3-a.log').open('x') as log:
 p=subprocess.Popen(command,stdout=log,stderr=log)
 record['pid']=p.pid
 (out/'native-final-r3-a-process.json').write_text(json.dumps(record,indent=2))
 record['returncode']=p.wait()
 record['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (out/'native-final-r3-a-process.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
