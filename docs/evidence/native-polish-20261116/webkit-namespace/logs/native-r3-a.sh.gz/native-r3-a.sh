#!/bin/bash
set -eu
source <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
exec /usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/native-r3-a.py
