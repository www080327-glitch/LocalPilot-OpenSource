import json,os,socket,stat
from pathlib import Path
raw=os.environ.get('XAUTHORITY')
path=Path(raw) if raw else Path.home()/'.Xauthority'
record={'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups(),'hostname':socket.gethostname(),'DISPLAY':os.environ.get('DISPLAY'),'XAUTHORITY_env':raw,'xauthority_selected_path':str(path),'selection':'XAUTHORITY' if raw else 'HOME default','cookie_contents_read':False,'authentication_policy_changed':False}
try:
 s=path.stat()
 record['file']={'exists':True,'resolved_path':str(path.resolve()),'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'device':s.st_dev,'inode':s.st_ino,'regular_file':stat.S_ISREG(s.st_mode),'access_readable':os.access(path,os.R_OK)}
 try:
  fd=os.open(path,os.O_RDONLY)
  os.close(fd)
  record['file']['open_readonly_succeeded']=True
 except OSError as error:
  record['file']['open_readonly_succeeded']=False
  record['file']['open_errno']=error.errno
except OSError as error:
 record['file']={'exists':False,'stat_errno':error.errno,'error_class':type(error).__name__}
print(json.dumps(record,indent=2))
