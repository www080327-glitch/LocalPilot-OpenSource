#!/bin/bash
set -eu
source <WORKSPACE>/validation/linux-20261116/desktop/toolchain/environment.sh
/usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/webkit-x11-identity-r8/inspect_identity.py > <WORKSPACE>/validation/polish-20261116/desktop/webkit-x11-identity-r8/outer.json
/usr/bin/bwrap --unshare-user --unshare-pid --ro-bind / / --proc /proc --dev /dev --die-with-parent \
 --overlay-src /usr/lib/x86_64-linux-gnu \
 --overlay-src <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r4/layer/lib \
 --ro-overlay /usr/lib/x86_64-linux-gnu \
 --overlay-src /usr/bin \
 --overlay-src <WORKSPACE>/validation/polish-20261116/desktop/webkit-minimal-overlay-r4/layer/bin \
 --ro-overlay /usr/bin \
 --setenv LP_INSTALL_TEST_ROOT <WORKSPACE>/validation/polish-20261116/desktop/native-final-profile-a \
 --setenv TMPDIR <WORKSPACE>/validation/polish-20261116/desktop/native-final-profile-a/tmp \
 --setenv XDG_RUNTIME_DIR <WORKSPACE>/validation/polish-20261116/desktop/native-final-profile-a/runtime \
 -- /usr/bin/python3 <WORKSPACE>/validation/polish-20261116/desktop/webkit-x11-identity-r8/inspect_identity.py > <WORKSPACE>/validation/polish-20261116/desktop/webkit-x11-identity-r8/namespace.json
