"""Run Suite source tests with an explicit import path ahead of editable installs."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

receipt = Path(__file__).resolve().parent
base = receipt.parents[1]
source = base/'rc20-work'
commit = subprocess.check_output(['git','rev-parse','HEAD'], cwd=source, text=True).strip()
assert commit=='8eb042cf57508de59179b4aa2fdd5ae41e9a9eec', commit
assert not subprocess.check_output(['git','status','--porcelain'], cwd=source, text=True)
python = str(base/'LocalPilot/.venv/bin/python')
env = dict(os.environ, PYTHONPATH=os.pathsep.join(map(str, (source, source/'suite', source/'companion'))))
probe = subprocess.check_output([python, '-B', '-c', 'import agent, localpilot_suite.upgrades, companion; '
    'print(agent.__file__); print(localpilot_suite.upgrades.__file__); print(companion.__file__)'],
    cwd=source, env=env, text=True).splitlines()
assert len(probe) == 3 and all(Path(path).resolve().is_relative_to(source) for path in probe), probe
command = [python,'-B','-m','unittest','discover','-s','suite/tests','-p','test_*.py','-v']
log = receipt/'suite-full-final-r3.log'
start = time.monotonic()
with log.open('x') as output:
    result = subprocess.run(command, cwd=source, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=900)
lines = log.read_text().splitlines()
record = {'source_commit':commit, 'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],
           cwd=source, text=True).strip(), 'import_provenance':probe, 'pythonpath':env['PYTHONPATH'],
          'command':command, 'exit_code':result.returncode, 'elapsed_seconds':round(time.monotonic()-start, 2),
          'log':log.name, 'log_sha256':hashlib.file_digest(log.open('rb'),'sha256').hexdigest(), 'footer':lines[-5:]}
(receipt/'SUITE_FINAL_R3.json').write_text(json.dumps(record, indent=2)+'\n')
print(record)
raise SystemExit(result.returncode)
