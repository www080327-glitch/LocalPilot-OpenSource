"""Exercise a reviewed RC20/RC18/RC20 wheel switch on stopped synthetic history."""
import importlib.util
import json
from pathlib import Path
import shutil
import sqlite3
import zipfile

spec = importlib.util.spec_from_file_location('acceptance', Path(__file__).with_name('run_acceptance.py'))
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def read_log(name):
    return json.loads((a.ROOT/f'{name}.log').read_text())


def read_state(database):
    with sqlite3.connect(database.as_uri() + '?mode=ro', uri=True) as db:
        return db.execute('PRAGMA user_version').fetchone()[0], db.execute(
            'SELECT session_id,revision,point,sha256,at FROM journal ORDER BY session_id,revision').fetchall()


def main():
    case = a.ROOT/'packaged-rollback'
    case.mkdir(mode=0o700)
    runtime = case/'runtime'
    shutil.copytree(a.RUNTIME, runtime, symlinks=True)
    python = runtime/'bin/python'
    home = case/'home'
    home.mkdir(mode=0o700)
    data = home/'data'
    data.mkdir(mode=0o700)
    database = data/'runtime.sqlite3'
    config = home/'service.json'
    config.write_text(json.dumps({'data_dir':str(data)})+'\n')
    config.chmod(0o600)
    original = a.ROOT.parents[1]/'rc20-runtime/check_rollback.py'
    fixture = case/'check_rollback.py'
    harness = a.ROOT/'installed-harness'
    src = original.read_text()
    src = src.replace('from agent.engine_v5 import EngineV5Policy',
                      f'sys.path.insert(0, {str(harness)!r})\n\nfrom agent.engine_v5 import EngineV5Policy')
    # Leave the first writer's on-disk format at 4 so the actual Suite plan must use the exporter.
    assert src.count('service.suspend()') == 1
    src = src.replace('service.suspend()', "if phase == 'candidate-create':\n    service.store.close()\nelse:\n    service.suspend()")
    src = src.replace("assert summary['schema_after_normal_stop'] == 3",
                      "assert summary['schema_after_normal_stop'] == (4 if phase == 'candidate-create' else 3)")
    src = src.replace("summary['schema_after_normal_stop']", "summary['schema_after_writer_exit']")
    fixture.write_text(src)
    packaged_wheels = a.RUNTIME.parent/'wheels'
    new, = packaged_wheels.glob('localpilot_agent_service-5.0.0b37-*.whl')
    old, = (a.ROOT/'legacy-wheels').glob('localpilot_agent_service-5.0.0b35-*.whl')
    hashes = json.loads((a.ROOT/'EXTRACTED_SOURCE_CHECK.json').read_text())['verification']['wheel_hashes']
    assert a.digest(new) == hashes[new.name]
    assert a.digest(old) == json.loads((a.ROOT/'LEGACY_WHEEL.json').read_text())['sha256']
    cli = [python, '-I', '-B', '-m', 'localpilot_suite.cli', '--home', home, '--json', 'upgrade', 'core']
    def phase(name, distribution):
        a.run(f'roundtrip-{name}', [python, '-I', '-B', fixture, name, data], cwd=case)
        observed = read_log(f'roundtrip-{name}')
        path = Path(observed['source'])
        assert path.resolve().is_relative_to(runtime), path
        with zipfile.ZipFile(distribution) as wheel:
            assert path.read_bytes() == wheel.read('agent/persistence.py')
        return observed
    def review(name, target, previous):
        a.run(name, [*cli, '--wheel', target, '--previous-wheel', previous], cwd=case)
        report = read_log(name)
        assert report['status'] == 'plan_only' and report['blocking_services'] == []
        assert report['runtime_versions']['localpilot-suite'] == '0.2.0b36'
        assert report['components'][0]['target']['sha256'] == a.digest(target)
        assert report['components'][0]['rollback']['sha256'] == a.digest(previous)
        return report
    def execute(name, review):
        a.run(name, [*cli, '--plan', review['id'], '--fingerprint', review['fingerprint'], '--execute'], cwd=case)
        result = read_log(name)
        assert result['status'] == 'completed' and result['data_preserved'] and not result['automatic_task_replay']
        assert result['verification'] == 'versions_imports_dependencies_passed'
        return result
    first = phase('candidate-create', new)
    schema, pre_journal = read_state(database)
    assert schema == 4 and first['task_count'] == 4
    downgrade_plan = review('roundtrip-downgrade-plan', old, new)
    assert downgrade_plan['runtime_storage']['schema'] == 4
    assert downgrade_plan['runtime_storage']['compatibility'] == 'materialize_before_switch'
    assert read_state(database) == (schema, pre_journal)
    downgrade = execute('roundtrip-downgrade-execute', downgrade_plan)
    conversion = downgrade['runtime_storage']
    assert (conversion['schema_before'], conversion['schema_after'], conversion['sessions']) == (4, 3, 1)
    assert conversion['materialized']
    schema, converted_journal = read_state(database)
    assert schema == 3 and converted_journal[:-1] == pre_journal and converted_journal[-1][2] == 'legacy_materialized'
    second = phase('rc18-write', old)
    assert second['schema'] == second['schema_after_writer_exit'] == 3 and second['task_count'] == 7
    assert second['session_id'] == first['session_id']
    assert second['task_hashes'][:first['task_count']] == first['task_hashes']
    assert second['segment_hashes'][:first['segments']] == first['segment_hashes']
    restore_plan = review('roundtrip-reupgrade-plan', new, old)
    assert restore_plan['runtime_storage']['schema'] == 3
    restore = execute('roundtrip-reupgrade-execute', restore_plan)
    assert restore['runtime_storage']['schema'] == 3
    third = phase('candidate-reopen', new)
    final_schema, final_journal = read_state(database)
    assert third['schema'] == 4 and final_schema == third['schema_after_writer_exit'] == 3
    assert third['task_count'] == 8 and third['session_id'] == first['session_id']
    assert third['task_hashes'][:second['task_count']] == second['task_hashes']
    assert third['segment_hashes'][:second['segments']] == second['segment_hashes']
    assert final_journal[:len(converted_journal)] == converted_journal
    a.receipt('PACKAGED_ROLLBACK', {'status':'PASS', 'source_commit':a.COMMIT, 'source_tree':a.TREE,
        'legacy_commit':'fe9765c69ce8a39e8a3682d61ceb67c86894c3b4',
        'original_fixture_sha256':a.digest(original), 'adapted_fixture_sha256':a.digest(fixture),
        'wheel_hashes':{wheel.name:a.digest(wheel) for wheel in (new,old)},
        'active_schema':first['schema'], 'conversion':conversion, 'final_stop_schema':final_schema,
        'original_journal_rows_preserved':len(pre_journal), 'task_counts':[4,7,8],
        'legacy_segments_after_reupgrade':third['segments'], 'task_snapshots_and_segments_preserved':True,
        'installed_product_paths': [row['source'] for row in (first,second,third)],
        'system_installation':False, 'data':'Independent extracted runtime copy and synthetic scripted-provider fixture'})


if __name__ == '__main__':
    main()
