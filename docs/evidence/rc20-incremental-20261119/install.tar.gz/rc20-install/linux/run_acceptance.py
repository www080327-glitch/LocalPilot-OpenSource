"""Run the existing Linux Test build and native acceptance against the RC20 freeze."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'final-source'
PREVIOUS = ROOT.parents[1] / 'install/linux'
COMMIT = '8eb042cf57508de59179b4aa2fdd5ae41e9a9eec'
TREE = '853f2dece1506f00e462be8b033ec12fcc892dab'
MODULES = {'suite': '0.2.0b36', 'localpilot-agent-service': '5.0.0b37',
           'localpilot-companion': '0.5.7b12', 'localpilot-channels': '0.1.0a4'}
ARTIFACT = 'LocalPilot-Test-5.0.1-rc.20-linux-x86_64.deb'
RUNTIME = ROOT / 'extracted-rc20/usr/lib/LocalPilot Test/bundled-backends/runtime'

spec = importlib.util.spec_from_file_location('native_environment', PREVIOUS / 'native_environment.py')
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
ENV = dict(native.environment(), PYTHONNOUSERSITE='1')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def receipt(name, value):
    with (ROOT / f'{name}.json').open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


def run(name, command, cwd=SOURCE, env=ENV, timeout=600):
    command = list(map(str, command))
    log = ROOT / f'{name}.log'
    start = time.monotonic()
    print(f'Starting {name}', flush=True)
    with log.open('x') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output,
                                stderr=subprocess.STDOUT, timeout=timeout)
    record = {'name': name, 'command': command, 'cwd': str(cwd), 'exit_code': result.returncode,
              'seconds': round(time.monotonic() - start, 2), 'log_sha256': digest(log)}
    receipt(name, record)
    result.check_returncode()
    return record


def source_identity():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=SOURCE).decode()
    assert git('rev-parse', 'HEAD').strip() == COMMIT
    assert git('rev-parse', 'HEAD^{tree}').strip() == TREE
    assert not git('status', '--porcelain')
    files = {file: digest(SOURCE / file) for file in git('ls-files', '-z').split('\0') if file}
    return {'git_commit': COMMIT, 'git_tree': TREE, 'tracked_file_count': len(files), 'files': files}


def prepare():
    receipt('FINAL_SOURCE', source_identity())
    wheels = ROOT / 'wheels'
    wheels.mkdir()
    build_python = PREVIOUS.parent / 'build-env/bin/python'
    for component, directory in (('core', '.'), ('companion', 'companion'), ('suite', 'suite')):
        run(f'wheel-{component}', [build_python, '-m', 'build', '--wheel', '--no-isolation',
                                  '--outdir', wheels, directory])
    run('wheel-channels', [build_python, 'scripts/build_channels_wheel.py', '--no-isolation',
                           '--out', wheels])
    receipt('PRODUCT_WHEELS', {wheel.name: digest(wheel) for wheel in sorted(wheels.glob('*.whl'))})
    run('prepare', ['/usr/bin/python3', 'scripts/linux_backends.py', 'prepare', '--python',
                    '/usr/bin/python3', '--wheels', wheels, '--dependencies', PREVIOUS/'dependencies',
                    '--dependency-lock', SOURCE/'desktop/runtime-dependencies-linux-x86_64-py313.json',
                    '--channel-runtime', PREVIOUS/'node-v22.23.4-linux-x64.tar.gz'], SOURCE/'desktop')
    run('npm-ci', ['npm', 'ci'], SOURCE/'desktop')


def build():
    run('native-build', ['npm', 'run', 'release:linux'], SOURCE/'desktop', timeout=1800)


def package_checks():
    artifact, = (SOURCE/'desktop/release/linux-test-v5.0.1-rc.20').glob(f'*/{ARTIFACT}')
    report = json.loads((artifact.parent/'RESULTS.json').read_text())
    assert report['git_commit'] == COMMIT and not report['source_dirty']
    assert report['sha256'] == digest(artifact) and report['bytes'] == artifact.stat().st_size
    self_check = report['bundle_self_check']
    assert self_check['bundle_id'] == 'io.localpilot.desktop.test'
    assert self_check['version'] == '5.0.1-rc.20' and self_check['modules'] == MODULES
    assert self_check['verified_wheels'] == 40
    assert not self_check['services_started'] and not self_check['user_data_opened']
    assert report['extracted_runtime']['pip_check'] == 'No broken requirements found.'
    assert report['extracted_runtime']['module_versions'] == MODULES
    receipt('PACKAGE_VERIFICATION', dict(report, local_artifact=str(artifact)))
    run('deb-extract', ['dpkg-deb', '-x', artifact, ROOT/'extracted-rc20'])
    verification = run('extracted-runtime-check', ['/usr/bin/python3', 'desktop/scripts/linux_backends.py',
                                                  'check', '--output', RUNTIME.parent])
    details = json.loads((ROOT/'extracted-runtime-check.log').read_text())
    assert details['passed'] and details['actual_module_versions'] == MODULES
    assert len(details['wheel_hashes']) == 40
    receipt('EXTRACTED_SOURCE_CHECK', dict(verification, source_commit=COMMIT, verification=details))


def installed_python_tests():
    harness = ROOT/'installed-harness'
    shutil.copytree(PREVIOUS/'installed-harness', harness, ignore=shutil.ignore_patterns('__pycache__'))
    template = harness/'run_installed.py'
    template.write_text(template.read_text().replace('02838a5db0b342647fc0f7904738bee87f167cf0', COMMIT))
    previous_manifest = json.loads((PREVIOUS/'INSTALLED_HARNESS_SOURCE.json').read_text())
    test_files = {}
    for file in previous_manifest['test_files']:
        src = SOURCE/(file if file.startswith('tests/') else f'companion/tests/{file}')
        assert digest(harness/file) == digest(src), file
        test_files[file] = digest(src)
    receipt('INSTALLED_HARNESS_SOURCE', {'source_commit': COMMIT, 'test_files': test_files,
                                         'product_source_copied': False})
    run('packaged-runtime-tests', [RUNTIME/'bin/python', '-I', '-B', template], cwd=ROOT)


def native_tests():
    checks = [
        ('rust-default', ['--', '--test-threads=1']),
        ('rust-core-recovery', ['real_core_recovery_and_identity', '--', '--ignored', '--exact',
                                'tests::real_core_recovery_and_identity', '--test-threads=1', '--nocapture']),
        ('rust-offline-release', ['offline_release_failure_is_unknown', '--', '--ignored',
                                  '--test-threads=1', '--nocapture']),
    ]
    env = dict(ENV, LP_GUI_TEST_PYTHON=str(RUNTIME/'bin/python'))
    evidence = ROOT/'offline-release'
    evidence.mkdir()
    unavailable = 'http://127.0.0.1:1'
    offline = dict(env, LP_OFFLINE_PROBE='1', LP_MAINTENANCE_EVIDENCE=str(evidence),
                   HTTP_PROXY=unavailable, HTTPS_PROXY=unavailable, ALL_PROXY=unavailable,
                   http_proxy=unavailable, https_proxy=unavailable, all_proxy=unavailable,
                   NO_PROXY='', no_proxy='')
    for name, args in checks:
        run(name, ['cargo', 'test', '--release', '--locked', '--manifest-path',
                   'desktop/src-tauri/Cargo.toml', *args],
            env=offline if name == 'rust-offline-release' else env, timeout=1200)
    current = source_identity()
    assert current == json.loads((ROOT/'FINAL_SOURCE.json').read_text())
    receipt('FINAL_SOURCE_POSTRUN', {key: value for key, value in current.items() if key != 'files'})


def final_receipt():
    def read(name):
        return json.loads((ROOT/f'{name}.json').read_text())
    package = read('PACKAGE_VERIFICATION')
    artifact = Path(package['local_artifact'])
    assert package['sha256'] == digest(artifact) and package['bytes'] == artifact.stat().st_size
    source = read('FINAL_SOURCE_POSTRUN')
    wheel_hashes = read('EXTRACTED_SOURCE_CHECK')['verification']['wheel_hashes']
    prepared = read('PRODUCT_WHEELS')
    assert all(wheel_hashes[name] == checksum for name, checksum in prepared.items())
    code = read('EXTRACTED_SOURCE_CHECK')['verification']['verified_code']
    installed = read('PACKAGED_RUNTIME_TESTS')
    assert installed['isolated'] and installed['passed'] == installed['run'] == 27
    assert all((RUNTIME/path).is_file() for path in installed['module_locations'].values())
    rust = {}
    for name, expected in (('rust-default', (63, 0, 3, 0, 0)),
                           ('rust-core-recovery', (1, 0, 0, 0, 65)),
                           ('rust-offline-release', (1, 0, 0, 0, 65))):
        line = re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',
                         (ROOT/f'{name}.log').read_text())
        results = tuple(map(int, line.groups()))
        assert results == expected, (name, results)
        rust[name] = dict(zip(('passed','failed','ignored','measured','filtered'), results))
    rollback = read('PACKAGED_ROLLBACK')
    assert rollback['status'] == 'PASS'
    receipt('INSTALL_FINAL_RESULTS', {
        'status':'PASS', 'source_commit':COMMIT, 'source_tree':TREE,
        'tracked_files_unchanged':source['tracked_file_count'],
        'artifact':{key:package[key] for key in ('artifact','local_artifact','sha256','bytes')},
        'package':package['package'], 'bundle_id':package['bundle_self_check']['bundle_id'],
        'module_versions':MODULES, 'wheel_count':len(wheel_hashes),
        'verified_product_code':code, 'source_files_verified':sum(item['source_files'] for item in code.values()),
        'pip_check':package['extracted_runtime']['pip_check'], 'node':package['extracted_runtime']['node'],
        'packaged_python':{key:installed[key] for key in ('python','isolated','run','passed','failures','errors','skips')},
        'product_modules_loaded_from_extracted_runtime':len(installed['module_locations']),
        'native_checks':rust, 'packaged_rollback':'PACKAGED_ROLLBACK.json',
        'system_installed':False, 'physical_native_gui':'NOT_RUN_RC20',
        'prior_gui_blocker_receipt':'../../install/linux/NATIVE_GUI_LAUNCH.json',
        'test_only_commit_equivalence':'../PACKAGE_SOURCE_EQUIVALENCE.json',
    })


if __name__ == '__main__':
    operations = {'prepare': prepare, 'build': build, 'package-checks': package_checks,
                  'python-tests': installed_python_tests, 'native-tests': native_tests,
                  'report': final_receipt}
    for stage in sys.argv[1:]:
        operations[stage]()
