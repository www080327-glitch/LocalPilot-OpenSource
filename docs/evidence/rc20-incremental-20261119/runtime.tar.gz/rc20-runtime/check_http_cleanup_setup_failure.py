"""Drive unittest's real failed-setup cleanup against the real HTTP fixture."""
import json
from unittest import TestResult
from unittest.mock import patch

from tests.test_plugin_http import HTTPTests, PluginManager


def main():
    case = HTTPTests('test_json_sse_session_and_protocol_headers')
    original_discover = PluginManager.discover
    failed_setup = 'intentional setup failure after real loopback plugin discovery'

    def fail_after_discovery(manager, *args, **kwargs):
        original_discover(manager, *args, **kwargs)
        raise RuntimeError(failed_setup)

    result = TestResult()
    with patch.object(PluginManager, 'discover', fail_after_discovery):
        case.run(result)

    worker_exited = not case.thread.is_alive()
    socket_closed = case.http.socket.fileno() == -1
    temp_removed = not case.root.exists()
    assert result.testsRun == 1
    assert len(result.errors) == 1 and failed_setup in result.errors[0][1], result.errors
    assert worker_exited and socket_closed and temp_removed
    print(json.dumps({
        'injected_error_observed': True,
        'loopback_discovery_completed_before_injection': True,
        'test_body_run': False,
        'server_thread_exited': worker_exited,
        'server_socket_closed': socket_closed,
        'fixture_temp_directory_removed': temp_removed,
        'status': 'PASS',
    }, indent=2))


if __name__ == '__main__':
    main()
