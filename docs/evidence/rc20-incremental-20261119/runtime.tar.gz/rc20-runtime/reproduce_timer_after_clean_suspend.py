"""Observe a real TaskService Timer waiting for the service condition during suspend."""
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import time
import traceback

from agent.persistence import PersistenceError, unpack
from agent.registry import create_default_registry
from agent.retry import RetryPolicy
from agent.session import AgentSession
from localpilot_api.service import TaskRequest, TaskService
from tests.test_runtime_api import Backend, answer, call


def waiting_in_cancel(timer):
    frame = sys._current_frames().get(timer.ident)
    stack = []
    while frame is not None:
        stack.append(frame.f_code)
        frame = frame.f_back
    return (threading.Condition.__enter__.__code__ in stack
            and TaskService.cancel.__code__ in stack)


def read_durable_state(path):
    with sqlite3.connect(path) as database:
        rows = database.execute('SELECT payload FROM checkpoints').fetchall()
        assert len(rows) == 1
        payload = json.loads(rows[0][0])
        journal = database.execute('SELECT point FROM journal ORDER BY rowid').fetchall()
        version = database.execute('PRAGMA user_version').fetchone()[0]
        return payload['tasks'][0], [item[0] for item in journal], version


def main():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        workspace = root / 'workspace'
        workspace.mkdir()
        path = root / 'runtime.db'
        target = workspace / 'requires-approval.txt'
        backend = Backend(answer(None, call('apply_patch', {'changes': [
            {'path': target.name, 'operation': 'create', 'content': 'approval required'},
        ]}, 'write-once')))

        def factory(callback):
            return AgentSession(create_default_registry(workspace, permission_mode='approve-mutations'),
                                backend=backend, policy='cloud-only', streaming=False,
                                event_callback=callback, retry_policy=RetryPolicy(max_attempts=1))

        service = TaskService({'localpilot': factory}, persistence=path)
        task_id = service.create_task(TaskRequest('Propose one change', timeout_seconds=3))['id']
        yielded = service.wait(task_id)
        assert yielded['status'] == 'requires_approval', yielded['status']
        task = service.tasks[task_id]
        assert task.timer is not None
        timer = task.timer
        errors = []
        original_hook = threading.excepthook

        def observe_error(args):
            if args.thread is timer:
                errors.append(args)
            else:
                original_hook(args)

        threading.excepthook = observe_error
        try:
            with service.condition:
                wait_until = time.monotonic() + 10
                while not waiting_in_cancel(timer) and time.monotonic() < wait_until:
                    time.sleep(0.005)
                assert waiting_in_cancel(timer), 'Timer did not enter cancel and wait on condition'
                assert task.status == 'requires_approval' and not task.executing
                receipt = service.suspend()
                assert receipt == {'status': 'ok', 'quiescent': True}
                assert service.closed and service.store.connection is None and not service.store.failed
                assert task.status == 'requires_approval'
                saved_before_callback = read_durable_state(path)
            timer.join(timeout=5)
            assert not timer.is_alive()
        finally:
            threading.excepthook = original_hook
            if service.store.connection is not None:
                service.shutdown()

        assert len(errors) == 1 and errors[0].exc_type is PersistenceError, errors
        assert 'fenced after storage failure/close' in str(errors[0].exc_value)
        saved_after_callback = read_durable_state(path)
        assert saved_before_callback == saved_after_callback
        stored, points, version = saved_after_callback
        stored = unpack(stored)
        assert stored['status'] == 'requires_approval' and stored['required_action']
        assert task.status == 'cancelling' and task.stop_reason == 'timed_out'
        assert not target.exists() and len(backend.requests) == 1
        print(json.dumps({
            'status': 'REPRODUCED',
            'uses_real_timer_and_service_condition': True,
            'normal_suspend': receipt,
            'store_fenced_before_callback': service.store.failed,
            'timer_error': str(errors[0].exc_value),
            'timer_trace': traceback.format_exception(errors[0].exc_type, errors[0].exc_value, errors[0].exc_traceback),
            'in_memory_status_after_callback': task.status,
            'durable_status_after_callback': stored['status'],
            'durable_approval_preserved': bool(stored['required_action']),
            'durable_checkpoint_and_journal_unchanged_during_late_callback': saved_before_callback == saved_after_callback,
            'last_durable_journal_boundary': points[-1],
            'schema_after_suspend': version,
            'write_tool_dispatched': target.exists(),
            'scripted_model_requests': len(backend.requests),
        }, indent=2))


if __name__ == '__main__':
    main()
