"""Keep the archived runner intact while recording actual loaded source files."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys


if __name__ == '__main__':
    runner = Path(sys.argv.pop(1)).resolve()
    output = Path(sys.argv.pop(1)).resolve()
    root = Path(sys.argv[sys.argv.index('--repo') + 1]).resolve()
    try:
        runpy.run_path(str(runner), run_name='__main__')
    finally:
        if output.parent.is_dir():
            package_names = {
                'agent', 'companion', 'computer', 'localpilot_api', 'localpilot_channels',
                'localpilot_plugins', 'localpilot_service', 'localpilot_suite', 'suite',
            }
            origins = {}
            for name, module in sorted(sys.modules.items()):
                if name.partition('.')[0] not in package_names:
                    continue
                origin = getattr(module, '__file__', None)
                if origin:
                    path = Path(origin).resolve()
                    origins[name] = {
                        'path': str(path),
                        'within_frozen_source': path.is_relative_to(root),
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    }
                else:
                    paths = [Path(value).resolve() for value in getattr(module, '__path__', ())]
                    origins[name] = {
                        'namespace_paths': [str(path) for path in paths],
                        'within_frozen_source': bool(paths) and all(path.is_relative_to(root) for path in paths),
                    }
            receipt = {
                'source_root': str(root),
                'measurement': 'actual main test process modules after execution',
                'pythonpath': os.environ.get('PYTHONPATH'),
                'sys_path': sys.path,
                'product_modules': origins,
                'outside_frozen_source': [
                    name for name, origin in origins.items() if not origin['within_frozen_source']
                ],
            }
            with output.open('x') as stream:
                json.dump(receipt, stream, indent=2)
                stream.write('\n')
