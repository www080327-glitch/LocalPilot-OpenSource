"""Run existing suites from a frozen source with a spawn-safe entry point."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import unittest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--suite', choices=('core', 'companion', 'suite'), required=True)
    args = parser.parse_args()
    root = args.repo.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    os.chdir(root)
    sys.path.insert(0, str(root))
    before = fingerprint(root)
    write(args.output / 'source-before.json', before)
    (args.output / 'runner.py').write_bytes(Path(__file__).read_bytes())
    test_root = root / {'core': 'tests', 'companion': 'companion/tests', 'suite': 'suite/tests'}[args.suite]
    tests = unittest.defaultTestLoader.discover(str(test_root))
    started = time.monotonic()
    with (args.output / 'tests.log').open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(tests)
    after = fingerprint(root)
    write(args.output / 'source-after.json', after)
    report = {
        'suite': args.suite,
        'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'source_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
        'python': platform.python_version(), 'python_executable': sys.executable,
        'run': result.testsRun,
        'passed': result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped),
        'failures': [{'test': str(test), 'traceback': detail} for test, detail in result.failures],
        'errors': [{'test': str(test), 'traceback': detail} for test, detail in result.errors],
        'skips': [{'test': str(test), 'reason': reason} for test, reason in result.skipped],
        'expected_failures': len(result.expectedFailures),
        'unexpected_successes': len(result.unexpectedSuccesses),
        'elapsed_seconds': time.monotonic() - started,
        'source_files': len(before), 'source_unchanged': before == after,
        'successful': result.wasSuccessful() and before == after,
    }
    write(args.output / 'RESULTS.json', report)
    print(json.dumps({key: len(value) if isinstance(value, list) else value
                     for key, value in report.items()}), flush=True)
    return 0 if report['successful'] else 1


def fingerprint(root):
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
    extensions = {'.py', '.swift', '.ts', '.tsx', '.toml'}
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in names if name and Path(name).suffix in extensions
            and not set(Path(name).parts) & {'evidence', 'archive'}}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


if __name__ == '__main__':
    raise SystemExit(main())
