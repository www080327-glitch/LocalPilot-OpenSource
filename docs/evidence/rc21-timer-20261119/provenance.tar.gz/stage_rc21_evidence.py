#!/usr/bin/env python3
"""Snapshot explicitly selected RC21 text evidence as deterministic archives."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile


SELECTION = "RC21_EVIDENCE_SELECTION.json"
SOURCE_MAP = "PUBLIC_RC21_SOURCE_MAP.json"
SUMMARY_COPIES = {
    "RC21_PRODUCT_FREEZE.json": "PRODUCT_FREEZE.json",
    SOURCE_MAP: "PUBLIC_SOURCE_MAP.json",
    "rc21-runtime/RESULTS.json": "RUNTIME_RESULTS.json",
    "rc21-runtime/core-full-final/FINAL_CORE_RESULTS.json": "FINAL_CORE_RESULTS.json",
    "rc21-review/INDEPENDENT_REVIEW.json": "INDEPENDENT_REVIEW.json",
    "rc21-review/INHERITED_SOURCE_SCOPE.json": "INHERITED_SOURCE_SCOPE.json",
    "rc21-install/linux/INSTALL_FINAL_RESULTS.json": "LINUX_INSTALL_RESULTS.json",
    "rc21-install/linux/PACKAGE_VERIFICATION.json": "LINUX_PACKAGE_VERIFICATION.json",
    "rc21-install/linux/PACKAGED_ROLLBACK.json": "LINUX_PACKAGED_ROLLBACK.json",
}
EXCLUSIONS = [
    "Repository clones and source snapshots (selected SHA-256 manifests are included)",
    "Virtual environments, node_modules, toolchains, sysroots, packages and models",
    "Databases, journals, locks, workspace files and generated bulk fixtures",
    "Artwork, images, screenshots, built applications and other binary artifacts",
    "Private Library identifiers, URLs, upload helpers and download receipts",
    "All files outside the explicit list, including previous-phase raw results",
]
SECRET_PATTERNS = {
    "provider_key": r"\b(?:sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[A-Z0-9]{16})\b",
    "private_key": r"-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----",
    "credential_assignment": r"(?i)(?:authorization\s*[:=]\s*[\"']?bearer\s+|api[_-]?key\s*[:=]\s*[\"']?)([A-Za-z0-9_.-]{16,})",
    "url_credentials": r"://[^/\s:@]+:[^/\s@]+@",
    "signed_query": r"(?i)[?&](?:sig|X-Amz-Signature|access_token)=([^&\s\"'<>]+)",
    "private_library_reference": r"file-inline-libfile_[A-Za-z0-9_-]+|oai-library[:][/][/]|(?i:library_file_id)\s*[:=]\s*[\"']?file[-_]",
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", choices=["draft", "final"], required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    if output.exists():
        raise SystemExit(f"Snapshot directory already exists: {output}")
    groups, payloads = read_selection(root)
    source_map = json.loads(payloads.get(SOURCE_MAP, b"null"))
    if args.phase == "final":
        freeze = json.loads(payloads["RC21_PRODUCT_FREEZE.json"])
        if not source_map or not source_map["remote_tree_read_back"] or (
            source_map["local_commit"] != freeze["source_commit"]
            or source_map["tree"] != freeze["tree"]
        ):
            raise SystemExit(f"Final stage requires a matching public source readback: {SOURCE_MAP}")
    credential_scan = scan_credentials(payloads)
    output.mkdir(parents=True)

    archives = []
    for group, names in sorted(groups.items()):
        path = output / f"{group}.tar.gz"
        write_archive(path, names, payloads)
        archives.append({
            **file_record(path.name, path.read_bytes()),
            "member_count": len(names),
            "members": [file_record(name, payloads[name]) for name in names],
        })

    standalone = []
    for source, name in SUMMARY_COPIES.items():
        if source in payloads:
            (output / name).write_bytes(payloads[source])
            standalone.append({**file_record(name, payloads[source]), "source": source})
    generated = {
        "LOG_SUMMARY.json": json_bytes(summarize_logs(payloads)),
        "SANITIZATION.json": json_bytes(credential_scan),
        "EVIDENCE_README.md": readme(args.phase).encode("utf-8"),
    }
    for name, data in generated.items():
        (output / name).write_bytes(data)
        standalone.append({**file_record(name, data), "generated": True})

    manifest = {
        "format": "localpilot-rc21-public-evidence-v1",
        "phase": args.phase,
        "source_map": source_map,
        "raw_member_count": len(payloads),
        "raw_member_bytes": sum(map(len, payloads.values())),
        "archive_count": len(archives),
        "archive_bytes": sum(item["bytes"] for item in archives),
        "selection": {"explicit_files": groups, "excluded": EXCLUSIONS},
        "transformations": [],
        "archives": archives,
        "standalone": standalone,
    }
    (output / "EVIDENCE_MANIFEST.json").write_bytes(json_bytes(manifest))
    checksummed = sorted(output.iterdir())
    (output / "SHA256SUMS").write_text("".join(f"{digest(p.read_bytes())}  {p.name}\n" for p in checksummed), encoding="utf-8")
    print(json.dumps({"output": str(output), "phase": args.phase, "raw_members": len(payloads), "archives": len(archives), "archive_bytes": manifest["archive_bytes"], "credential_candidates": credential_scan["candidate_count"]}))


def read_selection(root: Path) -> tuple[dict[str, list[str]], dict[str, bytes]]:
    groups = {group: sorted(paths) for group, paths in json.loads((root / SELECTION).read_bytes()).items()}
    payloads = {}
    for name in sorted(name for paths in groups.values() for name in paths):
        path = root / name
        if name in payloads or path.resolve() != path or not path.is_file():
            raise SystemExit(f"Selected evidence must be a unique regular file without symlinks: {name}")
        if not path.is_relative_to(root) or path.suffix not in {".json", ".log", ".md", ".py", ".txt", ".exit"}:
            raise SystemExit(f"Selected evidence must be text inside the validation directory: {name}")
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        if (before.st_mtime_ns, before.st_size) != (after.st_mtime_ns, after.st_size) or len(data) != after.st_size:
            raise SystemExit(f"Evidence changed during staging: {name}")
        data.decode("utf-8")
        if b"\x00" in data:
            raise SystemExit(f"Binary content in selected text file: {name}")
        payloads[name] = data
    return groups, payloads


def scan_credentials(payloads: dict[str, bytes]) -> dict:
    candidates = []
    for name, data in payloads.items():
        text = data.decode("utf-8")
        for kind, pattern in SECRET_PATTERNS.items():
            for match in re.finditer(pattern, text):
                candidates.append({"path": name, "pattern": kind, "line": text.count("\n", 0, match.start()) + 1})
    if candidates:
        raise SystemExit("Inspect credential candidates before publication; no automatic redaction: " + json.dumps(candidates))
    return {
        "files_scanned": len(payloads),
        "patterns": list(SECRET_PATTERNS),
        "candidate_count": 0,
        "automatic_redaction": False,
        "transformations": [],
        "limitations": "Pattern screening plus explicit file selection; not a claim that arbitrary sensitive text can be detected automatically.",
    }


def write_archive(path: Path, names: list[str], payloads: dict[str, bytes]) -> None:
    with path.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, filename="", mode="wb", mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name in names:
                    data = payloads[name]
                    member = tarfile.TarInfo(name)
                    member.size = len(data)
                    member.mode = 0o644
                    member.mtime = 0
                    archive.addfile(member, io.BytesIO(data))



def summarize_logs(payloads: dict[str, bytes]) -> dict:
    records = []
    ansi = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
    for name, data in sorted(payloads.items()):
        if not name.endswith(".log"):
            continue
        text = ansi.sub("", data.decode("utf-8"))
        footers = []
        for match in re.finditer(r"(?m)^Ran (\d+) tests? in ([\d.]+)s\s*\n\s*\n(OK|FAILED)(?: \(([^\n]+)\))?", text):
            counts = {key.strip().replace(" ", "_"): int(value) for key, value in re.findall(r"([a-z_ ]+)=(\d+)", match.group(4) or "")}
            footers.append({"framework": "unittest", "ran": int(match.group(1)), **counts, "result": match.group(3), "seconds": float(match.group(2)), "footer": match.group(0)})
        for match in re.finditer(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([\d.]+)s", text):
            footers.append({"framework": "rust", "result": match.group(1), "passed": int(match.group(2)), "failed": int(match.group(3)), "ignored": int(match.group(4)), "footer": match.group(0)})
        node = {key: int(value) for key, value in re.findall(r"(?m)^(?:ℹ|#) (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$", text)}
        if node:
            footers.append({"framework": "node", **node})
        records.append({**file_record(name, data), "footers": footers, "classification": "REPORTED_FOOTER" if footers else "NO_PARSED_TEST_FOOTER"})
    return {
        "scope": "Framework summaries extracted from the raw logs. The runs have separate source receipts and scopes.",
        "limits": "An absent footer provides no test result. Some logs are interrupted attempts; consult the run receipts. A footer alone cannot establish the tested source, process exit code or installed environment. A class setup error can count as an error without admitting a test method to the run count, so unittest pass counts are not inferred from footers.",
        "logs": records,
    }


def file_record(name: str, data: bytes) -> dict:
    return {"path": name, "bytes": len(data), "sha256": digest(data)}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")



def readme(phase: str) -> str:
    return f"""# LocalPilot RC21 evidence

Snapshot phase is **{phase.upper()}**. Release status remains **NOT_RELEASE_READY**.

`EVIDENCE_MANIFEST.json` records the explicit source selection, archive members, byte counts and SHA-256 hashes. `SHA256SUMS` covers every delivered file except itself. Each gzip archive preserves selected input files byte for byte. `SANITIZATION.json` records screening and transformations.

`PUBLIC_SOURCE_MAP.json` identifies the frozen product tree. Individual receipts specify which source revision, command and execution scope apply. The focused timer regression and SQLite probe include runs before and after the fix. The independent review identifies the source it inspected. `FINAL_CORE_RESULTS.json` reconciles the raw unittest runner count with the recorded test methods and class setup error.

`LOG_SUMMARY.json` records framework footers individually. A footer only applies to the corresponding run. RC20 historical regressions, unresolved full-run errors, prior installation checks and the original late-timer reproduction remain in that stage's published evidence.

In this directory, run `sha256sum --check SHA256SUMS` before extracting. Unpack the archives to one directory and rerun `python stage_rc20_evidence.py --output <new-snapshot-directory> --phase {phase}` from there to regenerate the snapshot. The script requires a fresh destination.
"""


if __name__ == "__main__":
    main()
