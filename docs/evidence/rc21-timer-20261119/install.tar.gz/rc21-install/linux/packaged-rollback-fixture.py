"""Run unchanged in candidate, actual RC18, then candidate source imports."""
import json
import sys
import sqlite3
from pathlib import Path

sys.path.insert(0, '/workspace/scratch/b0df9966d470/nov19-validation/rc21-install/linux/installed-harness')

from agent.engine_v5 import EngineV5Policy
from agent.persistence import dumps, digest
from agent.registry import create_default_registry
from agent.retry import RetryPolicy
from agent.session import AgentSession, SessionBudgets
from localpilot_api.service import TaskRequest, TaskService
from tests.test_runtime_api import Backend, answer, call

phase, location = sys.argv[1:]
root = Path(location)
root.mkdir(exist_ok=True)
workspace = root / 'workspace'
workspace.mkdir(exist_ok=True)
backend = Backend(*(answer('completed') for _ in range(30)))

def factory(callback):
    return AgentSession(create_default_registry(workspace, permission_mode='full-permission'),
        backend=backend, policy='cloud-only', streaming=False, event_callback=callback,
        engine_policy=EngineV5Policy(max_completion_repairs=0), retry_policy=RetryPolicy(max_attempts=1),
        budgets=SessionBudgets(max_steps=12, max_tool_calls=20, max_token_units=1000000, max_output_tokens=512))

service = TaskService({'localpilot': factory}, persistence=root / 'runtime.sqlite3', history_rotation_bytes=1)
task_path = root / 'tasks.json'
history = json.loads(task_path.read_text()) if task_path.exists() else []
for task in history:
    assert service.task_snapshot(task['id']) == task, task['id']
sid = history[0]['session_id'] if history else None

def submit(text):
    global sid
    task = service.wait(service.create_task(TaskRequest(text, session_id=sid))['id'])
    assert task['status'] == 'completed', task
    sid = task['session_id']
    history.append(task)

if phase == 'candidate-create':
    submit('RC19-ORIGINAL-NEEDLE')
    submit('second task')
    submit('third task')
    backend.steps = [answer(None, call('recall_history', {'query': 'RC19-ORIGINAL-NEEDLE'}, 'history-call')),
                     answer('history received')]
    submit('Recall the original requirement')
    assert service.sessions[sid].runtime.tool_history[-1]['payload']['result']['matches']
elif phase == 'rc18-write':
    assert 'recall_history' not in service.sessions[sid].runtime.registry._tools
    submit('RC18-POST-DOWNGRADE-NEEDLE')
    submit('legacy second task')
    submit('legacy third task')
elif phase == 'candidate-reopen':
    registry = service.sessions[sid].runtime.registry
    for query in ('RC19-ORIGINAL-NEEDLE', 'RC18-POST-DOWNGRADE-NEEDLE'):
        result = registry.call('recall_history', {'query': query})
        assert result['matches'], result
    submit('Candidate continuation after legacy writes')
else:
    raise AssertionError(phase)

records = service.store.connection.execute('SELECT session_id,generation,payload,sha256 FROM runtime_segments ORDER BY generation').fetchall()
for _, _, raw, checksum in records:
    assert digest(raw) == checksum
summary = {'phase': phase, 'source': str(Path(sys.modules['agent.persistence'].__file__).resolve()),
    'session_id': sid, 'task_count': len(history), 'segments': len(records),
    'segment_hashes': [r[3] for r in records], 'task_hashes': [digest(dumps(t)) for t in history],
    'schema': service.store.connection.execute('PRAGMA user_version').fetchone()[0],
    'projection_sources': service.store.connection.execute('SELECT count(*) FROM runtime_history_sources').fetchone()[0],
    'backup_created': service.store.migration_backup is not None, 'status': 'PASS'}
task_path.write_text(json.dumps(history, ensure_ascii=False, indent=2))
if phase == 'candidate-create':
    service.store.close()
else:
    service.suspend()
with sqlite3.connect(root / 'runtime.sqlite3') as db:
    summary['schema_after_writer_exit'] = db.execute('PRAGMA user_version').fetchone()[0]
    assert summary['schema_after_writer_exit'] == (4 if phase == 'candidate-create' else 3)
(root / (phase + '.json')).write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps(summary, ensure_ascii=False))
