import email
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib
import zipfile


ROOT = Path('WORKSPACE/LocalPilot-OpenSource')
OUTPUT = ROOT.parent / 'validation'
if '--output' in sys.argv:
    OUTPUT = Path(sys.argv[sys.argv.index('--output') + 1])
    OUTPUT.mkdir()
SOURCE = OUTPUT / 'cooperation-package-source'
WHEELS = OUTPUT / 'cooperation-component-wheels'
ENVIRONMENT = OUTPUT / 'cooperation-component-install'
BUILD_PYTHON = ROOT / '.venv/bin/python'


def command(label, args, cwd):
    with (OUTPUT / ('cooperation-' + label + '.log')).open('w') as log:
        log.write(json.dumps({'argv':[str(arg) for arg in args], 'cwd':str(cwd)}) + '\n')
        log.flush()
        result = subprocess.run(args, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(label + ' failed; preserve its log')


def main():
    if '--reuse-build' not in sys.argv:
        SOURCE.mkdir()
        WHEELS.mkdir()
        files = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'], cwd=ROOT).decode().split('\0')
        for name in set(files) - {''}:
            source = ROOT / name
            if not source.is_file():
                continue
            target = SOURCE / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        for component, directory in (('core', SOURCE), ('companion', SOURCE/'companion'), ('suite', SOURCE/'suite')):
            command('wheel-' + component, [BUILD_PYTHON,'-m','build','--wheel','--no-isolation','--outdir',WHEELS,directory], SOURCE)
        command('wheel-channels', [BUILD_PYTHON,SOURCE/'scripts/build_channels_wheel.py','--out',WHEELS,'--no-isolation'], SOURCE)
    audit = {'kind':'REAL_COMPONENT_WHEELS_SOURCE_OWNERSHIP_LICENSE_AUDIT', 'wheels':[], 'python_files':0}
    owners = {}
    for wheel in sorted(WHEELS.glob('*.whl')):
        with zipfile.ZipFile(wheel) as archive:
            metadata = email.message_from_bytes(archive.read(next(name for name in archive.namelist() if name.endswith('.dist-info/METADATA'))))
            files = [name for name in archive.namelist() if name.endswith('.py') and '.data/' not in name]
            for name in files:
                source = ROOT / ('suite/' + name if name.startswith('localpilot_suite/') else name)
                assert source.is_file(), (wheel.name, name, 'source missing')
                assert archive.read(name) == source.read_bytes(), (wheel.name, name, 'source differs')
                assert name not in owners, (name, owners.get(name), wheel.name)
                owners[name] = wheel.name
            prefix = {'localpilot-suite':'suite/', 'localpilot-companion':'companion/', 'localpilot-channels':'channels/'}.get(metadata['Name'], '')
            config = tomllib.loads((ROOT/prefix/'pyproject.toml').read_text())
            data_root = ROOT / (prefix if metadata['Name'] != 'localpilot-channels' else '')
            declared = {destination+'/'+Path(source).name:data_root/source
                        for destination, sources in config.get('tool', {}).get('setuptools', {}).get('data-files', {}).items()
                        for source in sources}
            data_files = [name for name in archive.namelist() if name.endswith('.py') and '.data/data/' in name]
            for name in data_files:
                source = declared[name.split('.data/data/', 1)[1]]
                assert archive.read(name) == source.read_bytes(), (wheel.name, name, 'data source differs')
            licenses = [name for name in archive.namelist() if '.dist-info/licenses/' in name]
            assert licenses and all(archive.read(name) for name in licenses)
            audit['wheels'].append({'name':wheel.name, 'distribution':metadata['Name'], 'version':metadata['Version'],
                'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(), 'python_files':len(files), 'source_exact':True,
                'python_data_files':len(data_files), 'license_expression':metadata['License-Expression'], 'license_files':licenses})
            audit['python_files'] += len(files)
            if metadata['Name'] == 'localpilot-companion':
                assert archive.read('companion/observers/MeetingTranscriber.swift') == (ROOT/'companion/observers/MeetingTranscriber.swift').read_bytes()
                assert 'companion/model/candidate.py' in files
            if metadata['Name'] == 'localpilot-agent-service':
                assert 'agent/session_tools.py' in files
                assert not any(name.startswith('localpilot_channels/') for name in archive.namelist())
    assert len(audit['wheels']) == 4
    (OUTPUT/'cooperation-component-wheel-audit.json').write_text(json.dumps(audit, indent=2)+'\n')
    command('install-venv', [BUILD_PYTHON,'-m','venv',ENVIRONMENT], OUTPUT)
    python = ENVIRONMENT / 'bin/python'
    command('wheel-install', [python,'-m','pip','install',*sorted(WHEELS.glob('*.whl'))], OUTPUT)
    proof_code = '''import hashlib, importlib.metadata, json, pathlib, sys, sysconfig, tempfile
from agent.registry import create_default_registry
import agent.session, agent.session_tools, companion.model.candidate, localpilot_suite, localpilot_channels
wheel_dir=pathlib.Path(sys.argv[1]); source=pathlib.Path(sys.argv[2]); installed=pathlib.Path(sysconfig.get_paths()['purelib'])
import zipfile
count=data_count=0
for wheel in wheel_dir.glob('*.whl'):
    with zipfile.ZipFile(wheel) as archive:
        for name in archive.namelist():
            if name.endswith('.py'):
                if '.data/data/' in name:
                    target=pathlib.Path(sysconfig.get_paths()['data'])/name.split('.data/data/',1)[1]
                    data_count+=1
                else:
                    target=installed/name
                    count+=1
                assert target.read_bytes()==archive.read(name),name
with tempfile.TemporaryDirectory() as directory:
    root=pathlib.Path(directory); (root/'source.txt').write_text('installed-product-fact')
    registry=create_default_registry(root,permission_mode='full-permission')
    observed=registry.call('read_file',{'path':'source.txt'})
    assert 'installed-product-fact' in json.dumps(observed)
    created=registry.call('apply_patch',{'changes':[{'path':'result.txt','operation':'create','content':'installed-effect'}]})
    assert (root/'result.txt').read_text()=='installed-effect'
print(json.dumps({'status':'PASS','installed_python_files':count,'installed_python_data_files':data_count,'all_wheel_sources_exact':True,'actual_file_read_write':True,
    'module_paths':{name:str(pathlib.Path(module.__file__).resolve()) for name,module in [('agent',agent.session),('tools',agent.session_tools),('candidate',companion.model.candidate),('suite',localpilot_suite),('channels',localpilot_channels)]},
    'versions':{distribution:importlib.metadata.version(distribution) for distribution in ['localpilot-agent-service','localpilot-companion','localpilot-suite','localpilot-channels','psutil','pypdf','watchdog','Pillow']}}))
'''
    result = subprocess.run([python,'-I','-c',proof_code,WHEELS,ROOT], cwd=OUTPUT, text=True, capture_output=True)
    (OUTPUT/'cooperation-installed-probe.log').write_text(result.stdout+result.stderr)
    result.check_returncode()
    proof = json.loads(result.stdout)
    proof['commands'] = []
    for executable, option in (('localpilot','--version'),('localpilot-core','--help'),('localpilot-service','--help'),('localpilot-channels','--help'),('companion','--help')):
        result = subprocess.run([ENVIRONMENT/'bin'/executable,option], cwd=OUTPUT, text=True, capture_output=True)
        result.check_returncode()
        proof['commands'].append({'executable':executable,'option':option,'returncode':result.returncode,
                                  'stdout':result.stdout,'stderr':result.stderr})
        if executable == 'localpilot':
            assert json.loads(result.stdout)['localpilot-channels'] == import_version(audit, 'localpilot-channels')
    (OUTPUT/'cooperation-component-installed-proof.json').write_text(json.dumps(proof, indent=2)+'\n')
    print(json.dumps({'wheels':len(audit['wheels']),'python_files':audit['python_files'],'installation':'PASS','suite_channels_version':'PASS'}))


def import_version(audit, distribution):
    return next(row['version'] for row in audit['wheels'] if row['distribution'] == distribution)


if __name__ == '__main__':
    main()
