import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile


ROOT = Path('WORKSPACE/LocalPilot-OpenSource')
VALIDATION = ROOT.parent / 'validation'
EVIDENCE = ROOT / 'docs/evidence/pa-cooperation-20261115'
BASE = '92ad9a30b9fda43bc185d96c99e5cb0a8ce8ec02'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def public_bytes(data):
    text = data.decode('utf-8')
    text = text.replace(str(ROOT.parent), 'WORKSPACE')
    text = text.replace('RUNTIME_HOME', 'RUNTIME_HOME')
    text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text)
    return text.encode('utf-8')


def save_json(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def unittest_result(path):
    text = path.read_text()
    count, seconds = re.findall(r'Ran (\d+) tests? in ([0-9.]+)s', text)[-1]
    status = re.findall(r'^(OK(?: \([^\n]+\))?|FAILED \([^\n]+\))$', text, re.M)[-1]
    def number(label):
        match = re.search(rf'{label}=(\d+)', status)
        return int(match.group(1)) if match else 0
    skipped, failed, errors = number('skipped'), number('failures'), number('errors')
    return {'run':int(count), 'passed':int(count)-skipped-failed-errors,
            'failures':failed, 'errors':errors, 'skipped':skipped,
            'seconds':float(seconds), 'log':str(path.relative_to(VALIDATION))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--core', required=True)
    parser.add_argument('--suite', required=True)
    parser.add_argument('--channels', required=True)
    parser.add_argument('--packaging', required=True)
    args = parser.parse_args()
    package = VALIDATION / args.packaging
    core = json.loads((VALIDATION / (args.core + '.json')).read_text())
    core_summary = unittest_result(VALIDATION / (args.core + '.log'))
    assert core_summary['run'] == core['run']
    assert core_summary['passed'] == core['passed']
    groups = {
        'core':core_summary,
        'companion':unittest_result(VALIDATION/'companion-continuation-20261115-full-r2.log'),
        'suite':unittest_result(VALIDATION/(args.suite+'.log')),
        'openai_sdk':unittest_result(VALIDATION/'cooperation-sdk-final.log'),
        'harbor':unittest_result(VALIDATION/'eval-continuation-20261115/harbor-contract-final-workers.log'),
        'installed_channels':unittest_result(VALIDATION/(args.channels+'.log')),
    }
    assert all(row['failures'] == 0 and row['errors'] == 0 for row in groups.values()), groups
    groups['desktop'] = {'vitest_passed':68, 'vitest_files':12, 'typescript':'PASS',
        'vite':'PASS', 'unused_symbols':'PASS', 'playwright_collected':34,
        'playwright_executed':0, 'playwright_status':'NOT_RUN',
        'playwright_reason':'Chromium socket() failed: Operation not permitted before any page opened'}
    for source, destination in [
            ('cooperation-component-wheel-audit.json','component-wheel-audit.json'),
            ('cooperation-component-installed-proof.json','component-installed-proof.json')]:
        (EVIDENCE/destination).write_bytes(public_bytes((package/source).read_bytes()))

    paths = {p for p in VALIDATION.iterdir() if p.is_file() and p.suffix in {'.log','.json'}
             and p.name.startswith(('cooperation-','companion-continuation-20261115','companion-candidate-interface-20261115'))
             and not any(word in p.name for word in ('upload','payload','publication'))}
    for name in ['desktop-pa-continuation-20261115','eval-continuation-20261115']:
        paths.update(p for p in (VALIDATION/name).iterdir() if p.is_file() and p.suffix in {'.log','.json'})
    for directory in VALIDATION.glob('cooperation-packaging-*'):
        paths.update(p for p in directory.iterdir() if p.is_file() and p.suffix in {'.log','.json'})
    paths.update([VALIDATION/'cooperation-wheel-proof.py', Path(__file__)])
    entries = []
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode='w') as archive:
        for path in sorted(paths):
            relative = str(path.relative_to(VALIDATION))
            raw = path.read_bytes()
            public = public_bytes(raw)
            if re.search(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', public):
                raise ValueError('Credential-shaped material requires review: ' + relative)
            entry = tarfile.TarInfo('logs/' + relative)
            entry.size, entry.mode, entry.mtime = len(public), 0o644, 0
            archive.addfile(entry, io.BytesIO(public))
            entries.append({'path':relative, 'original_bytes':len(raw), 'public_bytes':len(public),
                            'original_sha256':digest(raw), 'public_sha256':digest(public)})
    archive_bytes = gzip.compress(tar_buffer.getvalue(), mtime=0)
    (EVIDENCE/'verification-logs-redacted.tar.gz').write_bytes(archive_bytes)
    save_json('LOG_MANIFEST.json', {'scope':'This continuation only; earlier failures are retained',
        'redaction':['workspace path replaced with WORKSPACE','runtime home replaced with RUNTIME_HOME','ANSI formatting removed'],
        'originals_retained_locally':True, 'files':entries,
        'archive':{'path':'verification-logs-redacted.tar.gz','bytes':len(archive_bytes),'sha256':digest(archive_bytes)}})

    files = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'], cwd=ROOT).decode().split('\0')
    source_rows = []
    for name in sorted(set(files)-{''}):
        if name.startswith('docs/evidence/pa-cooperation-20261115/'):
            continue
        path = ROOT/name
        if path.is_symlink():
            data, mode = os.readlink(path).encode(), '120000'
        elif path.is_file():
            data = path.read_bytes()
            mode = '100755' if path.stat().st_mode & 0o111 else '100644'
        else:
            continue
        source_rows.append({'path':name,'mode':mode,'bytes':len(data),'sha256':digest(data)})
    encoded = json.dumps(source_rows, ensure_ascii=False, separators=(',',':')).encode('utf-8')
    save_json('SOURCE_FILES.json', {'base_commit':BASE,
        'scope':'All tracked and new non-ignored repository files except this evidence directory; prior evidence is included',
        'aggregate_algorithm':'SHA-256 of UTF-8 JSON files array, ensure_ascii=False, separators=(comma,colon), sorted by path',
        'aggregate_sha256':digest(encoded),'count':len(source_rows),'files':source_rows})

    warnings = {}
    for name, row in groups.items():
        if 'log' in row:
            text = (VALIDATION/row['log']).read_text()
            warnings[name] = {term:len(re.findall(term,text)) for term in ['ResourceWarning','RuntimeWarning']}
    save_json('RESULTS.json', {'date':'2026-11-15','branch':'codex/pa-cooperation-20261115',
        'base_commit':BASE,'tested_commit':None,'pull_request':None,
        'environment':{'os':'Linux','architecture':'x86_64','python':'3.12.14'},
        'final_groups':groups,'raw_core_skips':core['skipped'],'final_warning_mentions':warnings,
        'counts_overlap':True,'source_manifest_sha256':digest((EVIDENCE/'SOURCE_FILES.json').read_bytes()),
        'log_manifest_sha256':digest((EVIDENCE/'LOG_MANIFEST.json').read_bytes()),
        'public_model_comparison':{'executed_this_turn':False,'old_study_code':'1c06e97',
            'old_study_total':534,'old_pass':1,'old_fail':3,'old_error':13,'old_without_final_result':517,
            'old_results_modified':False,'official_ranking_claimed':False},
        'channel_startup_fix':{'status':'FIXED_AND_INSTALLED_REGRESSION_PASSED',
            'observed_cause':'A live newly spawned child temporarily returned empty argv; the original launcher treated it as changed arguments',
            'change':'Defer only the initial empty observation to existing readiness; reject actual changes or final empty identity and reap the original child on recording failure',
            'new_retries':False,'macos_status':'NOT_RUN'},
        'training_scope':{'chosen_path':'human-reviewed LoRA','actual_training':'NOT_RUN',
            'dense_full_boundary':'Selected Transformer layers only; embedding/head are excluded',
            'reinforcement_learning_executor':'NOT_IMPLEMENTED'},
        'not_run':['Rust','Swift','macOS APP build/install/upgrade/rollback','real native PA/UI/audio',
            'real model quality and new public benchmark study','actual LoRA training and adapter tensor inference',
            'Intel hardware and CPU model performance','real KV cold/hot/reload measurements'],
        'preserved_failed_runs':['cooperation-child-registry-first.log','cooperation-script-approval-before.log',
            'cooperation-child-authorization-before.log','companion-continuation-20261115-focus-r1.log',
            'companion-continuation-20261115-full-r1.log','cooperation-wheel-audit-first.log',
            'cooperation-installed-channel-final.log','cooperation-installed-channel-post-diagnostics.log',
            'cooperation-channel-identity-deterministic-before.log',
            'cooperation-core-post-diagnostics.log','desktop-pa-continuation-20261115/chromium-probe.log'],
        'missing_original_logs':[{'scope':'First Harbor orchestration fixture run',
            'reported_result':{'passed':5,'errors':1},
            'reason':'Only tool conversation output was retained; no standalone raw log and temporary directory was cleaned by the test',
            'subsequent_success_logs_are_not_original_failure_evidence':True}],
        'actions':{'merged':False,'release_published':False,'daily_app_replaced':False,'external_forms_submitted':False}})
    print(json.dumps({'groups':groups,'source_files':len(source_rows),'logs':len(entries),
                      'archive_bytes':len(archive_bytes)},ensure_ascii=False))


if __name__ == '__main__':
    main()
